"use strict";
exports.id = "src_app_features_other-apps_furniture_furniture_module_ts";
exports.ids = ["src_app_features_other-apps_furniture_furniture_module_ts"];
exports.modules = {

/***/ "./src/app/features/other-apps/furniture/furniture-routing.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FurnitureRoutingModule": () => (/* binding */ FurnitureRoutingModule),
/* harmony export */   "routes": () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _furniture_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/other-apps/furniture/furniture.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");




const routes = [
    {
        path: "",
        component: _furniture_component__WEBPACK_IMPORTED_MODULE_0__.FurnitureComponent,
    },
];
class FurnitureRoutingModule {
}
FurnitureRoutingModule.ɵfac = function FurnitureRoutingModule_Factory(t) { return new (t || FurnitureRoutingModule)(); };
FurnitureRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: FurnitureRoutingModule });
FurnitureRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptRouterModule.forChild(routes)] });


/***/ }),

/***/ "./src/app/features/other-apps/furniture/furniture.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FurnitureComponent": () => (/* binding */ FurnitureComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");


function FurnitureComponent_ng_container_6_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](1, "ContentView", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](2, "Label", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const tag_r11 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("backgroundColor", tag_r11.selected ? "#65ADF1" : "#fff")("borderColor", tag_r11.selected ? "#65ADF1" : "#555");
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", tag_r11.tagName)("color", tag_r11.selected ? "#fff" : "#555");
} }
function FurnitureComponent_ng_container_8_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
} }
const _c0 = function (a0) { return { $implicit: a0 }; };
function FurnitureComponent_ng_container_8_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](1, FurnitureComponent_ng_container_8_ng_container_1_Template, 1, 0, "ng-container", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const trendingItem_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵnextContext"]();
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r2)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](2, _c0, trendingItem_r12));
} }
function FurnitureComponent_ng_template_9_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "GridLayout", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ContentView", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "GridLayout", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "Label", 23)(4, "Label", 24)(5, "Label", 25)(6, "Button", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "Image", 27);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
} if (rf & 2) {
    const item_r14 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", item_r14.name);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", item_r14.description);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", item_r14.price);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", item_r14.image);
} }
function FurnitureComponent_ng_container_14_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
} }
function FurnitureComponent_ng_container_16_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
} }
function FurnitureComponent_ng_container_18_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
} }
function FurnitureComponent_ng_container_20_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
} }
function FurnitureComponent_ng_template_21_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](0, "Image", 28);
} if (rf & 2) {
    const tab_r15 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", tab_r15.tabImage);
} }
function FurnitureComponent_ng_container_24_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementContainer"](0);
} }
class FurnitureComponent {
    constructor() {
        this.tabs = {
            home: {
                tabImage: "~/assets/images/other-apps/furniture/house.png",
            },
            search: {
                tabImage: "~/assets/images/other-apps/furniture/search.png",
            },
            cart: {
                tabImage: "~/assets/images/other-apps/furniture/shopping-cart.png",
            },
            likes: {
                tabImage: "~/assets/images/other-apps/furniture/hearts.png",
            },
            notifications: {
                tabImage: "~/assets/images/other-apps/furniture/notification.png",
            },
        };
        this.tags = [
            {
                tagName: "Bedroom",
                selected: true,
            },
            {
                tagName: "Kitchen",
                selected: false,
            },
            {
                tagName: "Livingroom",
                selected: false,
            },
            {
                tagName: "Bathroom",
                selected: false,
            },
        ];
        this.trending = [
            {
                name: "Klippan",
                description: "2-seat sofa, grey",
                price: "$359",
                image: "~/assets/images/other-apps/furniture/sofa-klippan.png",
            },
            {
                name: "Hemlingby",
                description: "2-seat sofa, bomstad black",
                price: "$659",
                image: "~/assets/images/other-apps/furniture/sofa-hemlingby.png",
            },
            {
                name: "Klippan 2.0",
                description: "2-seat sofa, grey",
                price: "$499",
                image: "~/assets/images/other-apps/furniture/sofa-klippan.png",
            },
        ];
    }
}
FurnitureComponent.ɵfac = function FurnitureComponent_Factory(t) { return new (t || FurnitureComponent)(); };
FurnitureComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: FurnitureComponent, selectors: [["app-furniture"]], decls: 25, vars: 22, consts: [["rows", "*, 85"], ["row", "0", "rowSpan", "2", "height", "100%"], ["padding", "20 20 85 20"], ["fontSize", "30", "fontWeight", "600", "textWrap", "true", "text", "Find the perfect furniture for your home.", "marginTop", "15"], ["orientation", "horizontal", "height", "40", "width", "100%", "marginTop", "15"], ["orientation", "horizontal"], [4, "ngFor", "ngForOf"], ["fontSize", "30", "fontWeight", "600", "textWrap", "true", "text", "Trending", "marginTop", "25"], ["trendingItems", ""], ["row", "1", "columns", "*, *, *, *, *"], ["col", "0", "colSpan", "5", "columns", "*, *, *, *, *", "height", "60", "boxShadow", "0 -1 5 0 rgba(0,0,0,0.5)", "verticalAlignment", "bottom"], ["row", "0", "col", "0"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["row", "0", "col", "1"], ["row", "0", "col", "3"], ["row", "0", "col", "4"], ["tab", ""], ["row", "0", "col", "2", "background", "linear-gradient(to top right, #65adf1, #65d8f1)", "height", "70", "width", "70", "borderRadius", "35", "verticalAlignment", "top"], ["height", "40", "width", "100", "marginRight", "5", "borderWidth", "1", "borderRadius", "20", 3, "backgroundColor", "borderColor"], ["textAlignment", "center", 3, "text", "color"], ["rows", "30, 210", "marginTop", "20"], ["row", "2", "margin", "15", "boxShadow", "1 1 10 0 rgba(0,0,0,0.5)", "height", "100%", "width", "100%"], ["row", "1", "rows", "*, auto, auto, auto", "columns", "2*, *", "borderRadius", "10", "padding", "20", "backgroundColor", "#fff", "height", "100%"], ["row", "1", "col", "0", "colSpan", "2", "fontSize", "25", "fontWeight", "400", "color", "#444", 3, "text"], ["row", "2", "col", "0", "colSpan", "2", "fontSize", "17", "fontWeight", "300", "color", "#666", 3, "text"], ["row", "3", "col", "0", "fontSize", "30", "fontWeight", "600", "color", "#333", "marginTop", "10", 3, "text"], ["row", "3", "col", "1", "backgroundColor", "#F1A965", "borderRadius", "5", "padding", "10", "fontSize", "15", "fontWeight", "600", "verticalAlignment", "bottom", "text", "Add to Cart"], ["row", "0", "rowSpan", "2", "horizontalAlignment", "right", "verticalAlignment", "top", "height", "150", "width", "300", "stretch", "aspectFit", 3, "src"], ["height", "30", "width", "30", "stretch", "aspectFit", "verticalAlignment", "center", "horizontalAlignment", "center", 3, "src"]], template: function FurnitureComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "GridLayout", 0)(1, "ScrollView", 1)(2, "StackLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "Label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](4, "ScrollView", 4)(5, "StackLayout", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](6, FurnitureComponent_ng_container_6_Template, 3, 4, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](7, "Label", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](8, FurnitureComponent_ng_container_8_Template, 2, 4, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](9, FurnitureComponent_ng_template_9_Template, 8, 4, "ng-template", null, 8, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](11, "GridLayout", 9)(12, "GridLayout", 10)(13, "GridLayout", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](14, FurnitureComponent_ng_container_14_Template, 1, 0, "ng-container", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](15, "GridLayout", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](16, FurnitureComponent_ng_container_16_Template, 1, 0, "ng-container", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](17, "GridLayout", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](18, FurnitureComponent_ng_container_18_Template, 1, 0, "ng-container", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](19, "GridLayout", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](20, FurnitureComponent_ng_container_20_Template, 1, 0, "ng-container", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](21, FurnitureComponent_ng_template_21_Template, 1, 1, "ng-template", null, 16, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplateRefExtractor"]);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](23, "GridLayout", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵtemplate"](24, FurnitureComponent_ng_container_24_Template, 1, 0, "ng-container", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵreference"](22);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.tags);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngForOf", ctx.trending);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r8)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](12, _c0, ctx.tabs.home));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r8)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](14, _c0, ctx.tabs.search));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r8)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](16, _c0, ctx.tabs.likes));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r8)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](18, _c0, ctx.tabs.notifications));
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("ngTemplateOutlet", _r8)("ngTemplateOutletContext", _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵpureFunction1"](20, _c0, ctx.tabs.cart));
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgTemplateOutlet], encapsulation: 2 });


/***/ }),

/***/ "./src/app/features/other-apps/furniture/furniture.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FurnitureModule": () => (/* binding */ FurnitureModule)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _furniture_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/other-apps/furniture/furniture-routing.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



class FurnitureModule {
}
FurnitureModule.ɵfac = function FurnitureModule_Factory(t) { return new (t || FurnitureModule)(); };
FurnitureModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: FurnitureModule });
FurnitureModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptFormsModule,
        _furniture_routing_module__WEBPACK_IMPORTED_MODULE_0__.FurnitureRoutingModule] });


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2FwcF9mZWF0dXJlc19vdGhlci1hcHBzX2Z1cm5pdHVyZV9mdXJuaXR1cmVfbW9kdWxlX3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBNEY7QUFDakM7QUFDdkI7QUFDUTtBQUNyQztBQUNQO0FBQ0E7QUFDQSxtQkFBbUIsb0VBQWtCO0FBQ3JDLEtBQUs7QUFDTDtBQUNPO0FBQ1A7QUFDQSwyRUFBMkU7QUFDM0UsNENBQTRDLDhEQUFtQixHQUFHLDhCQUE4QjtBQUNoRyw0Q0FBNEMsOERBQW1CLEdBQUcsVUFBVSwyRUFBd0I7QUFDcEcsUUFBUSxvRkFBaUMsV0FBVzs7Ozs7Ozs7Ozs7Ozs7QUNmaEI7QUFDRTtBQUN0QywrREFBK0Q7QUFDL0QsSUFBSSxxRUFBMEI7QUFDOUIsSUFBSSw0REFBaUI7QUFDckIsSUFBSSx1REFBWTtBQUNoQixJQUFJLDBEQUFlO0FBQ25CLElBQUksbUVBQXdCO0FBQzVCLEVBQUU7QUFDRjtBQUNBLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDQSw4RUFBOEU7QUFDOUUsSUFBSSxnRUFBcUI7QUFDekI7QUFDQSw0QkFBNEIsU0FBUztBQUNyQywrREFBK0Q7QUFDL0QsSUFBSSxxRUFBMEI7QUFDOUIsSUFBSSx3REFBYTtBQUNqQixJQUFJLG1FQUF3QjtBQUM1QixFQUFFO0FBQ0Y7QUFDQSxJQUFJLDJEQUFnQjtBQUNwQixnQkFBZ0IseURBQWM7QUFDOUIsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhLHFEQUFxRCw2REFBa0I7QUFDeEY7QUFDQSw4REFBOEQ7QUFDOUQsSUFBSSw0REFBaUI7QUFDckIsSUFBSSx1REFBWTtBQUNoQixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksMERBQWU7QUFDbkIsSUFBSSx1REFBWTtBQUNoQixJQUFJLDBEQUFlO0FBQ25CLEVBQUU7QUFDRjtBQUNBLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakIsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQjtBQUNBLGdFQUFnRTtBQUNoRSxJQUFJLGdFQUFxQjtBQUN6QjtBQUNBLGdFQUFnRTtBQUNoRSxJQUFJLGdFQUFxQjtBQUN6QjtBQUNBLGdFQUFnRTtBQUNoRSxJQUFJLGdFQUFxQjtBQUN6QjtBQUNBLGdFQUFnRTtBQUNoRSxJQUFJLGdFQUFxQjtBQUN6QjtBQUNBLCtEQUErRDtBQUMvRCxJQUFJLHVEQUFZO0FBQ2hCLEVBQUU7QUFDRjtBQUNBLElBQUksd0RBQWE7QUFDakI7QUFDQSxnRUFBZ0U7QUFDaEUsSUFBSSxnRUFBcUI7QUFDekI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsbUVBQW1FO0FBQ25FLHdDQUF3QywrREFBb0IsR0FBRyxnNUVBQWc1RTtBQUMvOEUsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsMERBQWU7QUFDdkIsUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsd0RBQWEsNkVBQTZFLG9FQUF5QjtBQUMzSCxRQUFRLDBEQUFlO0FBQ3ZCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSwwREFBZTtBQUN2QixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsMERBQWU7QUFDdkIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx3REFBYTtBQUNyQixRQUFRLDBEQUFlO0FBQ3ZCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSwwREFBZTtBQUN2QixRQUFRLHdEQUFhLGdGQUFnRixvRUFBeUI7QUFDOUgsUUFBUSwwREFBZTtBQUN2QixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsMERBQWU7QUFDdkIsTUFBTTtBQUNOLG9CQUFvQix5REFBYztBQUNsQyxRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYSxxREFBcUQsNkRBQWtCO0FBQzVGLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYSxxREFBcUQsNkRBQWtCO0FBQzVGLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYSxxREFBcUQsNkRBQWtCO0FBQzVGLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYSxxREFBcUQsNkRBQWtCO0FBQzVGLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYSxxREFBcUQsNkRBQWtCO0FBQzVGLE9BQU8saUJBQWlCLG9EQUFVLEVBQUUsNkRBQW1CLHFCQUFxQjs7Ozs7Ozs7Ozs7Ozs7O0FDN0tlO0FBQ3ZCO0FBQ2hDO0FBQzdCO0FBQ1A7QUFDQSw2REFBNkQ7QUFDN0QscUNBQXFDLDhEQUFtQixHQUFHLHVCQUF1QjtBQUNsRixxQ0FBcUMsOERBQW1CLEdBQUcsVUFBVSwyRUFBd0I7QUFDN0YsUUFBUSwwRUFBdUI7QUFDL0IsUUFBUSw2RUFBc0IsR0FBRyIsInNvdXJjZXMiOlsid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL290aGVyLWFwcHMvZnVybml0dXJlL2Z1cm5pdHVyZS1yb3V0aW5nLm1vZHVsZS50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9mZWF0dXJlcy9vdGhlci1hcHBzL2Z1cm5pdHVyZS9mdXJuaXR1cmUuY29tcG9uZW50LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL290aGVyLWFwcHMvZnVybml0dXJlL2Z1cm5pdHVyZS5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLCBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUsIH0gZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0IHsgRnVybml0dXJlQ29tcG9uZW50IH0gZnJvbSBcIi4vZnVybml0dXJlLmNvbXBvbmVudFwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmV4cG9ydCBjb25zdCByb3V0ZXMgPSBbXG4gICAge1xuICAgICAgICBwYXRoOiBcIlwiLFxuICAgICAgICBjb21wb25lbnQ6IEZ1cm5pdHVyZUNvbXBvbmVudCxcbiAgICB9LFxuXTtcbmV4cG9ydCBjbGFzcyBGdXJuaXR1cmVSb3V0aW5nTW9kdWxlIHtcbn1cbkZ1cm5pdHVyZVJvdXRpbmdNb2R1bGUuybVmYWMgPSBmdW5jdGlvbiBGdXJuaXR1cmVSb3V0aW5nTW9kdWxlX0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IEZ1cm5pdHVyZVJvdXRpbmdNb2R1bGUpKCk7IH07XG5GdXJuaXR1cmVSb3V0aW5nTW9kdWxlLsm1bW9kID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lTmdNb2R1bGUoeyB0eXBlOiBGdXJuaXR1cmVSb3V0aW5nTW9kdWxlIH0pO1xuRnVybml0dXJlUm91dGluZ01vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW05hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcbiAgICAgICAgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLmZvckNoaWxkKHJvdXRlcyldIH0pO1xuIiwiaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfNl9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMSwgXCJDb250ZW50Vmlld1wiLCAxOCk7XG4gICAgaTAuybXJtWVsZW1lbnQoMiwgXCJMYWJlbFwiLCAxOSk7XG4gICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgdGFnX3IxMSA9IGN0eC4kaW1wbGljaXQ7XG4gICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgaTAuybXJtXByb3BlcnR5KFwiYmFja2dyb3VuZENvbG9yXCIsIHRhZ19yMTEuc2VsZWN0ZWQgPyBcIiM2NUFERjFcIiA6IFwiI2ZmZlwiKShcImJvcmRlckNvbG9yXCIsIHRhZ19yMTEuc2VsZWN0ZWQgPyBcIiM2NUFERjFcIiA6IFwiIzU1NVwiKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIHRhZ19yMTEudGFnTmFtZSkoXCJjb2xvclwiLCB0YWdfcjExLnNlbGVjdGVkID8gXCIjZmZmXCIgOiBcIiM1NTVcIik7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfOF9uZ19jb250YWluZXJfMV9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lcigwKTtcbn0gfVxuY29uc3QgX2MwID0gZnVuY3Rpb24gKGEwKSB7IHJldHVybiB7ICRpbXBsaWNpdDogYTAgfTsgfTtcbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfOF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybV0ZW1wbGF0ZSgxLCBGdXJuaXR1cmVDb21wb25lbnRfbmdfY29udGFpbmVyXzhfbmdfY29udGFpbmVyXzFfVGVtcGxhdGUsIDEsIDAsIFwibmctY29udGFpbmVyXCIsIDEyKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgdHJlbmRpbmdJdGVtX3IxMiA9IGN0eC4kaW1wbGljaXQ7XG4gICAgaTAuybXJtW5leHRDb250ZXh0KCk7XG4gICAgY29uc3QgX3IyID0gaTAuybXJtXJlZmVyZW5jZSgxMCk7XG4gICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgaTAuybXJtXByb3BlcnR5KFwibmdUZW1wbGF0ZU91dGxldFwiLCBfcjIpKFwibmdUZW1wbGF0ZU91dGxldENvbnRleHRcIiwgaTAuybXJtXB1cmVGdW5jdGlvbjEoMiwgX2MwLCB0cmVuZGluZ0l0ZW1fcjEyKSk7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ190ZW1wbGF0ZV85X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJHcmlkTGF5b3V0XCIsIDIwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgxLCBcIkNvbnRlbnRWaWV3XCIsIDIxKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDIsIFwiR3JpZExheW91dFwiLCAyMik7XG4gICAgaTAuybXJtWVsZW1lbnQoMywgXCJMYWJlbFwiLCAyMykoNCwgXCJMYWJlbFwiLCAyNCkoNSwgXCJMYWJlbFwiLCAyNSkoNiwgXCJCdXR0b25cIiwgMjYpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnQoNywgXCJJbWFnZVwiLCAyNyk7XG4gICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGl0ZW1fcjE0ID0gY3R4LiRpbXBsaWNpdDtcbiAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGl0ZW1fcjE0Lm5hbWUpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgaXRlbV9yMTQuZGVzY3JpcHRpb24pO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgaXRlbV9yMTQucHJpY2UpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInNyY1wiLCBpdGVtX3IxNC5pbWFnZSk7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfMTRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXIoMCk7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfMTZfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXIoMCk7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfMThfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXIoMCk7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfMjBfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXIoMCk7XG59IH1cbmZ1bmN0aW9uIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ190ZW1wbGF0ZV8yMV9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudCgwLCBcIkltYWdlXCIsIDI4KTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IHRhYl9yMTUgPSBjdHguJGltcGxpY2l0O1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInNyY1wiLCB0YWJfcjE1LnRhYkltYWdlKTtcbn0gfVxuZnVuY3Rpb24gRnVybml0dXJlQ29tcG9uZW50X25nX2NvbnRhaW5lcl8yNF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lcigwKTtcbn0gfVxuZXhwb3J0IGNsYXNzIEZ1cm5pdHVyZUNvbXBvbmVudCB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHRoaXMudGFicyA9IHtcbiAgICAgICAgICAgIGhvbWU6IHtcbiAgICAgICAgICAgICAgICB0YWJJbWFnZTogXCJ+L2Fzc2V0cy9pbWFnZXMvb3RoZXItYXBwcy9mdXJuaXR1cmUvaG91c2UucG5nXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2VhcmNoOiB7XG4gICAgICAgICAgICAgICAgdGFiSW1hZ2U6IFwifi9hc3NldHMvaW1hZ2VzL290aGVyLWFwcHMvZnVybml0dXJlL3NlYXJjaC5wbmdcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjYXJ0OiB7XG4gICAgICAgICAgICAgICAgdGFiSW1hZ2U6IFwifi9hc3NldHMvaW1hZ2VzL290aGVyLWFwcHMvZnVybml0dXJlL3Nob3BwaW5nLWNhcnQucG5nXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbGlrZXM6IHtcbiAgICAgICAgICAgICAgICB0YWJJbWFnZTogXCJ+L2Fzc2V0cy9pbWFnZXMvb3RoZXItYXBwcy9mdXJuaXR1cmUvaGVhcnRzLnBuZ1wiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbnM6IHtcbiAgICAgICAgICAgICAgICB0YWJJbWFnZTogXCJ+L2Fzc2V0cy9pbWFnZXMvb3RoZXItYXBwcy9mdXJuaXR1cmUvbm90aWZpY2F0aW9uLnBuZ1wiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy50YWdzID0gW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRhZ05hbWU6IFwiQmVkcm9vbVwiLFxuICAgICAgICAgICAgICAgIHNlbGVjdGVkOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0YWdOYW1lOiBcIktpdGNoZW5cIixcbiAgICAgICAgICAgICAgICBzZWxlY3RlZDogZmFsc2UsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRhZ05hbWU6IFwiTGl2aW5ncm9vbVwiLFxuICAgICAgICAgICAgICAgIHNlbGVjdGVkOiBmYWxzZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGFnTmFtZTogXCJCYXRocm9vbVwiLFxuICAgICAgICAgICAgICAgIHNlbGVjdGVkOiBmYWxzZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF07XG4gICAgICAgIHRoaXMudHJlbmRpbmcgPSBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJLbGlwcGFuXCIsXG4gICAgICAgICAgICAgICAgZGVzY3JpcHRpb246IFwiMi1zZWF0IHNvZmEsIGdyZXlcIixcbiAgICAgICAgICAgICAgICBwcmljZTogXCIkMzU5XCIsXG4gICAgICAgICAgICAgICAgaW1hZ2U6IFwifi9hc3NldHMvaW1hZ2VzL290aGVyLWFwcHMvZnVybml0dXJlL3NvZmEta2xpcHBhbi5wbmdcIixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJIZW1saW5nYnlcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCIyLXNlYXQgc29mYSwgYm9tc3RhZCBibGFja1wiLFxuICAgICAgICAgICAgICAgIHByaWNlOiBcIiQ2NTlcIixcbiAgICAgICAgICAgICAgICBpbWFnZTogXCJ+L2Fzc2V0cy9pbWFnZXMvb3RoZXItYXBwcy9mdXJuaXR1cmUvc29mYS1oZW1saW5nYnkucG5nXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIG5hbWU6IFwiS2xpcHBhbiAyLjBcIixcbiAgICAgICAgICAgICAgICBkZXNjcmlwdGlvbjogXCIyLXNlYXQgc29mYSwgZ3JleVwiLFxuICAgICAgICAgICAgICAgIHByaWNlOiBcIiQ0OTlcIixcbiAgICAgICAgICAgICAgICBpbWFnZTogXCJ+L2Fzc2V0cy9pbWFnZXMvb3RoZXItYXBwcy9mdXJuaXR1cmUvc29mYS1rbGlwcGFuLnBuZ1wiLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXTtcbiAgICB9XG59XG5GdXJuaXR1cmVDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBGdXJuaXR1cmVDb21wb25lbnRfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgRnVybml0dXJlQ29tcG9uZW50KSgpOyB9O1xuRnVybml0dXJlQ29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogRnVybml0dXJlQ29tcG9uZW50LCBzZWxlY3RvcnM6IFtbXCJhcHAtZnVybml0dXJlXCJdXSwgZGVjbHM6IDI1LCB2YXJzOiAyMiwgY29uc3RzOiBbW1wicm93c1wiLCBcIiosIDg1XCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwicm93U3BhblwiLCBcIjJcIiwgXCJoZWlnaHRcIiwgXCIxMDAlXCJdLCBbXCJwYWRkaW5nXCIsIFwiMjAgMjAgODUgMjBcIl0sIFtcImZvbnRTaXplXCIsIFwiMzBcIiwgXCJmb250V2VpZ2h0XCIsIFwiNjAwXCIsIFwidGV4dFdyYXBcIiwgXCJ0cnVlXCIsIFwidGV4dFwiLCBcIkZpbmQgdGhlIHBlcmZlY3QgZnVybml0dXJlIGZvciB5b3VyIGhvbWUuXCIsIFwibWFyZ2luVG9wXCIsIFwiMTVcIl0sIFtcIm9yaWVudGF0aW9uXCIsIFwiaG9yaXpvbnRhbFwiLCBcImhlaWdodFwiLCBcIjQwXCIsIFwid2lkdGhcIiwgXCIxMDAlXCIsIFwibWFyZ2luVG9wXCIsIFwiMTVcIl0sIFtcIm9yaWVudGF0aW9uXCIsIFwiaG9yaXpvbnRhbFwiXSwgWzQsIFwibmdGb3JcIiwgXCJuZ0Zvck9mXCJdLCBbXCJmb250U2l6ZVwiLCBcIjMwXCIsIFwiZm9udFdlaWdodFwiLCBcIjYwMFwiLCBcInRleHRXcmFwXCIsIFwidHJ1ZVwiLCBcInRleHRcIiwgXCJUcmVuZGluZ1wiLCBcIm1hcmdpblRvcFwiLCBcIjI1XCJdLCBbXCJ0cmVuZGluZ0l0ZW1zXCIsIFwiXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwiY29sdW1uc1wiLCBcIiosICosICosICosICpcIl0sIFtcImNvbFwiLCBcIjBcIiwgXCJjb2xTcGFuXCIsIFwiNVwiLCBcImNvbHVtbnNcIiwgXCIqLCAqLCAqLCAqLCAqXCIsIFwiaGVpZ2h0XCIsIFwiNjBcIiwgXCJib3hTaGFkb3dcIiwgXCIwIC0xIDUgMCByZ2JhKDAsMCwwLDAuNSlcIiwgXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImJvdHRvbVwiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjBcIl0sIFs0LCBcIm5nVGVtcGxhdGVPdXRsZXRcIiwgXCJuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dFwiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjFcIl0sIFtcInJvd1wiLCBcIjBcIiwgXCJjb2xcIiwgXCIzXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiNFwiXSwgW1widGFiXCIsIFwiXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiMlwiLCBcImJhY2tncm91bmRcIiwgXCJsaW5lYXItZ3JhZGllbnQodG8gdG9wIHJpZ2h0LCAjNjVhZGYxLCAjNjVkOGYxKVwiLCBcImhlaWdodFwiLCBcIjcwXCIsIFwid2lkdGhcIiwgXCI3MFwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjM1XCIsIFwidmVydGljYWxBbGlnbm1lbnRcIiwgXCJ0b3BcIl0sIFtcImhlaWdodFwiLCBcIjQwXCIsIFwid2lkdGhcIiwgXCIxMDBcIiwgXCJtYXJnaW5SaWdodFwiLCBcIjVcIiwgXCJib3JkZXJXaWR0aFwiLCBcIjFcIiwgXCJib3JkZXJSYWRpdXNcIiwgXCIyMFwiLCAzLCBcImJhY2tncm91bmRDb2xvclwiLCBcImJvcmRlckNvbG9yXCJdLCBbXCJ0ZXh0QWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIDMsIFwidGV4dFwiLCBcImNvbG9yXCJdLCBbXCJyb3dzXCIsIFwiMzAsIDIxMFwiLCBcIm1hcmdpblRvcFwiLCBcIjIwXCJdLCBbXCJyb3dcIiwgXCIyXCIsIFwibWFyZ2luXCIsIFwiMTVcIiwgXCJib3hTaGFkb3dcIiwgXCIxIDEgMTAgMCByZ2JhKDAsMCwwLDAuNSlcIiwgXCJoZWlnaHRcIiwgXCIxMDAlXCIsIFwid2lkdGhcIiwgXCIxMDAlXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwicm93c1wiLCBcIiosIGF1dG8sIGF1dG8sIGF1dG9cIiwgXCJjb2x1bW5zXCIsIFwiMiosICpcIiwgXCJib3JkZXJSYWRpdXNcIiwgXCIxMFwiLCBcInBhZGRpbmdcIiwgXCIyMFwiLCBcImJhY2tncm91bmRDb2xvclwiLCBcIiNmZmZcIiwgXCJoZWlnaHRcIiwgXCIxMDAlXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwiY29sXCIsIFwiMFwiLCBcImNvbFNwYW5cIiwgXCIyXCIsIFwiZm9udFNpemVcIiwgXCIyNVwiLCBcImZvbnRXZWlnaHRcIiwgXCI0MDBcIiwgXCJjb2xvclwiLCBcIiM0NDRcIiwgMywgXCJ0ZXh0XCJdLCBbXCJyb3dcIiwgXCIyXCIsIFwiY29sXCIsIFwiMFwiLCBcImNvbFNwYW5cIiwgXCIyXCIsIFwiZm9udFNpemVcIiwgXCIxN1wiLCBcImZvbnRXZWlnaHRcIiwgXCIzMDBcIiwgXCJjb2xvclwiLCBcIiM2NjZcIiwgMywgXCJ0ZXh0XCJdLCBbXCJyb3dcIiwgXCIzXCIsIFwiY29sXCIsIFwiMFwiLCBcImZvbnRTaXplXCIsIFwiMzBcIiwgXCJmb250V2VpZ2h0XCIsIFwiNjAwXCIsIFwiY29sb3JcIiwgXCIjMzMzXCIsIFwibWFyZ2luVG9wXCIsIFwiMTBcIiwgMywgXCJ0ZXh0XCJdLCBbXCJyb3dcIiwgXCIzXCIsIFwiY29sXCIsIFwiMVwiLCBcImJhY2tncm91bmRDb2xvclwiLCBcIiNGMUE5NjVcIiwgXCJib3JkZXJSYWRpdXNcIiwgXCI1XCIsIFwicGFkZGluZ1wiLCBcIjEwXCIsIFwiZm9udFNpemVcIiwgXCIxNVwiLCBcImZvbnRXZWlnaHRcIiwgXCI2MDBcIiwgXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImJvdHRvbVwiLCBcInRleHRcIiwgXCJBZGQgdG8gQ2FydFwiXSwgW1wicm93XCIsIFwiMFwiLCBcInJvd1NwYW5cIiwgXCIyXCIsIFwiaG9yaXpvbnRhbEFsaWdubWVudFwiLCBcInJpZ2h0XCIsIFwidmVydGljYWxBbGlnbm1lbnRcIiwgXCJ0b3BcIiwgXCJoZWlnaHRcIiwgXCIxNTBcIiwgXCJ3aWR0aFwiLCBcIjMwMFwiLCBcInN0cmV0Y2hcIiwgXCJhc3BlY3RGaXRcIiwgMywgXCJzcmNcIl0sIFtcImhlaWdodFwiLCBcIjMwXCIsIFwid2lkdGhcIiwgXCIzMFwiLCBcInN0cmV0Y2hcIiwgXCJhc3BlY3RGaXRcIiwgXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCBcImhvcml6b250YWxBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgMywgXCJzcmNcIl1dLCB0ZW1wbGF0ZTogZnVuY3Rpb24gRnVybml0dXJlQ29tcG9uZW50X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDAsIFwiR3JpZExheW91dFwiLCAwKSgxLCBcIlNjcm9sbFZpZXdcIiwgMSkoMiwgXCJTdGFja0xheW91dFwiLCAyKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMywgXCJMYWJlbFwiLCAzKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCg0LCBcIlNjcm9sbFZpZXdcIiwgNCkoNSwgXCJTdGFja0xheW91dFwiLCA1KTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDYsIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfNl9UZW1wbGF0ZSwgMywgNCwgXCJuZy1jb250YWluZXJcIiwgNik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoNywgXCJMYWJlbFwiLCA3KTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDgsIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfOF9UZW1wbGF0ZSwgMiwgNCwgXCJuZy1jb250YWluZXJcIiwgNik7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSg5LCBGdXJuaXR1cmVDb21wb25lbnRfbmdfdGVtcGxhdGVfOV9UZW1wbGF0ZSwgOCwgNCwgXCJuZy10ZW1wbGF0ZVwiLCBudWxsLCA4LCBpMC7Jtcm1dGVtcGxhdGVSZWZFeHRyYWN0b3IpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMTEsIFwiR3JpZExheW91dFwiLCA5KSgxMiwgXCJHcmlkTGF5b3V0XCIsIDEwKSgxMywgXCJHcmlkTGF5b3V0XCIsIDExKTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDE0LCBGdXJuaXR1cmVDb21wb25lbnRfbmdfY29udGFpbmVyXzE0X1RlbXBsYXRlLCAxLCAwLCBcIm5nLWNvbnRhaW5lclwiLCAxMik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMTUsIFwiR3JpZExheW91dFwiLCAxMyk7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSgxNiwgRnVybml0dXJlQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xNl9UZW1wbGF0ZSwgMSwgMCwgXCJuZy1jb250YWluZXJcIiwgMTIpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDE3LCBcIkdyaWRMYXlvdXRcIiwgMTQpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoMTgsIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfMThfVGVtcGxhdGUsIDEsIDAsIFwibmctY29udGFpbmVyXCIsIDEyKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgxOSwgXCJHcmlkTGF5b3V0XCIsIDE1KTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDIwLCBGdXJuaXR1cmVDb21wb25lbnRfbmdfY29udGFpbmVyXzIwX1RlbXBsYXRlLCAxLCAwLCBcIm5nLWNvbnRhaW5lclwiLCAxMik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSgyMSwgRnVybml0dXJlQ29tcG9uZW50X25nX3RlbXBsYXRlXzIxX1RlbXBsYXRlLCAxLCAxLCBcIm5nLXRlbXBsYXRlXCIsIG51bGwsIDE2LCBpMC7Jtcm1dGVtcGxhdGVSZWZFeHRyYWN0b3IpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDIzLCBcIkdyaWRMYXlvdXRcIiwgMTcpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoMjQsIEZ1cm5pdHVyZUNvbXBvbmVudF9uZ19jb250YWluZXJfMjRfVGVtcGxhdGUsIDEsIDAsIFwibmctY29udGFpbmVyXCIsIDEyKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKSgpKCk7XG4gICAgfSBpZiAocmYgJiAyKSB7XG4gICAgICAgIGNvbnN0IF9yOCA9IGkwLsm1ybVyZWZlcmVuY2UoMjIpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSg2KTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdGb3JPZlwiLCBjdHgudGFncyk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ0Zvck9mXCIsIGN0eC50cmVuZGluZyk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDYpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ1RlbXBsYXRlT3V0bGV0XCIsIF9yOCkoXCJuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dFwiLCBpMC7Jtcm1cHVyZUZ1bmN0aW9uMSgxMiwgX2MwLCBjdHgudGFicy5ob21lKSk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ1RlbXBsYXRlT3V0bGV0XCIsIF9yOCkoXCJuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dFwiLCBpMC7Jtcm1cHVyZUZ1bmN0aW9uMSgxNCwgX2MwLCBjdHgudGFicy5zZWFyY2gpKTtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nVGVtcGxhdGVPdXRsZXRcIiwgX3I4KShcIm5nVGVtcGxhdGVPdXRsZXRDb250ZXh0XCIsIGkwLsm1ybVwdXJlRnVuY3Rpb24xKDE2LCBfYzAsIGN0eC50YWJzLmxpa2VzKSk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ1RlbXBsYXRlT3V0bGV0XCIsIF9yOCkoXCJuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dFwiLCBpMC7Jtcm1cHVyZUZ1bmN0aW9uMSgxOCwgX2MwLCBjdHgudGFicy5ub3RpZmljYXRpb25zKSk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDQpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ1RlbXBsYXRlT3V0bGV0XCIsIF9yOCkoXCJuZ1RlbXBsYXRlT3V0bGV0Q29udGV4dFwiLCBpMC7Jtcm1cHVyZUZ1bmN0aW9uMSgyMCwgX2MwLCBjdHgudGFicy5jYXJ0KSk7XG4gICAgfSB9LCBkZXBlbmRlbmNpZXM6IFtpMS5OZ0Zvck9mLCBpMS5OZ1RlbXBsYXRlT3V0bGV0XSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCB7IE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSwgTmF0aXZlU2NyaXB0Rm9ybXNNb2R1bGUsIH0gZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0IHsgRnVybml0dXJlUm91dGluZ01vZHVsZSB9IGZyb20gXCIuL2Z1cm5pdHVyZS1yb3V0aW5nLm1vZHVsZVwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmV4cG9ydCBjbGFzcyBGdXJuaXR1cmVNb2R1bGUge1xufVxuRnVybml0dXJlTW9kdWxlLsm1ZmFjID0gZnVuY3Rpb24gRnVybml0dXJlTW9kdWxlX0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IEZ1cm5pdHVyZU1vZHVsZSkoKTsgfTtcbkZ1cm5pdHVyZU1vZHVsZS7JtW1vZCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZU5nTW9kdWxlKHsgdHlwZTogRnVybml0dXJlTW9kdWxlIH0pO1xuRnVybml0dXJlTW9kdWxlLsm1aW5qID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lSW5qZWN0b3IoeyBpbXBvcnRzOiBbTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLFxuICAgICAgICBOYXRpdmVTY3JpcHRGb3Jtc01vZHVsZSxcbiAgICAgICAgRnVybml0dXJlUm91dGluZ01vZHVsZV0gfSk7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=