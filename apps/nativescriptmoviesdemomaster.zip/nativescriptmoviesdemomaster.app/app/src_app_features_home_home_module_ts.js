"use strict";
exports.id = "src_app_features_home_home_module_ts";
exports.ids = ["src_app_features_home_home_module_ts"];
exports.modules = {

/***/ "./src/app/features/home/home-routing.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeRoutingModule": () => (/* binding */ HomeRoutingModule),
/* harmony export */   "routes": () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _home_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/home/home.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");




const routes = [
    {
        path: "",
        component: _home_component__WEBPACK_IMPORTED_MODULE_0__.HomeComponent,
    },
];
class HomeRoutingModule {
}
HomeRoutingModule.ɵfac = function HomeRoutingModule_Factory(t) { return new (t || HomeRoutingModule)(); };
HomeRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: HomeRoutingModule });
HomeRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptRouterModule.forChild(routes)] });


/***/ }),

/***/ "./src/app/features/home/home.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeComponent": () => (/* binding */ HomeComponent)
/* harmony export */ });
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/@nativescript/core/platform/index.ios.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@ngxs/store/__ivy_ngcc__/fesm5/ngxs-store.js");
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/@nativescript/core/ui/page/index.ios.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _shared_components_cards_thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/cards/thumbnail-card/thumbnail-card.component.ts");
/* harmony import */ var _shared_components_header_header_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/shared/components/header/header.component.ts");










function HomeComponent_ng_container_6_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ContentView", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
}

function HomeComponent_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r7 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "GridLayout", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "Image", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, HomeComponent_ng_container_6_ng_container_3_Template, 2, 0, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "StackLayout", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](5, "Label", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "Label", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "Button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("tap", function HomeComponent_ng_container_6_Template_Button_tap_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r7);
      const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r6.openAlertPopup());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](9, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const featured_r4 = ctx.ngIf;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    let tmp_4_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", featured_r4.image.cover);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", featured_r4.tinted);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](6, 6, featured_r4.title));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", featured_r4.description.slice(0, 100) + "...");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", ((tmp_4_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](9, 8, ctx_r0.staticText$)) == null ? null : tmp_4_0.home == null ? null : tmp_4_0.home.buttons == null ? null : tmp_4_0.home.buttons.heroCta) || "PLAY NOW")("padding", ctx_r0.ios ? "15 0" : "5 0 0 0");
  }
}

function HomeComponent_Label_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "Label", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](1, "async");
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    let tmp_0_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", ((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](1, 1, ctx_r1.staticText$)) == null ? null : tmp_0_0.sectionTitle == null ? null : tmp_0_0.sectionTitle.categories) || "Categories");
  }
}

function HomeComponent_ng_container_9_ng_container_3_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ContentView", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }
}

function HomeComponent_ng_container_9_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "GridLayout", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "Image", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, HomeComponent_ng_container_9_ng_container_3_ng_container_3_Template, 2, 0, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](4, "Label", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "uppercase");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const category_r10 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("src", category_r10.image);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", category_r10.tinted);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](5, 3, category_r10.displayName));
  }
}

function HomeComponent_ng_container_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ScrollView", 15)(2, "StackLayout", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](3, HomeComponent_ng_container_9_ng_container_3_Template, 6, 5, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const categories_r8 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", categories_r8);
  }
}

function HomeComponent_ng_container_11_Label_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "Label", 14);
  }

  if (rf & 2) {
    const group_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]().$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("text", group_r12.displayName);
  }
}

function HomeComponent_ng_container_11_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r18 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](1, "ContentView", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("tap", function HomeComponent_ng_container_11_ng_container_4_Template_ContentView_tap_1_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵrestoreView"](_r18);
      const product_r16 = restoredCtx.$implicit;
      const ctx_r17 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵresetView"](ctx_r17.openProductDetails(product_r16.id));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "ns-thumbnail-card", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const product_r16 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("testID", product_r16.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("imageSrc", product_r16.image.thumbnail);
  }
}

function HomeComponent_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](1, HomeComponent_ng_container_11_Label_1_Template, 1, 1, "Label", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "ScrollView", 15)(3, "StackLayout", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](4, HomeComponent_ng_container_11_ng_container_4_Template, 3, 2, "ng-container", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const group_r12 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", true);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", group_r12.products);
  }
}

class HomeComponent {
  constructor(page, layersService) {
    this.page = page;
    this.layersService = layersService;
    this.ios = _nativescript_core__WEBPACK_IMPORTED_MODULE_5__.isIOS;
    this.headerRightActionButton = {
      icon: _app_core__WEBPACK_IMPORTED_MODULE_1__.Icons.search,
      onTap: () => this.layersService.openSearchBottomsheet()
    };
    this.page.actionBarHidden = true;
  }

  openProductDetails(id) {
    this.layersService.openQuickviewBottomsheet(id);
  }

  openAlertPopup() {
    this.layersService.openAlertPopup();
  }

}

HomeComponent.ɵfac = function HomeComponent_Factory(t) {
  return new (t || HomeComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_nativescript_core__WEBPACK_IMPORTED_MODULE_6__.Page), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_1__.LayersService));
};

HomeComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: HomeComponent,
  selectors: [["ns-home"]],
  decls: 13,
  vars: 15,
  consts: [["rows", "auto, *"], ["row", "0"], ["hasMenuButton", "true", 3, "headerTitle", "rightActionButton"], ["row", "1", "height", "100%", "iosOverflowSafeAreaEnabled", "false"], [4, "ngIf"], ["class", "bold font-size-h3", "margin", "20 20 0 20", 3, "text", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["height", "250", "rows", "*", "columns", "*", 1, "glow-shadow"], ["row", "0", "col", "0", "height", "100%", "width", "100%", "stretch", "aspectFill", 3, "src"], ["row", "0", "col", "0", "verticalAlignment", "bottom", "horizontalAlignment", "left", "width", "75%", "padding", "20"], ["fontSize", "20", "color", "#fff", 1, "bold", 3, "text"], ["fontSize", "15", "color", "#ddd", "marginTop", "7", "textWrap", "true", 3, "text"], ["marginTop", "20", "horizontalAlignment", "left", "width", "150", "color", "#fff", "fontSize", "14", "testID", "playNowButton", 1, "bg-color-primary", "bold", "glow-shadow", 3, "text", "padding", "tap"], ["backgroundColor", "#666666", "opacity", "0.7", "row", "0", "col", "0", "height", "100%", "width", "100%"], ["margin", "20 20 0 20", 1, "bold", "font-size-h3", 3, "text"], ["orientation", "horizontal", "scrollBarIndicatorVisible", "false"], ["orientation", "horizontal", "padding", "10 20"], ["height", "80", "width", "160", "rows", "*", "columns", "*", "marginRight", "10", 1, "glow-shadow"], ["stretch", "aspectFill", 3, "src"], [1, "v-center", "text-color-light", "bold", "text-center", "font-size-h3", 3, "text"], ["opacity", "0.7", 1, "bg-color-primary"], ["verticalAlignment", "bottom", 3, "testID", "tap"], [3, "imageSrc"]],
  template: function HomeComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "GridLayout", 0)(1, "ContentView", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](2, "ns-header", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ScrollView", 3)(5, "StackLayout");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](6, HomeComponent_ng_container_6_Template, 10, 10, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](7, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, HomeComponent_Label_8_Template, 2, 3, "Label", 5);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](9, HomeComponent_ng_container_9_Template, 4, 1, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](11, HomeComponent_ng_container_11_Template, 5, 2, "ng-container", 6);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](12, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    }

    if (rf & 2) {
      let tmp_0_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("headerTitle", ((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](3, 7, ctx.staticText$)) == null ? null : tmp_0_0.mainHeaderTitle) || "MOVIES")("rightActionButton", ctx.headerRightActionButton);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@slideUpFadeStagger", undefined);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](7, 9, ctx.featuredProduct$));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", true);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 11, ctx.categories$));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](12, 13, ctx.productGroups$));
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _shared_components_cards_thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_2__.ThumbnailCardComponent, _shared_components_header_header_component__WEBPACK_IMPORTED_MODULE_3__.HeaderComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe, _angular_common__WEBPACK_IMPORTED_MODULE_7__.UpperCasePipe],
  encapsulation: 2,
  data: {
    animation: [_app_core__WEBPACK_IMPORTED_MODULE_1__.SlideUpFadeStagger]
  }
});

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ConfigState.staticText), __metadata("design:type", Object)], HomeComponent.prototype, "staticText$", void 0);

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ProductState.categories), __metadata("design:type", Object)], HomeComponent.prototype, "categories$", void 0);

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ProductState.productGroups), __metadata("design:type", Object)], HomeComponent.prototype, "productGroups$", void 0);

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ProductState.featuredProduct), __metadata("design:type", Object)], HomeComponent.prototype, "featuredProduct$", void 0);

/***/ }),

/***/ "./src/app/features/home/home.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeModule": () => (/* binding */ HomeModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _app_shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/index.ts");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/features/home/home-routing.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");





class HomeModule {
}
HomeModule.ɵfac = function HomeModule_Factory(t) { return new (t || HomeModule)(); };
HomeModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: HomeModule });
HomeModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_3__.NativeScriptCommonModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomeRoutingModule,
        _app_shared__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2FwcF9mZWF0dXJlc19ob21lX2hvbWVfbW9kdWxlX3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBNEY7QUFDM0M7QUFDYjtBQUNRO0FBQ3JDO0FBQ1A7QUFDQTtBQUNBLG1CQUFtQiwwREFBYTtBQUNoQyxLQUFLO0FBQ0w7QUFDTztBQUNQO0FBQ0EsaUVBQWlFO0FBQ2pFLHVDQUF1Qyw4REFBbUIsR0FBRyx5QkFBeUI7QUFDdEYsdUNBQXVDLDhEQUFtQixHQUFHLFVBQVUsMkVBQXdCO0FBQy9GLFFBQVEsb0ZBQWlDLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZnBEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTYyxvREFBVCxDQUE4REMsRUFBOUQsRUFBa0VDLEdBQWxFLEVBQXVFO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNqRlAscUVBQUEsQ0FBMkIsQ0FBM0I7SUFDQUEsdURBQUEsQ0FBYSxDQUFiLEVBQWdCLGFBQWhCLEVBQStCLEVBQS9CO0lBQ0FBLG1FQUFBO0VBQ0g7QUFBRTs7QUFDSCxTQUFTWSxxQ0FBVCxDQUErQ0wsRUFBL0MsRUFBbURDLEdBQW5ELEVBQXdEO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNsRSxNQUFNTSxHQUFHLEdBQUdiLDhEQUFBLEVBQVo7O0lBQ0FBLHFFQUFBLENBQTJCLENBQTNCO0lBQ0FBLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLFlBQXJCLEVBQW1DLENBQW5DO0lBQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixPQUFoQixFQUF5QixDQUF6QjtJQUNBQSx3REFBQSxDQUFjLENBQWQsRUFBaUJNLG9EQUFqQixFQUF1RSxDQUF2RSxFQUEwRSxDQUExRSxFQUE2RSxjQUE3RSxFQUE2RixDQUE3RjtJQUNBTiw0REFBQSxDQUFrQixDQUFsQixFQUFxQixhQUFyQixFQUFvQyxDQUFwQztJQUNBQSx1REFBQSxDQUFhLENBQWIsRUFBZ0IsT0FBaEIsRUFBeUIsRUFBekI7SUFDQUEsb0RBQUEsQ0FBVSxDQUFWLEVBQWEsV0FBYjtJQUNBQSx1REFBQSxDQUFhLENBQWIsRUFBZ0IsT0FBaEIsRUFBeUIsRUFBekI7SUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsUUFBckIsRUFBK0IsRUFBL0I7SUFDQUEsd0RBQUEsQ0FBYyxLQUFkLEVBQXFCLFNBQVNtQiwyREFBVCxHQUF1RTtNQUFFbkIsMkRBQUEsQ0FBaUJhLEdBQWpCO01BQXVCLE1BQU1RLE1BQU0sR0FBR3JCLDJEQUFBLEVBQWY7TUFBbUMsT0FBT0EseURBQUEsQ0FBZXFCLE1BQU0sQ0FBQ0csY0FBUCxFQUFmLENBQVA7SUFBaUQsQ0FBek07SUFDQXhCLG9EQUFBLENBQVUsQ0FBVixFQUFhLE9BQWI7SUFDQUEsMERBQUE7SUFDQUEsbUVBQUE7RUFDSDs7RUFBQyxJQUFJTyxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ1YsTUFBTW1CLFdBQVcsR0FBR2xCLEdBQUcsQ0FBQ21CLElBQXhCO0lBQ0EsTUFBTUMsTUFBTSxHQUFHNUIsMkRBQUEsRUFBZjtJQUNBLElBQUk2QixPQUFKO0lBQ0E3Qix1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxLQUFkLEVBQXFCMEIsV0FBVyxDQUFDTSxLQUFaLENBQWtCQyxLQUF2QztJQUNBakMsdURBQUEsQ0FBYSxDQUFiO0lBQ0FBLHdEQUFBLENBQWMsTUFBZCxFQUFzQjBCLFdBQVcsQ0FBQ1EsTUFBbEM7SUFDQWxDLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0JBLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQjBCLFdBQVcsQ0FBQ1UsS0FBakMsQ0FBdEI7SUFDQXBDLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0IwQixXQUFXLENBQUNXLFdBQVosQ0FBd0JDLEtBQXhCLENBQThCLENBQTlCLEVBQWlDLEdBQWpDLElBQXdDLEtBQTlEO0lBQ0F0Qyx1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCLENBQUMsQ0FBQzZCLE9BQU8sR0FBRzdCLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQjRCLE1BQU0sQ0FBQ1csV0FBNUIsQ0FBWCxLQUF3RCxJQUF4RCxHQUErRCxJQUEvRCxHQUFzRVYsT0FBTyxDQUFDVyxJQUFSLElBQWdCLElBQWhCLEdBQXVCLElBQXZCLEdBQThCWCxPQUFPLENBQUNXLElBQVIsQ0FBYUMsT0FBYixJQUF3QixJQUF4QixHQUErQixJQUEvQixHQUFzQ1osT0FBTyxDQUFDVyxJQUFSLENBQWFDLE9BQWIsQ0FBcUJDLE9BQWhLLEtBQTRLLFVBQWxNLEVBQThNLFNBQTlNLEVBQXlOZCxNQUFNLENBQUNlLEdBQVAsR0FBYSxNQUFiLEdBQXNCLFNBQS9PO0VBQ0g7QUFBRTs7QUFDSCxTQUFTQyw4QkFBVCxDQUF3Q3JDLEVBQXhDLEVBQTRDQyxHQUE1QyxFQUFpRDtFQUFFLElBQUlELEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDM0RQLHVEQUFBLENBQWEsQ0FBYixFQUFnQixPQUFoQixFQUF5QixFQUF6QjtJQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO0VBQ0g7O0VBQUMsSUFBSU8sRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNWLE1BQU1zQyxNQUFNLEdBQUc3QywyREFBQSxFQUFmO0lBQ0EsSUFBSThDLE9BQUo7SUFDQTlDLHdEQUFBLENBQWMsTUFBZCxFQUFzQixDQUFDLENBQUM4QyxPQUFPLEdBQUc5Qyx5REFBQSxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUI2QyxNQUFNLENBQUNOLFdBQTVCLENBQVgsS0FBd0QsSUFBeEQsR0FBK0QsSUFBL0QsR0FBc0VPLE9BQU8sQ0FBQ0MsWUFBUixJQUF3QixJQUF4QixHQUErQixJQUEvQixHQUFzQ0QsT0FBTyxDQUFDQyxZQUFSLENBQXFCQyxVQUFsSSxLQUFpSixZQUF2SztFQUNIO0FBQUU7O0FBQ0gsU0FBU0MsbUVBQVQsQ0FBNkUxQyxFQUE3RSxFQUFpRkMsR0FBakYsRUFBc0Y7RUFBRSxJQUFJRCxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ2hHUCxxRUFBQSxDQUEyQixDQUEzQjtJQUNBQSx1REFBQSxDQUFhLENBQWIsRUFBZ0IsYUFBaEIsRUFBK0IsRUFBL0I7SUFDQUEsbUVBQUE7RUFDSDtBQUFFOztBQUNILFNBQVNrRCxvREFBVCxDQUE4RDNDLEVBQTlELEVBQWtFQyxHQUFsRSxFQUF1RTtFQUFFLElBQUlELEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDakZQLHFFQUFBLENBQTJCLENBQTNCO0lBQ0FBLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLFlBQXJCLEVBQW1DLEVBQW5DO0lBQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixPQUFoQixFQUF5QixFQUF6QjtJQUNBQSx3REFBQSxDQUFjLENBQWQsRUFBaUJpRCxtRUFBakIsRUFBc0YsQ0FBdEYsRUFBeUYsQ0FBekYsRUFBNEYsY0FBNUYsRUFBNEcsQ0FBNUc7SUFDQWpELHVEQUFBLENBQWEsQ0FBYixFQUFnQixPQUFoQixFQUF5QixFQUF6QjtJQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxXQUFiO0lBQ0FBLDBEQUFBO0lBQ0FBLG1FQUFBO0VBQ0g7O0VBQUMsSUFBSU8sRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNWLE1BQU00QyxZQUFZLEdBQUczQyxHQUFHLENBQUM0QyxTQUF6QjtJQUNBcEQsdURBQUEsQ0FBYSxDQUFiO0lBQ0FBLHdEQUFBLENBQWMsS0FBZCxFQUFxQm1ELFlBQVksQ0FBQ25CLEtBQWxDO0lBQ0FoQyx1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCbUQsWUFBWSxDQUFDakIsTUFBbkM7SUFDQWxDLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0JBLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQm1ELFlBQVksQ0FBQ0UsV0FBbEMsQ0FBdEI7RUFDSDtBQUFFOztBQUNILFNBQVNDLHFDQUFULENBQStDL0MsRUFBL0MsRUFBbURDLEdBQW5ELEVBQXdEO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNsRVAscUVBQUEsQ0FBMkIsQ0FBM0I7SUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsWUFBckIsRUFBbUMsRUFBbkMsRUFBdUMsQ0FBdkMsRUFBMEMsYUFBMUMsRUFBeUQsRUFBekQ7SUFDQUEsd0RBQUEsQ0FBYyxDQUFkLEVBQWlCa0Qsb0RBQWpCLEVBQXVFLENBQXZFLEVBQTBFLENBQTFFLEVBQTZFLGNBQTdFLEVBQTZGLENBQTdGO0lBQ0FsRCwwREFBQTtJQUNBQSxtRUFBQTtFQUNIOztFQUFDLElBQUlPLEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDVixNQUFNZ0QsYUFBYSxHQUFHL0MsR0FBRyxDQUFDbUIsSUFBMUI7SUFDQTNCLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLFNBQWQsRUFBeUJ1RCxhQUF6QjtFQUNIO0FBQUU7O0FBQ0gsU0FBU0MsOENBQVQsQ0FBd0RqRCxFQUF4RCxFQUE0REMsR0FBNUQsRUFBaUU7RUFBRSxJQUFJRCxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQzNFUCx1REFBQSxDQUFhLENBQWIsRUFBZ0IsT0FBaEIsRUFBeUIsRUFBekI7RUFDSDs7RUFBQyxJQUFJTyxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ1YsTUFBTWtELFNBQVMsR0FBR3pELDJEQUFBLEdBQW1Cb0QsU0FBckM7SUFDQXBELHdEQUFBLENBQWMsTUFBZCxFQUFzQnlELFNBQVMsQ0FBQ0osV0FBaEM7RUFDSDtBQUFFOztBQUNILFNBQVNLLHFEQUFULENBQStEbkQsRUFBL0QsRUFBbUVDLEdBQW5FLEVBQXdFO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNsRixNQUFNb0QsSUFBSSxHQUFHM0QsOERBQUEsRUFBYjs7SUFDQUEscUVBQUEsQ0FBMkIsQ0FBM0I7SUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsYUFBckIsRUFBb0MsRUFBcEM7SUFDQUEsd0RBQUEsQ0FBYyxLQUFkLEVBQXFCLFNBQVM0RCxnRkFBVCxHQUE0RjtNQUFFLE1BQU1DLFdBQVcsR0FBRzdELDJEQUFBLENBQWlCMkQsSUFBakIsQ0FBcEI7TUFBNEMsTUFBTUcsV0FBVyxHQUFHRCxXQUFXLENBQUNULFNBQWhDO01BQTJDLE1BQU1XLE9BQU8sR0FBRy9ELDJEQUFBLENBQWlCLENBQWpCLENBQWhCO01BQXFDLE9BQU9BLHlEQUFBLENBQWUrRCxPQUFPLENBQUNDLGtCQUFSLENBQTJCRixXQUFXLENBQUNHLEVBQXZDLENBQWYsQ0FBUDtJQUFvRSxDQUFuVDtJQUNBakUsdURBQUEsQ0FBYSxDQUFiLEVBQWdCLG1CQUFoQixFQUFxQyxFQUFyQztJQUNBQSwwREFBQTtJQUNBQSxtRUFBQTtFQUNIOztFQUFDLElBQUlPLEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDVixNQUFNdUQsV0FBVyxHQUFHdEQsR0FBRyxDQUFDNEMsU0FBeEI7SUFDQXBELHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLFFBQWQsRUFBd0I4RCxXQUFXLENBQUMxQixLQUFwQztJQUNBcEMsdURBQUEsQ0FBYSxDQUFiO0lBQ0FBLHdEQUFBLENBQWMsVUFBZCxFQUEwQjhELFdBQVcsQ0FBQzlCLEtBQVosQ0FBa0JrQyxTQUE1QztFQUNIO0FBQUU7O0FBQ0gsU0FBU0Msc0NBQVQsQ0FBZ0Q1RCxFQUFoRCxFQUFvREMsR0FBcEQsRUFBeUQ7RUFBRSxJQUFJRCxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ25FUCxxRUFBQSxDQUEyQixDQUEzQjtJQUNBQSx3REFBQSxDQUFjLENBQWQsRUFBaUJ3RCw4Q0FBakIsRUFBaUUsQ0FBakUsRUFBb0UsQ0FBcEUsRUFBdUUsT0FBdkUsRUFBZ0YsQ0FBaEY7SUFDQXhELDREQUFBLENBQWtCLENBQWxCLEVBQXFCLFlBQXJCLEVBQW1DLEVBQW5DLEVBQXVDLENBQXZDLEVBQTBDLGFBQTFDLEVBQXlELEVBQXpEO0lBQ0FBLHdEQUFBLENBQWMsQ0FBZCxFQUFpQjBELHFEQUFqQixFQUF3RSxDQUF4RSxFQUEyRSxDQUEzRSxFQUE4RSxjQUE5RSxFQUE4RixDQUE5RjtJQUNBMUQsMERBQUE7SUFDQUEsbUVBQUE7RUFDSDs7RUFBQyxJQUFJTyxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ1YsTUFBTWtELFNBQVMsR0FBR2pELEdBQUcsQ0FBQzRDLFNBQXRCO0lBQ0FwRCx1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCLElBQXRCO0lBQ0FBLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLFNBQWQsRUFBeUJ5RCxTQUFTLENBQUNXLFFBQW5DO0VBQ0g7QUFBRTs7QUFDSSxNQUFNQyxhQUFOLENBQW9CO0VBQ3ZCQyxXQUFXLENBQUNDLElBQUQsRUFBT0MsYUFBUCxFQUFzQjtJQUM3QixLQUFLRCxJQUFMLEdBQVlBLElBQVo7SUFDQSxLQUFLQyxhQUFMLEdBQXFCQSxhQUFyQjtJQUNBLEtBQUs3QixHQUFMLEdBQVdsRCxxREFBWDtJQUNBLEtBQUtnRix1QkFBTCxHQUErQjtNQUMzQkMsSUFBSSxFQUFFN0UsbURBRHFCO01BRTNCK0UsS0FBSyxFQUFFLE1BQU0sS0FBS0osYUFBTCxDQUFtQksscUJBQW5CO0lBRmMsQ0FBL0I7SUFJQSxLQUFLTixJQUFMLENBQVVPLGVBQVYsR0FBNEIsSUFBNUI7RUFDSDs7RUFDRGQsa0JBQWtCLENBQUNDLEVBQUQsRUFBSztJQUNuQixLQUFLTyxhQUFMLENBQW1CTyx3QkFBbkIsQ0FBNENkLEVBQTVDO0VBQ0g7O0VBQ0R6QyxjQUFjLEdBQUc7SUFDYixLQUFLZ0QsYUFBTCxDQUFtQmhELGNBQW5CO0VBQ0g7O0FBaEJzQjs7QUFrQjNCNkMsYUFBYSxDQUFDVyxJQUFkLEdBQXFCLFNBQVNDLHFCQUFULENBQStCQyxDQUEvQixFQUFrQztFQUFFLE9BQU8sS0FBS0EsQ0FBQyxJQUFJYixhQUFWLEVBQXlCckUsK0RBQUEsQ0FBcUJDLG9EQUFyQixDQUF6QixFQUF3REQsK0RBQUEsQ0FBcUJFLG9EQUFyQixDQUF4RCxDQUFQO0FBQXlHLENBQWxLOztBQUNBbUUsYUFBYSxDQUFDZSxJQUFkLEdBQXFCLGFBQWNwRiwrREFBQSxDQUFxQjtFQUFFc0YsSUFBSSxFQUFFakIsYUFBUjtFQUF1QmtCLFNBQVMsRUFBRSxDQUFDLENBQUMsU0FBRCxDQUFELENBQWxDO0VBQWlEQyxLQUFLLEVBQUUsRUFBeEQ7RUFBNERDLElBQUksRUFBRSxFQUFsRTtFQUFzRUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxNQUFELEVBQVMsU0FBVCxDQUFELEVBQXNCLENBQUMsS0FBRCxFQUFRLEdBQVIsQ0FBdEIsRUFBb0MsQ0FBQyxlQUFELEVBQWtCLE1BQWxCLEVBQTBCLENBQTFCLEVBQTZCLGFBQTdCLEVBQTRDLG1CQUE1QyxDQUFwQyxFQUFzRyxDQUFDLEtBQUQsRUFBUSxHQUFSLEVBQWEsUUFBYixFQUF1QixNQUF2QixFQUErQiw0QkFBL0IsRUFBNkQsT0FBN0QsQ0FBdEcsRUFBNkssQ0FBQyxDQUFELEVBQUksTUFBSixDQUE3SyxFQUEwTCxDQUFDLE9BQUQsRUFBVSxtQkFBVixFQUErQixRQUEvQixFQUF5QyxZQUF6QyxFQUF1RCxDQUF2RCxFQUEwRCxNQUExRCxFQUFrRSxDQUFsRSxFQUFxRSxNQUFyRSxDQUExTCxFQUF3USxDQUFDLENBQUQsRUFBSSxPQUFKLEVBQWEsU0FBYixDQUF4USxFQUFpUyxDQUFDLFFBQUQsRUFBVyxLQUFYLEVBQWtCLE1BQWxCLEVBQTBCLEdBQTFCLEVBQStCLFNBQS9CLEVBQTBDLEdBQTFDLEVBQStDLENBQS9DLEVBQWtELGFBQWxELENBQWpTLEVBQW1XLENBQUMsS0FBRCxFQUFRLEdBQVIsRUFBYSxLQUFiLEVBQW9CLEdBQXBCLEVBQXlCLFFBQXpCLEVBQW1DLE1BQW5DLEVBQTJDLE9BQTNDLEVBQW9ELE1BQXBELEVBQTRELFNBQTVELEVBQXVFLFlBQXZFLEVBQXFGLENBQXJGLEVBQXdGLEtBQXhGLENBQW5XLEVBQW1jLENBQUMsS0FBRCxFQUFRLEdBQVIsRUFBYSxLQUFiLEVBQW9CLEdBQXBCLEVBQXlCLG1CQUF6QixFQUE4QyxRQUE5QyxFQUF3RCxxQkFBeEQsRUFBK0UsTUFBL0UsRUFBdUYsT0FBdkYsRUFBZ0csS0FBaEcsRUFBdUcsU0FBdkcsRUFBa0gsSUFBbEgsQ0FBbmMsRUFBNGpCLENBQUMsVUFBRCxFQUFhLElBQWIsRUFBbUIsT0FBbkIsRUFBNEIsTUFBNUIsRUFBb0MsQ0FBcEMsRUFBdUMsTUFBdkMsRUFBK0MsQ0FBL0MsRUFBa0QsTUFBbEQsQ0FBNWpCLEVBQXVuQixDQUFDLFVBQUQsRUFBYSxJQUFiLEVBQW1CLE9BQW5CLEVBQTRCLE1BQTVCLEVBQW9DLFdBQXBDLEVBQWlELEdBQWpELEVBQXNELFVBQXRELEVBQWtFLE1BQWxFLEVBQTBFLENBQTFFLEVBQTZFLE1BQTdFLENBQXZuQixFQUE2c0IsQ0FBQyxXQUFELEVBQWMsSUFBZCxFQUFvQixxQkFBcEIsRUFBMkMsTUFBM0MsRUFBbUQsT0FBbkQsRUFBNEQsS0FBNUQsRUFBbUUsT0FBbkUsRUFBNEUsTUFBNUUsRUFBb0YsVUFBcEYsRUFBZ0csSUFBaEcsRUFBc0csUUFBdEcsRUFBZ0gsZUFBaEgsRUFBaUksQ0FBakksRUFBb0ksa0JBQXBJLEVBQXdKLE1BQXhKLEVBQWdLLGFBQWhLLEVBQStLLENBQS9LLEVBQWtMLE1BQWxMLEVBQTBMLFNBQTFMLEVBQXFNLEtBQXJNLENBQTdzQixFQUEwNUIsQ0FBQyxpQkFBRCxFQUFvQixTQUFwQixFQUErQixTQUEvQixFQUEwQyxLQUExQyxFQUFpRCxLQUFqRCxFQUF3RCxHQUF4RCxFQUE2RCxLQUE3RCxFQUFvRSxHQUFwRSxFQUF5RSxRQUF6RSxFQUFtRixNQUFuRixFQUEyRixPQUEzRixFQUFvRyxNQUFwRyxDQUExNUIsRUFBdWdDLENBQUMsUUFBRCxFQUFXLFlBQVgsRUFBeUIsQ0FBekIsRUFBNEIsTUFBNUIsRUFBb0MsY0FBcEMsRUFBb0QsQ0FBcEQsRUFBdUQsTUFBdkQsQ0FBdmdDLEVBQXVrQyxDQUFDLGFBQUQsRUFBZ0IsWUFBaEIsRUFBOEIsMkJBQTlCLEVBQTJELE9BQTNELENBQXZrQyxFQUE0b0MsQ0FBQyxhQUFELEVBQWdCLFlBQWhCLEVBQThCLFNBQTlCLEVBQXlDLE9BQXpDLENBQTVvQyxFQUErckMsQ0FBQyxRQUFELEVBQVcsSUFBWCxFQUFpQixPQUFqQixFQUEwQixLQUExQixFQUFpQyxNQUFqQyxFQUF5QyxHQUF6QyxFQUE4QyxTQUE5QyxFQUF5RCxHQUF6RCxFQUE4RCxhQUE5RCxFQUE2RSxJQUE3RSxFQUFtRixDQUFuRixFQUFzRixhQUF0RixDQUEvckMsRUFBcXlDLENBQUMsU0FBRCxFQUFZLFlBQVosRUFBMEIsQ0FBMUIsRUFBNkIsS0FBN0IsQ0FBcnlDLEVBQTAwQyxDQUFDLENBQUQsRUFBSSxVQUFKLEVBQWdCLGtCQUFoQixFQUFvQyxNQUFwQyxFQUE0QyxhQUE1QyxFQUEyRCxjQUEzRCxFQUEyRSxDQUEzRSxFQUE4RSxNQUE5RSxDQUExMEMsRUFBaTZDLENBQUMsU0FBRCxFQUFZLEtBQVosRUFBbUIsQ0FBbkIsRUFBc0Isa0JBQXRCLENBQWo2QyxFQUE0OEMsQ0FBQyxtQkFBRCxFQUFzQixRQUF0QixFQUFnQyxDQUFoQyxFQUFtQyxRQUFuQyxFQUE2QyxLQUE3QyxDQUE1OEMsRUFBaWdELENBQUMsQ0FBRCxFQUFJLFVBQUosQ0FBamdELENBQTlFO0VBQWltREMsUUFBUSxFQUFFLFNBQVNDLHNCQUFULENBQWdDckYsRUFBaEMsRUFBb0NDLEdBQXBDLEVBQXlDO0lBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtNQUNsdERQLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLFlBQXJCLEVBQW1DLENBQW5DLEVBQXNDLENBQXRDLEVBQXlDLGFBQXpDLEVBQXdELENBQXhEO01BQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixXQUFoQixFQUE2QixDQUE3QjtNQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO01BQ0FBLDBEQUFBO01BQ0FBLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLFlBQXJCLEVBQW1DLENBQW5DLEVBQXNDLENBQXRDLEVBQXlDLGFBQXpDO01BQ0FBLHdEQUFBLENBQWMsQ0FBZCxFQUFpQlkscUNBQWpCLEVBQXdELEVBQXhELEVBQTRELEVBQTVELEVBQWdFLGNBQWhFLEVBQWdGLENBQWhGO01BQ0FaLG9EQUFBLENBQVUsQ0FBVixFQUFhLE9BQWI7TUFDQUEsd0RBQUEsQ0FBYyxDQUFkLEVBQWlCNEMsOEJBQWpCLEVBQWlELENBQWpELEVBQW9ELENBQXBELEVBQXVELE9BQXZELEVBQWdFLENBQWhFO01BQ0E1Qyx3REFBQSxDQUFjLENBQWQsRUFBaUJzRCxxQ0FBakIsRUFBd0QsQ0FBeEQsRUFBMkQsQ0FBM0QsRUFBOEQsY0FBOUQsRUFBOEUsQ0FBOUU7TUFDQXRELG9EQUFBLENBQVUsRUFBVixFQUFjLE9BQWQ7TUFDQUEsd0RBQUEsQ0FBYyxFQUFkLEVBQWtCbUUsc0NBQWxCLEVBQTBELENBQTFELEVBQTZELENBQTdELEVBQWdFLGNBQWhFLEVBQWdGLENBQWhGO01BQ0FuRSxvREFBQSxDQUFVLEVBQVYsRUFBYyxPQUFkO01BQ0FBLDBEQUFBO0lBQ0g7O0lBQUMsSUFBSU8sRUFBRSxHQUFHLENBQVQsRUFBWTtNQUNWLElBQUl1QyxPQUFKO01BQ0E5Qyx1REFBQSxDQUFhLENBQWI7TUFDQUEsd0RBQUEsQ0FBYyxhQUFkLEVBQTZCLENBQUMsQ0FBQzhDLE9BQU8sR0FBRzlDLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQlEsR0FBRyxDQUFDK0IsV0FBekIsQ0FBWCxLQUFxRCxJQUFyRCxHQUE0RCxJQUE1RCxHQUFtRU8sT0FBTyxDQUFDK0MsZUFBNUUsS0FBZ0csUUFBN0gsRUFBdUksbUJBQXZJLEVBQTRKckYsR0FBRyxDQUFDaUUsdUJBQWhLO01BQ0F6RSx1REFBQSxDQUFhLENBQWI7TUFDQUEsd0RBQUEsQ0FBYyxxQkFBZCxFQUFxQzhGLFNBQXJDO01BQ0E5Rix1REFBQSxDQUFhLENBQWI7TUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCQSx5REFBQSxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUJRLEdBQUcsQ0FBQ3VGLGdCQUF6QixDQUF0QjtNQUNBL0YsdURBQUEsQ0FBYSxDQUFiO01BQ0FBLHdEQUFBLENBQWMsTUFBZCxFQUFzQixJQUF0QjtNQUNBQSx1REFBQSxDQUFhLENBQWI7TUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCQSx5REFBQSxDQUFlLEVBQWYsRUFBbUIsRUFBbkIsRUFBdUJRLEdBQUcsQ0FBQ3dGLFdBQTNCLENBQXRCO01BQ0FoRyx1REFBQSxDQUFhLENBQWI7TUFDQUEsd0RBQUEsQ0FBYyxTQUFkLEVBQXlCQSx5REFBQSxDQUFlLEVBQWYsRUFBbUIsRUFBbkIsRUFBdUJRLEdBQUcsQ0FBQ3lGLGNBQTNCLENBQXpCO0lBQ0g7RUFBRSxDQTVCaUQ7RUE0Qi9DQyxZQUFZLEVBQUUsQ0FBQy9GLG9EQUFELEVBQWFBLGlEQUFiLEVBQXNCQyxvSEFBdEIsRUFBaURDLHVGQUFqRCxFQUFxRUYsc0RBQXJFLEVBQW1GQSwwREFBbkYsQ0E1QmlDO0VBNEJxRXNHLGFBQWEsRUFBRSxDQTVCcEY7RUE0QnVGQyxJQUFJLEVBQUU7SUFBRUMsU0FBUyxFQUFFLENBQUM1Ryx5REFBRDtFQUFiO0FBNUI3RixDQUFyQixDQUFuQzs7QUE2QkE2RyxVQUFVLENBQUMsQ0FDUGxILG1EQUFNLENBQUNDLDZEQUFELENBREMsRUFFUG1ILFVBQVUsQ0FBQyxhQUFELEVBQWdCQyxNQUFoQixDQUZILENBQUQsRUFHUDFDLGFBQWEsQ0FBQzJDLFNBSFAsRUFHa0IsYUFIbEIsRUFHaUMsS0FBSyxDQUh0QyxDQUFWOztBQUlBSixVQUFVLENBQUMsQ0FDUGxILG1EQUFNLENBQUNFLDhEQUFELENBREMsRUFFUGtILFVBQVUsQ0FBQyxhQUFELEVBQWdCQyxNQUFoQixDQUZILENBQUQsRUFHUDFDLGFBQWEsQ0FBQzJDLFNBSFAsRUFHa0IsYUFIbEIsRUFHaUMsS0FBSyxDQUh0QyxDQUFWOztBQUlBSixVQUFVLENBQUMsQ0FDUGxILG1EQUFNLENBQUNFLGlFQUFELENBREMsRUFFUGtILFVBQVUsQ0FBQyxhQUFELEVBQWdCQyxNQUFoQixDQUZILENBQUQsRUFHUDFDLGFBQWEsQ0FBQzJDLFNBSFAsRUFHa0IsZ0JBSGxCLEVBR29DLEtBQUssQ0FIekMsQ0FBVjs7QUFJQUosVUFBVSxDQUFDLENBQ1BsSCxtREFBTSxDQUFDRSxtRUFBRCxDQURDLEVBRVBrSCxVQUFVLENBQUMsYUFBRCxFQUFnQkMsTUFBaEIsQ0FGSCxDQUFELEVBR1AxQyxhQUFhLENBQUMyQyxTQUhQLEVBR2tCLGtCQUhsQixFQUdzQyxLQUFLLENBSDNDLENBQVY7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyTCtDO0FBQ0o7QUFDc0I7QUFDUDtBQUN0QjtBQUM3QjtBQUNQO0FBQ0EsbURBQW1EO0FBQ25ELGdDQUFnQyw4REFBbUIsR0FBRyxrQkFBa0I7QUFDeEUsZ0NBQWdDLDhEQUFtQixHQUFHLFVBQVUsMkVBQXdCO0FBQ3hGLFFBQVEseURBQVk7QUFDcEIsUUFBUSxtRUFBaUI7QUFDekIsUUFBUSxxREFBWSxHQUFHIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9ob21lLXJvdXRpbmcubW9kdWxlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL2hvbWUvaG9tZS5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvZmVhdHVyZXMvaG9tZS9ob21lLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsIE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZSwgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgeyBIb21lQ29tcG9uZW50IH0gZnJvbSBcIi4vaG9tZS5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5leHBvcnQgY29uc3Qgcm91dGVzID0gW1xuICAgIHtcbiAgICAgICAgcGF0aDogXCJcIixcbiAgICAgICAgY29tcG9uZW50OiBIb21lQ29tcG9uZW50LFxuICAgIH0sXG5dO1xuZXhwb3J0IGNsYXNzIEhvbWVSb3V0aW5nTW9kdWxlIHtcbn1cbkhvbWVSb3V0aW5nTW9kdWxlLsm1ZmFjID0gZnVuY3Rpb24gSG9tZVJvdXRpbmdNb2R1bGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgSG9tZVJvdXRpbmdNb2R1bGUpKCk7IH07XG5Ib21lUm91dGluZ01vZHVsZS7JtW1vZCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZU5nTW9kdWxlKHsgdHlwZTogSG9tZVJvdXRpbmdNb2R1bGUgfSk7XG5Ib21lUm91dGluZ01vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW05hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcbiAgICAgICAgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLmZvckNoaWxkKHJvdXRlcyldIH0pO1xuIiwiaW1wb3J0IHsgUGFnZSwgaXNJT1MgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9jb3JlXCI7XG5pbXBvcnQgeyBTZWxlY3QgfSBmcm9tIFwiQG5neHMvc3RvcmVcIjtcbmltcG9ydCB7IENvbmZpZ1N0YXRlLCBQcm9kdWN0U3RhdGUsIEljb25zLCBMYXllcnNTZXJ2aWNlLCBTbGlkZVVwRmFkZVN0YWdnZXIsIH0gZnJvbSBcIkBhcHAvY29yZVwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAbmF0aXZlc2NyaXB0L2NvcmVcIjtcbmltcG9ydCAqIGFzIGkyIGZyb20gXCJAYXBwL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkzIGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCAqIGFzIGk0IGZyb20gXCIuLi8uLi9zaGFyZWQvY29tcG9uZW50cy9jYXJkcy90aHVtYm5haWwtY2FyZC90aHVtYm5haWwtY2FyZC5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGk1IGZyb20gXCIuLi8uLi9zaGFyZWQvY29tcG9uZW50cy9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudFwiO1xuZnVuY3Rpb24gSG9tZUNvbXBvbmVudF9uZ19jb250YWluZXJfNl9uZ19jb250YWluZXJfM19UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiQ29udGVudFZpZXdcIiwgMTMpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IH1cbmZ1bmN0aW9uIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzZfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgY29uc3QgX3I3ID0gaTAuybXJtWdldEN1cnJlbnRWaWV3KCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiR3JpZExheW91dFwiLCA3KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgyLCBcIkltYWdlXCIsIDgpO1xuICAgIGkwLsm1ybV0ZW1wbGF0ZSgzLCBIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl82X25nX2NvbnRhaW5lcl8zX1RlbXBsYXRlLCAyLCAwLCBcIm5nLWNvbnRhaW5lclwiLCA0KTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDQsIFwiU3RhY2tMYXlvdXRcIiwgOSk7XG4gICAgaTAuybXJtWVsZW1lbnQoNSwgXCJMYWJlbFwiLCAxMCk7XG4gICAgaTAuybXJtXBpcGUoNiwgXCJ1cHBlcmNhc2VcIik7XG4gICAgaTAuybXJtWVsZW1lbnQoNywgXCJMYWJlbFwiLCAxMSk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCg4LCBcIkJ1dHRvblwiLCAxMik7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwidGFwXCIsIGZ1bmN0aW9uIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzZfVGVtcGxhdGVfQnV0dG9uX3RhcF84X2xpc3RlbmVyKCkgeyBpMC7Jtcm1cmVzdG9yZVZpZXcoX3I3KTsgY29uc3QgY3R4X3I2ID0gaTAuybXJtW5leHRDb250ZXh0KCk7IHJldHVybiBpMC7Jtcm1cmVzZXRWaWV3KGN0eF9yNi5vcGVuQWxlcnRQb3B1cCgpKTsgfSk7XG4gICAgaTAuybXJtXBpcGUoOSwgXCJhc3luY1wiKTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpKCkoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgZmVhdHVyZWRfcjQgPSBjdHgubmdJZjtcbiAgICBjb25zdCBjdHhfcjAgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTtcbiAgICBsZXQgdG1wXzRfMDtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJzcmNcIiwgZmVhdHVyZWRfcjQuaW1hZ2UuY292ZXIpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgZmVhdHVyZWRfcjQudGludGVkKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGkwLsm1ybVwaXBlQmluZDEoNiwgNiwgZmVhdHVyZWRfcjQudGl0bGUpKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGZlYXR1cmVkX3I0LmRlc2NyaXB0aW9uLnNsaWNlKDAsIDEwMCkgKyBcIi4uLlwiKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsICgodG1wXzRfMCA9IGkwLsm1ybVwaXBlQmluZDEoOSwgOCwgY3R4X3IwLnN0YXRpY1RleHQkKSkgPT0gbnVsbCA/IG51bGwgOiB0bXBfNF8wLmhvbWUgPT0gbnVsbCA/IG51bGwgOiB0bXBfNF8wLmhvbWUuYnV0dG9ucyA9PSBudWxsID8gbnVsbCA6IHRtcF80XzAuaG9tZS5idXR0b25zLmhlcm9DdGEpIHx8IFwiUExBWSBOT1dcIikoXCJwYWRkaW5nXCIsIGN0eF9yMC5pb3MgPyBcIjE1IDBcIiA6IFwiNSAwIDAgMFwiKTtcbn0gfVxuZnVuY3Rpb24gSG9tZUNvbXBvbmVudF9MYWJlbF84X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGkwLsm1ybVlbGVtZW50KDAsIFwiTGFiZWxcIiwgMTQpO1xuICAgIGkwLsm1ybVwaXBlKDEsIFwiYXN5bmNcIik7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBjdHhfcjEgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTtcbiAgICBsZXQgdG1wXzBfMDtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsICgodG1wXzBfMCA9IGkwLsm1ybVwaXBlQmluZDEoMSwgMSwgY3R4X3IxLnN0YXRpY1RleHQkKSkgPT0gbnVsbCA/IG51bGwgOiB0bXBfMF8wLnNlY3Rpb25UaXRsZSA9PSBudWxsID8gbnVsbCA6IHRtcF8wXzAuc2VjdGlvblRpdGxlLmNhdGVnb3JpZXMpIHx8IFwiQ2F0ZWdvcmllc1wiKTtcbn0gfVxuZnVuY3Rpb24gSG9tZUNvbXBvbmVudF9uZ19jb250YWluZXJfOV9uZ19jb250YWluZXJfM19uZ19jb250YWluZXJfM19UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiQ29udGVudFZpZXdcIiwgMjApO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IH1cbmZ1bmN0aW9uIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzlfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiR3JpZExheW91dFwiLCAxNyk7XG4gICAgaTAuybXJtWVsZW1lbnQoMiwgXCJJbWFnZVwiLCAxOCk7XG4gICAgaTAuybXJtXRlbXBsYXRlKDMsIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzlfbmdfY29udGFpbmVyXzNfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUsIDIsIDAsIFwibmctY29udGFpbmVyXCIsIDQpO1xuICAgIGkwLsm1ybVlbGVtZW50KDQsIFwiTGFiZWxcIiwgMTkpO1xuICAgIGkwLsm1ybVwaXBlKDUsIFwidXBwZXJjYXNlXCIpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGNhdGVnb3J5X3IxMCA9IGN0eC4kaW1wbGljaXQ7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwic3JjXCIsIGNhdGVnb3J5X3IxMC5pbWFnZSk7XG4gICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBjYXRlZ29yeV9yMTAudGludGVkKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGkwLsm1ybVwaXBlQmluZDEoNSwgMywgY2F0ZWdvcnlfcjEwLmRpc3BsYXlOYW1lKSk7XG59IH1cbmZ1bmN0aW9uIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzlfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiU2Nyb2xsVmlld1wiLCAxNSkoMiwgXCJTdGFja0xheW91dFwiLCAxNik7XG4gICAgaTAuybXJtXRlbXBsYXRlKDMsIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzlfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUsIDYsIDUsIFwibmctY29udGFpbmVyXCIsIDYpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgY2F0ZWdvcmllc19yOCA9IGN0eC5uZ0lmO1xuICAgIGkwLsm1ybVhZHZhbmNlKDMpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nRm9yT2ZcIiwgY2F0ZWdvcmllc19yOCk7XG59IH1cbmZ1bmN0aW9uIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzExX0xhYmVsXzFfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnQoMCwgXCJMYWJlbFwiLCAxNCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBncm91cF9yMTIgPSBpMC7Jtcm1bmV4dENvbnRleHQoKS4kaW1wbGljaXQ7XG4gICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBncm91cF9yMTIuZGlzcGxheU5hbWUpO1xufSB9XG5mdW5jdGlvbiBIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xMV9uZ19jb250YWluZXJfNF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBjb25zdCBfcjE4ID0gaTAuybXJtWdldEN1cnJlbnRWaWV3KCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiQ29udGVudFZpZXdcIiwgMjEpO1xuICAgIGkwLsm1ybVsaXN0ZW5lcihcInRhcFwiLCBmdW5jdGlvbiBIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xMV9uZ19jb250YWluZXJfNF9UZW1wbGF0ZV9Db250ZW50Vmlld190YXBfMV9saXN0ZW5lcigpIHsgY29uc3QgcmVzdG9yZWRDdHggPSBpMC7Jtcm1cmVzdG9yZVZpZXcoX3IxOCk7IGNvbnN0IHByb2R1Y3RfcjE2ID0gcmVzdG9yZWRDdHguJGltcGxpY2l0OyBjb25zdCBjdHhfcjE3ID0gaTAuybXJtW5leHRDb250ZXh0KDIpOyByZXR1cm4gaTAuybXJtXJlc2V0VmlldyhjdHhfcjE3Lm9wZW5Qcm9kdWN0RGV0YWlscyhwcm9kdWN0X3IxNi5pZCkpOyB9KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgyLCBcIm5zLXRodW1ibmFpbC1jYXJkXCIsIDIyKTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBwcm9kdWN0X3IxNiA9IGN0eC4kaW1wbGljaXQ7XG4gICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgaTAuybXJtXByb3BlcnR5KFwidGVzdElEXCIsIHByb2R1Y3RfcjE2LnRpdGxlKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJpbWFnZVNyY1wiLCBwcm9kdWN0X3IxNi5pbWFnZS50aHVtYm5haWwpO1xufSB9XG5mdW5jdGlvbiBIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xMV9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybV0ZW1wbGF0ZSgxLCBIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xMV9MYWJlbF8xX1RlbXBsYXRlLCAxLCAxLCBcIkxhYmVsXCIsIDUpO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMiwgXCJTY3JvbGxWaWV3XCIsIDE1KSgzLCBcIlN0YWNrTGF5b3V0XCIsIDE2KTtcbiAgICBpMC7Jtcm1dGVtcGxhdGUoNCwgSG9tZUNvbXBvbmVudF9uZ19jb250YWluZXJfMTFfbmdfY29udGFpbmVyXzRfVGVtcGxhdGUsIDMsIDIsIFwibmctY29udGFpbmVyXCIsIDYpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgZ3JvdXBfcjEyID0gY3R4LiRpbXBsaWNpdDtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ0lmXCIsIHRydWUpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDMpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nRm9yT2ZcIiwgZ3JvdXBfcjEyLnByb2R1Y3RzKTtcbn0gfVxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHBhZ2UsIGxheWVyc1NlcnZpY2UpIHtcbiAgICAgICAgdGhpcy5wYWdlID0gcGFnZTtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlID0gbGF5ZXJzU2VydmljZTtcbiAgICAgICAgdGhpcy5pb3MgPSBpc0lPUztcbiAgICAgICAgdGhpcy5oZWFkZXJSaWdodEFjdGlvbkJ1dHRvbiA9IHtcbiAgICAgICAgICAgIGljb246IEljb25zLnNlYXJjaCxcbiAgICAgICAgICAgIG9uVGFwOiAoKSA9PiB0aGlzLmxheWVyc1NlcnZpY2Uub3BlblNlYXJjaEJvdHRvbXNoZWV0KCksXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMucGFnZS5hY3Rpb25CYXJIaWRkZW4gPSB0cnVlO1xuICAgIH1cbiAgICBvcGVuUHJvZHVjdERldGFpbHMoaWQpIHtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlLm9wZW5RdWlja3ZpZXdCb3R0b21zaGVldChpZCk7XG4gICAgfVxuICAgIG9wZW5BbGVydFBvcHVwKCkge1xuICAgICAgICB0aGlzLmxheWVyc1NlcnZpY2Uub3BlbkFsZXJ0UG9wdXAoKTtcbiAgICB9XG59XG5Ib21lQ29tcG9uZW50Lsm1ZmFjID0gZnVuY3Rpb24gSG9tZUNvbXBvbmVudF9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBIb21lQ29tcG9uZW50KShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkxLlBhZ2UpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkyLkxheWVyc1NlcnZpY2UpKTsgfTtcbkhvbWVDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBIb21lQ29tcG9uZW50LCBzZWxlY3RvcnM6IFtbXCJucy1ob21lXCJdXSwgZGVjbHM6IDEzLCB2YXJzOiAxNSwgY29uc3RzOiBbW1wicm93c1wiLCBcImF1dG8sICpcIl0sIFtcInJvd1wiLCBcIjBcIl0sIFtcImhhc01lbnVCdXR0b25cIiwgXCJ0cnVlXCIsIDMsIFwiaGVhZGVyVGl0bGVcIiwgXCJyaWdodEFjdGlvbkJ1dHRvblwiXSwgW1wicm93XCIsIFwiMVwiLCBcImhlaWdodFwiLCBcIjEwMCVcIiwgXCJpb3NPdmVyZmxvd1NhZmVBcmVhRW5hYmxlZFwiLCBcImZhbHNlXCJdLCBbNCwgXCJuZ0lmXCJdLCBbXCJjbGFzc1wiLCBcImJvbGQgZm9udC1zaXplLWgzXCIsIFwibWFyZ2luXCIsIFwiMjAgMjAgMCAyMFwiLCAzLCBcInRleHRcIiwgNCwgXCJuZ0lmXCJdLCBbNCwgXCJuZ0ZvclwiLCBcIm5nRm9yT2ZcIl0sIFtcImhlaWdodFwiLCBcIjI1MFwiLCBcInJvd3NcIiwgXCIqXCIsIFwiY29sdW1uc1wiLCBcIipcIiwgMSwgXCJnbG93LXNoYWRvd1wiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjBcIiwgXCJoZWlnaHRcIiwgXCIxMDAlXCIsIFwid2lkdGhcIiwgXCIxMDAlXCIsIFwic3RyZXRjaFwiLCBcImFzcGVjdEZpbGxcIiwgMywgXCJzcmNcIl0sIFtcInJvd1wiLCBcIjBcIiwgXCJjb2xcIiwgXCIwXCIsIFwidmVydGljYWxBbGlnbm1lbnRcIiwgXCJib3R0b21cIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwibGVmdFwiLCBcIndpZHRoXCIsIFwiNzUlXCIsIFwicGFkZGluZ1wiLCBcIjIwXCJdLCBbXCJmb250U2l6ZVwiLCBcIjIwXCIsIFwiY29sb3JcIiwgXCIjZmZmXCIsIDEsIFwiYm9sZFwiLCAzLCBcInRleHRcIl0sIFtcImZvbnRTaXplXCIsIFwiMTVcIiwgXCJjb2xvclwiLCBcIiNkZGRcIiwgXCJtYXJnaW5Ub3BcIiwgXCI3XCIsIFwidGV4dFdyYXBcIiwgXCJ0cnVlXCIsIDMsIFwidGV4dFwiXSwgW1wibWFyZ2luVG9wXCIsIFwiMjBcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwibGVmdFwiLCBcIndpZHRoXCIsIFwiMTUwXCIsIFwiY29sb3JcIiwgXCIjZmZmXCIsIFwiZm9udFNpemVcIiwgXCIxNFwiLCBcInRlc3RJRFwiLCBcInBsYXlOb3dCdXR0b25cIiwgMSwgXCJiZy1jb2xvci1wcmltYXJ5XCIsIFwiYm9sZFwiLCBcImdsb3ctc2hhZG93XCIsIDMsIFwidGV4dFwiLCBcInBhZGRpbmdcIiwgXCJ0YXBcIl0sIFtcImJhY2tncm91bmRDb2xvclwiLCBcIiM2NjY2NjZcIiwgXCJvcGFjaXR5XCIsIFwiMC43XCIsIFwicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjBcIiwgXCJoZWlnaHRcIiwgXCIxMDAlXCIsIFwid2lkdGhcIiwgXCIxMDAlXCJdLCBbXCJtYXJnaW5cIiwgXCIyMCAyMCAwIDIwXCIsIDEsIFwiYm9sZFwiLCBcImZvbnQtc2l6ZS1oM1wiLCAzLCBcInRleHRcIl0sIFtcIm9yaWVudGF0aW9uXCIsIFwiaG9yaXpvbnRhbFwiLCBcInNjcm9sbEJhckluZGljYXRvclZpc2libGVcIiwgXCJmYWxzZVwiXSwgW1wib3JpZW50YXRpb25cIiwgXCJob3Jpem9udGFsXCIsIFwicGFkZGluZ1wiLCBcIjEwIDIwXCJdLCBbXCJoZWlnaHRcIiwgXCI4MFwiLCBcIndpZHRoXCIsIFwiMTYwXCIsIFwicm93c1wiLCBcIipcIiwgXCJjb2x1bW5zXCIsIFwiKlwiLCBcIm1hcmdpblJpZ2h0XCIsIFwiMTBcIiwgMSwgXCJnbG93LXNoYWRvd1wiXSwgW1wic3RyZXRjaFwiLCBcImFzcGVjdEZpbGxcIiwgMywgXCJzcmNcIl0sIFsxLCBcInYtY2VudGVyXCIsIFwidGV4dC1jb2xvci1saWdodFwiLCBcImJvbGRcIiwgXCJ0ZXh0LWNlbnRlclwiLCBcImZvbnQtc2l6ZS1oM1wiLCAzLCBcInRleHRcIl0sIFtcIm9wYWNpdHlcIiwgXCIwLjdcIiwgMSwgXCJiZy1jb2xvci1wcmltYXJ5XCJdLCBbXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImJvdHRvbVwiLCAzLCBcInRlc3RJRFwiLCBcInRhcFwiXSwgWzMsIFwiaW1hZ2VTcmNcIl1dLCB0ZW1wbGF0ZTogZnVuY3Rpb24gSG9tZUNvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCkoMSwgXCJDb250ZW50Vmlld1wiLCAxKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMiwgXCJucy1oZWFkZXJcIiwgMik7XG4gICAgICAgIGkwLsm1ybVwaXBlKDMsIFwiYXN5bmNcIik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoNCwgXCJTY3JvbGxWaWV3XCIsIDMpKDUsIFwiU3RhY2tMYXlvdXRcIik7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSg2LCBIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl82X1RlbXBsYXRlLCAxMCwgMTAsIFwibmctY29udGFpbmVyXCIsIDQpO1xuICAgICAgICBpMC7Jtcm1cGlwZSg3LCBcImFzeW5jXCIpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoOCwgSG9tZUNvbXBvbmVudF9MYWJlbF84X1RlbXBsYXRlLCAyLCAzLCBcIkxhYmVsXCIsIDUpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoOSwgSG9tZUNvbXBvbmVudF9uZ19jb250YWluZXJfOV9UZW1wbGF0ZSwgNCwgMSwgXCJuZy1jb250YWluZXJcIiwgNCk7XG4gICAgICAgIGkwLsm1ybVwaXBlKDEwLCBcImFzeW5jXCIpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoMTEsIEhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzExX1RlbXBsYXRlLCA1LCAyLCBcIm5nLWNvbnRhaW5lclwiLCA2KTtcbiAgICAgICAgaTAuybXJtXBpcGUoMTIsIFwiYXN5bmNcIik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKSgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBsZXQgdG1wXzBfMDtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcImhlYWRlclRpdGxlXCIsICgodG1wXzBfMCA9IGkwLsm1ybVwaXBlQmluZDEoMywgNywgY3R4LnN0YXRpY1RleHQkKSkgPT0gbnVsbCA/IG51bGwgOiB0bXBfMF8wLm1haW5IZWFkZXJUaXRsZSkgfHwgXCJNT1ZJRVNcIikoXCJyaWdodEFjdGlvbkJ1dHRvblwiLCBjdHguaGVhZGVyUmlnaHRBY3Rpb25CdXR0b24pO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwiQHNsaWRlVXBGYWRlU3RhZ2dlclwiLCB1bmRlZmluZWQpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBpMC7Jtcm1cGlwZUJpbmQxKDcsIDksIGN0eC5mZWF0dXJlZFByb2R1Y3QkKSk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ0lmXCIsIHRydWUpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBpMC7Jtcm1cGlwZUJpbmQxKDEwLCAxMSwgY3R4LmNhdGVnb3JpZXMkKSk7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ0Zvck9mXCIsIGkwLsm1ybVwaXBlQmluZDEoMTIsIDEzLCBjdHgucHJvZHVjdEdyb3VwcyQpKTtcbiAgICB9IH0sIGRlcGVuZGVuY2llczogW2kzLk5nRm9yT2YsIGkzLk5nSWYsIGk0LlRodW1ibmFpbENhcmRDb21wb25lbnQsIGk1LkhlYWRlckNvbXBvbmVudCwgaTMuQXN5bmNQaXBlLCBpMy5VcHBlckNhc2VQaXBlXSwgZW5jYXBzdWxhdGlvbjogMiwgZGF0YTogeyBhbmltYXRpb246IFtTbGlkZVVwRmFkZVN0YWdnZXJdIH0gfSk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3QoQ29uZmlnU3RhdGUuc3RhdGljVGV4dCksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjp0eXBlXCIsIE9iamVjdClcbl0sIEhvbWVDb21wb25lbnQucHJvdG90eXBlLCBcInN0YXRpY1RleHQkXCIsIHZvaWQgMCk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3QoUHJvZHVjdFN0YXRlLmNhdGVnb3JpZXMpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBPYmplY3QpXG5dLCBIb21lQ29tcG9uZW50LnByb3RvdHlwZSwgXCJjYXRlZ29yaWVzJFwiLCB2b2lkIDApO1xuX19kZWNvcmF0ZShbXG4gICAgU2VsZWN0KFByb2R1Y3RTdGF0ZS5wcm9kdWN0R3JvdXBzKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgT2JqZWN0KVxuXSwgSG9tZUNvbXBvbmVudC5wcm90b3R5cGUsIFwicHJvZHVjdEdyb3VwcyRcIiwgdm9pZCAwKTtcbl9fZGVjb3JhdGUoW1xuICAgIFNlbGVjdChQcm9kdWN0U3RhdGUuZmVhdHVyZWRQcm9kdWN0KSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgT2JqZWN0KVxuXSwgSG9tZUNvbXBvbmVudC5wcm90b3R5cGUsIFwiZmVhdHVyZWRQcm9kdWN0JFwiLCB2b2lkIDApO1xuIiwiaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHsgU2hhcmVkTW9kdWxlIH0gZnJvbSBcIkBhcHAvc2hhcmVkXCI7XG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgeyBIb21lUm91dGluZ01vZHVsZSB9IGZyb20gXCIuL2hvbWUtcm91dGluZy5tb2R1bGVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5leHBvcnQgY2xhc3MgSG9tZU1vZHVsZSB7XG59XG5Ib21lTW9kdWxlLsm1ZmFjID0gZnVuY3Rpb24gSG9tZU1vZHVsZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBIb21lTW9kdWxlKSgpOyB9O1xuSG9tZU1vZHVsZS7JtW1vZCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZU5nTW9kdWxlKHsgdHlwZTogSG9tZU1vZHVsZSB9KTtcbkhvbWVNb2R1bGUuybVpbmogPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVJbmplY3Rvcih7IGltcG9ydHM6IFtOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXG4gICAgICAgIENvbW1vbk1vZHVsZSxcbiAgICAgICAgSG9tZVJvdXRpbmdNb2R1bGUsXG4gICAgICAgIFNoYXJlZE1vZHVsZV0gfSk7XG4iXSwibmFtZXMiOlsiUGFnZSIsImlzSU9TIiwiU2VsZWN0IiwiQ29uZmlnU3RhdGUiLCJQcm9kdWN0U3RhdGUiLCJJY29ucyIsIkxheWVyc1NlcnZpY2UiLCJTbGlkZVVwRmFkZVN0YWdnZXIiLCJpMCIsImkxIiwiaTIiLCJpMyIsImk0IiwiaTUiLCJIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl82X25nX2NvbnRhaW5lcl8zX1RlbXBsYXRlIiwicmYiLCJjdHgiLCLJtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0IiwiybXJtWVsZW1lbnQiLCLJtcm1ZWxlbWVudENvbnRhaW5lckVuZCIsIkhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzZfVGVtcGxhdGUiLCJfcjciLCLJtcm1Z2V0Q3VycmVudFZpZXciLCLJtcm1ZWxlbWVudFN0YXJ0IiwiybXJtXRlbXBsYXRlIiwiybXJtXBpcGUiLCLJtcm1bGlzdGVuZXIiLCJIb21lQ29tcG9uZW50X25nX2NvbnRhaW5lcl82X1RlbXBsYXRlX0J1dHRvbl90YXBfOF9saXN0ZW5lciIsIsm1ybVyZXN0b3JlVmlldyIsImN0eF9yNiIsIsm1ybVuZXh0Q29udGV4dCIsIsm1ybVyZXNldFZpZXciLCJvcGVuQWxlcnRQb3B1cCIsIsm1ybVlbGVtZW50RW5kIiwiZmVhdHVyZWRfcjQiLCJuZ0lmIiwiY3R4X3IwIiwidG1wXzRfMCIsIsm1ybVhZHZhbmNlIiwiybXJtXByb3BlcnR5IiwiaW1hZ2UiLCJjb3ZlciIsInRpbnRlZCIsIsm1ybVwaXBlQmluZDEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic2xpY2UiLCJzdGF0aWNUZXh0JCIsImhvbWUiLCJidXR0b25zIiwiaGVyb0N0YSIsImlvcyIsIkhvbWVDb21wb25lbnRfTGFiZWxfOF9UZW1wbGF0ZSIsImN0eF9yMSIsInRtcF8wXzAiLCJzZWN0aW9uVGl0bGUiLCJjYXRlZ29yaWVzIiwiSG9tZUNvbXBvbmVudF9uZ19jb250YWluZXJfOV9uZ19jb250YWluZXJfM19uZ19jb250YWluZXJfM19UZW1wbGF0ZSIsIkhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzlfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUiLCJjYXRlZ29yeV9yMTAiLCIkaW1wbGljaXQiLCJkaXNwbGF5TmFtZSIsIkhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzlfVGVtcGxhdGUiLCJjYXRlZ29yaWVzX3I4IiwiSG9tZUNvbXBvbmVudF9uZ19jb250YWluZXJfMTFfTGFiZWxfMV9UZW1wbGF0ZSIsImdyb3VwX3IxMiIsIkhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzExX25nX2NvbnRhaW5lcl80X1RlbXBsYXRlIiwiX3IxOCIsIkhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzExX25nX2NvbnRhaW5lcl80X1RlbXBsYXRlX0NvbnRlbnRWaWV3X3RhcF8xX2xpc3RlbmVyIiwicmVzdG9yZWRDdHgiLCJwcm9kdWN0X3IxNiIsImN0eF9yMTciLCJvcGVuUHJvZHVjdERldGFpbHMiLCJpZCIsInRodW1ibmFpbCIsIkhvbWVDb21wb25lbnRfbmdfY29udGFpbmVyXzExX1RlbXBsYXRlIiwicHJvZHVjdHMiLCJIb21lQ29tcG9uZW50IiwiY29uc3RydWN0b3IiLCJwYWdlIiwibGF5ZXJzU2VydmljZSIsImhlYWRlclJpZ2h0QWN0aW9uQnV0dG9uIiwiaWNvbiIsInNlYXJjaCIsIm9uVGFwIiwib3BlblNlYXJjaEJvdHRvbXNoZWV0IiwiYWN0aW9uQmFySGlkZGVuIiwib3BlblF1aWNrdmlld0JvdHRvbXNoZWV0IiwiybVmYWMiLCJIb21lQ29tcG9uZW50X0ZhY3RvcnkiLCJ0IiwiybXJtWRpcmVjdGl2ZUluamVjdCIsIsm1Y21wIiwiybXJtWRlZmluZUNvbXBvbmVudCIsInR5cGUiLCJzZWxlY3RvcnMiLCJkZWNscyIsInZhcnMiLCJjb25zdHMiLCJ0ZW1wbGF0ZSIsIkhvbWVDb21wb25lbnRfVGVtcGxhdGUiLCJtYWluSGVhZGVyVGl0bGUiLCJ1bmRlZmluZWQiLCJmZWF0dXJlZFByb2R1Y3QkIiwiY2F0ZWdvcmllcyQiLCJwcm9kdWN0R3JvdXBzJCIsImRlcGVuZGVuY2llcyIsIk5nRm9yT2YiLCJOZ0lmIiwiVGh1bWJuYWlsQ2FyZENvbXBvbmVudCIsIkhlYWRlckNvbXBvbmVudCIsIkFzeW5jUGlwZSIsIlVwcGVyQ2FzZVBpcGUiLCJlbmNhcHN1bGF0aW9uIiwiZGF0YSIsImFuaW1hdGlvbiIsIl9fZGVjb3JhdGUiLCJzdGF0aWNUZXh0IiwiX19tZXRhZGF0YSIsIk9iamVjdCIsInByb3RvdHlwZSIsInByb2R1Y3RHcm91cHMiLCJmZWF0dXJlZFByb2R1Y3QiXSwic291cmNlUm9vdCI6IiJ9