"use strict";
(() => {
var exports = {};
exports.id = "bundle";
exports.ids = ["bundle"];
exports.modules = {

/***/ "./src/main.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app.css");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/app.module.ts");
/* harmony import */ var _app_features_loading_loading_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/features/loading/loading.module.ts");
// Added by app-css-loader




(0,_nativescript_angular__WEBPACK_IMPORTED_MODULE_3__.runNativeScriptAngularApp)({
    appModuleBootstrap: (reason) => (0,_nativescript_angular__WEBPACK_IMPORTED_MODULE_3__.platformNativeScript)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_1__.AppModule),
    loadingModule: (reason) => (0,_nativescript_angular__WEBPACK_IMPORTED_MODULE_3__.platformNativeScript)().bootstrapModule(_app_features_loading_loading_module__WEBPACK_IMPORTED_MODULE_2__.LoadingModule),
});


/***/ }),

/***/ "./src/app.css":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* CSS2JSON */

const ___CSS2JSON_LOADER_EXPORT___ = {"type":"stylesheet","stylesheet":{"rules":[{"type":"comment","comment":" Fonts "},{"type":"rule","selectors":[".fa"],"declarations":[{"type":"declaration","property":"font-family","value":"FontAwesome, fontawesome-webfont"}]},{"type":"rule","selectors":[".ionicons"],"declarations":[{"type":"declaration","property":"font-family","value":"Ionicons, ionicons"}]},{"type":"rule","selectors":[".bold"],"declarations":[{"type":"declaration","property":"font-family","value":"\"Poppins Bold\", \"Poppins-Bold\""},{"type":"declaration","property":"font-weight","value":"700"}]},{"type":"rule","selectors":[".medium"],"declarations":[{"type":"declaration","property":"font-family","value":"\"Poppins Medium\", \"Poppins-Medium\""},{"type":"declaration","property":"font-weight","value":"500"}]},{"type":"rule","selectors":[".regular"],"declarations":[{"type":"declaration","property":"font-family","value":"\"Poppins Regular\", \"Poppins-Regular\""},{"type":"declaration","property":"font-weight","value":"400"}]},{"type":"rule","selectors":[".light"],"declarations":[{"type":"declaration","property":"font-family","value":"\"Poppins Light\", \"Poppins-Light\""},{"type":"declaration","property":"font-weight","value":"300"}]},{"type":"rule","selectors":[".ion-alert:before"],"declarations":[{"type":"declaration","property":"content","value":"\"\\f101\""}]},{"type":"rule","selectors":[".ns-root"],"declarations":[{"type":"comment","comment":" Colors "},{"type":"declaration","property":"--color-primary","value":"#65adf1"},{"type":"declaration","property":"--color-bg-default","value":"#fefefe"},{"type":"declaration","property":"--color-bg-gray","value":"#444"},{"type":"declaration","property":"--color-text-on-primary","value":"#fefefe"},{"type":"declaration","property":"--color-text-default","value":"#393838"},{"type":"declaration","property":"--color-text-gray","value":"#444"},{"type":"comment","comment":" Spacing "},{"type":"declaration","property":"--spacing-xl","value":"25"},{"type":"declaration","property":"--spacing-l","value":"15"},{"type":"declaration","property":"--spacing-m","value":"10"},{"type":"declaration","property":"--spacing-s","value":"5"},{"type":"comment","comment":" Border Radius "},{"type":"declaration","property":"--border-radius-l","value":"15"},{"type":"declaration","property":"--border-radius-m","value":"10"},{"type":"declaration","property":"--border-radius-s","value":"5"},{"type":"comment","comment":" Font "},{"type":"declaration","property":"--font-size-h1","value":"25"},{"type":"declaration","property":"--font-size-h2","value":"20"},{"type":"declaration","property":"--font-size-h3","value":"18"},{"type":"comment","comment":" Shadows "},{"type":"declaration","property":"--box-shadow-default","value":"0 0 5px rgba(0, 0, 0, 0.8)"},{"type":"declaration","property":"--text-shadow-default","value":"1px 1px 1px rgba(101, 173, 241, 0.8)"}]},{"type":"comment","comment":" Spacing "},{"type":"rule","selectors":[".p-xl"],"declarations":[{"type":"declaration","property":"padding","value":"var(--spacing-xl)"}]},{"type":"rule","selectors":[".p-l"],"declarations":[{"type":"declaration","property":"padding","value":"var(--spacing-l)"}]},{"type":"rule","selectors":[".p-m"],"declarations":[{"type":"declaration","property":"padding","value":"var(--spacing-m)"}]},{"type":"rule","selectors":[".p-s"],"declarations":[{"type":"declaration","property":"padding","value":"var(--spacing-s)"}]},{"type":"rule","selectors":[".m-xl"],"declarations":[{"type":"declaration","property":"margin","value":"var(--spacing-xl)"}]},{"type":"rule","selectors":[".m-l"],"declarations":[{"type":"declaration","property":"margin","value":"var(--spacing-l)"}]},{"type":"rule","selectors":[".m-m"],"declarations":[{"type":"declaration","property":"margin","value":"var(--spacing-m)"}]},{"type":"rule","selectors":[".m-s"],"declarations":[{"type":"declaration","property":"margin","value":"var(--spacing-s)"}]},{"type":"rule","selectors":[".m-x-l"],"declarations":[{"type":"declaration","property":"margin-left","value":"var(--spacing-l)"},{"type":"declaration","property":"margin-right","value":"var(--spacing-l)"}]},{"type":"rule","selectors":[".m-x-m"],"declarations":[{"type":"declaration","property":"margin-left","value":"var(--spacing-m)"},{"type":"declaration","property":"margin-right","value":"var(--spacing-m)"}]},{"type":"rule","selectors":[".m-x-s"],"declarations":[{"type":"declaration","property":"margin-left","value":"var(--spacing-s)"},{"type":"declaration","property":"margin-right","value":"var(--spacing-s)"}]},{"type":"rule","selectors":[".m-t-xl"],"declarations":[{"type":"declaration","property":"margin-top","value":"var(--spacing-xl)"}]},{"type":"rule","selectors":[".m-t-l"],"declarations":[{"type":"declaration","property":"margin-top","value":"var(--spacing-l)"}]},{"type":"rule","selectors":[".m-t-m"],"declarations":[{"type":"declaration","property":"margin-top","value":"var(--spacing-m)"}]},{"type":"rule","selectors":[".m-t-s"],"declarations":[{"type":"declaration","property":"margin-top","value":"var(--spacing-s)"}]},{"type":"rule","selectors":[".m-b-xl"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"var(--spacing-xl)"}]},{"type":"rule","selectors":[".m-b-l"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"var(--spacing-l)"}]},{"type":"rule","selectors":[".m-b-m"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"var(--spacing-m)"}]},{"type":"rule","selectors":[".m-b-s"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"var(--spacing-s)"}]},{"type":"comment","comment":" Font "},{"type":"rule","selectors":[".font-size-h1"],"declarations":[{"type":"declaration","property":"font-size","value":"var(--font-size-h1)"}]},{"type":"rule","selectors":[".font-size-h2"],"declarations":[{"type":"declaration","property":"font-size","value":"var(--font-size-h2)"}]},{"type":"rule","selectors":[".font-size-h3"],"declarations":[{"type":"declaration","property":"font-size","value":"var(--font-size-h3)"}]},{"type":"comment","comment":" Button "},{"type":"rule","selectors":[".button-primary"],"declarations":[{"type":"declaration","property":"font-size","value":"var(--font-size-h3)"},{"type":"declaration","property":"background-color","value":"var(--color-primary)"},{"type":"declaration","property":"color","value":"var(--color-text-on-primary)"},{"type":"declaration","property":"padding","value":"var(--spacing-l)"},{"type":"declaration","property":"border-radius","value":"var(--border-radius-m)"},{"type":"declaration","property":"text-transform","value":"none"}]},{"type":"rule","selectors":[".button-text"],"declarations":[{"type":"declaration","property":"font-size","value":"var(--font-size-h3)"},{"type":"declaration","property":"color","value":"var(--color-text-gray)"},{"type":"declaration","property":"padding","value":"var(--spacing-l)"},{"type":"declaration","property":"text-transform","value":"none"},{"type":"declaration","property":"background-color","value":"transparent"},{"type":"declaration","property":"border-width","value":"0"},{"type":"declaration","property":"background-color","value":"transparent"},{"type":"declaration","property":"z-index","value":"0"}]},{"type":"rule","selectors":["Page"],"declarations":[{"type":"declaration","property":"background-color","value":"var(--color-bg-default)"}]},{"type":"rule","selectors":["label","TextField"],"declarations":[{"type":"declaration","property":"color","value":"var(--color-text-default)"},{"type":"declaration","property":"font-family","value":"\"Poppins Regular\", Poppins-Regular"},{"type":"declaration","property":"font-weight","value":"400"}]},{"type":"rule","selectors":[".text-color-primary"],"declarations":[{"type":"declaration","property":"color","value":"var(--color-primary)"}]},{"type":"rule","selectors":[".text-color-light"],"declarations":[{"type":"declaration","property":"color","value":"var(--color-bg-default)"}]},{"type":"rule","selectors":[".text-color-gray"],"declarations":[{"type":"declaration","property":"color","value":"var(--color-text-gray)"}]},{"type":"rule","selectors":[".bg-color-primary"],"declarations":[{"type":"declaration","property":"background-color","value":"var(--color-primary)"}]},{"type":"rule","selectors":[".bg-color-default"],"declarations":[{"type":"declaration","property":"background-color","value":"var(--color-bg-default)"}]},{"type":"rule","selectors":[".border-primary"],"declarations":[{"type":"declaration","property":"border-color","value":"var(--color-primary)"},{"type":"declaration","property":"border-width","value":"1"}]},{"type":"rule","selectors":[".border-light"],"declarations":[{"type":"declaration","property":"border-color","value":"var(--color-bg-default)"},{"type":"declaration","property":"border-width","value":"1"}]},{"type":"rule","selectors":[".border-b-primary"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"var(--color-primary)"},{"type":"declaration","property":"border-bottom-width","value":"1"}]},{"type":"rule","selectors":[".border-t-gray"],"declarations":[{"type":"declaration","property":"border-top-color","value":"var(--color-bg-gray) var(--color-text-gray)"},{"type":"declaration","property":"border-top-width","value":"1"}]},{"type":"rule","selectors":[".border-radius-l"],"declarations":[{"type":"declaration","property":"border-radius","value":"var(--border-radius-l)"}]},{"type":"rule","selectors":[".border-radius-m"],"declarations":[{"type":"declaration","property":"border-radius","value":"var(--border-radius-m)"}]},{"type":"rule","selectors":[".border-radius-s"],"declarations":[{"type":"declaration","property":"border-radius","value":"var(--border-radius-s)"}]},{"type":"rule","selectors":[".glow-shadow"],"declarations":[{"type":"declaration","property":"box-shadow","value":"var(--box-shadow-default)"}]},{"type":"rule","selectors":[".title"],"declarations":[{"type":"declaration","property":"text-shadow","value":"var(--text-shadow-default)"}]},{"type":"comment","comment":" alignments "},{"type":"rule","selectors":[".text-center"],"declarations":[{"type":"declaration","property":"text-align","value":"center"}]},{"type":"rule","selectors":[".v-center"],"declarations":[{"type":"declaration","property":"vertical-align","value":"center"}]},{"type":"rule","selectors":[".v-top"],"declarations":[{"type":"declaration","property":"vertical-align","value":"top"}]},{"type":"rule","selectors":[".v-bottom"],"declarations":[{"type":"declaration","property":"vertical-align","value":"bottom"}]},{"type":"rule","selectors":[".h-center"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"center"}]}],"parsingErrors":[]}}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS2JSON_LOADER_EXPORT___);
const { addTaggedAdditionalCSS } = __webpack_require__("./node_modules/@nativescript/core/ui/styling/style-scope.js");
addTaggedAdditionalCSS(___CSS2JSON_LOADER_EXPORT___, "/Users/douglasmachado/Documents/Appium/blogPost/nativescript-movies-demo-master/src/app.css")


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



const routes = [
    { path: "", redirectTo: "/home", pathMatch: "full" },
    {
        path: "home",
        loadChildren: () => __webpack_require__.e(/* import() */ "src_app_features_home_home_module_ts").then(__webpack_require__.bind(__webpack_require__, "./src/app/features/home/home.module.ts")).then((m) => m.HomeModule),
    },
    {
        path: "details",
        loadChildren: () => __webpack_require__.e(/* import() */ "src_app_features_details_details_module_ts").then(__webpack_require__.bind(__webpack_require__, "./src/app/features/details/details.module.ts")).then((m) => m.DetailsModule),
    },
    {
        path: "profile",
        loadChildren: () => __webpack_require__.e(/* import() */ "src_app_features_profile_profile_module_ts").then(__webpack_require__.bind(__webpack_require__, "./src/app/features/profile/profile.module.ts")).then((m) => m.ProfileModule),
    },
    {
        path: "config",
        loadChildren: () => __webpack_require__.e(/* import() */ "src_app_features_config_config_module_ts").then(__webpack_require__.bind(__webpack_require__, "./src/app/features/config/config.module.ts")).then((m) => m.ConfigModule),
    },
    {
        path: "other-apps",
        loadChildren: () => __webpack_require__.e(/* import() */ "src_app_features_other-apps_other-apps_module_ts").then(__webpack_require__.bind(__webpack_require__, "./src/app/features/other-apps/other-apps.module.ts")).then((m) => m.OtherAppsModule),
    },
];
class AppRoutingModule {
}
AppRoutingModule.ɵfac = function AppRoutingModule_Factory(t) { return new (t || AppRoutingModule)(); };
AppRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: AppRoutingModule });
AppRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.NativeScriptRouterModule.forRoot(routes), _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.NativeScriptRouterModule] });


/***/ }),

/***/ "./src/app/app.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./node_modules/@angular/animations/fesm2015/animations.mjs");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _shared_components_layers_alert_popup_alert_popup_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/components/layers/alert-popup/alert-popup.component.ts");
/* harmony import */ var _shared_components_menu_menu_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/menu/menu.component.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");









class AppComponent {
  constructor(layersService) {
    this.layersService = layersService;
    this.menuIsOpen$ = this.layersService.getLayers$().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.map)(state => state.menu.isOpen));
  }

  closeMenu() {
    this.layersService.closeMenu();
  }

}

AppComponent.ɵfac = function AppComponent_Factory(t) {
  return new (t || AppComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_core__WEBPACK_IMPORTED_MODULE_0__.LayersService));
};

AppComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
  type: AppComponent,
  selectors: [["ns-app"]],
  decls: 13,
  vars: 14,
  consts: [[1, "bg-color-default"], ["columns", "*,*", "iosOverflowSafeArea", "false"], ["col", "0"], ["col", "0", "colSpan", "2"], [1, "bg-color-primary"]],
  template: function AppComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "RootLayout", 0)(1, "GridLayout", 1)(2, "ContentView", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](3, "ns-menu");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "GridLayout", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](5, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](6, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](7, "ContentView", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "GridLayout", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](9, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](10, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](11, "page-router-outlet");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](12, "ns-alert-popup", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("glow-shadow", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](5, 6, ctx.menuIsOpen$));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@mainContentShade", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](6, 8, ctx.menuIsOpen$) ? "menuIsOpen" : "menuIsClosed");
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](4);
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵclassProp"]("glow-shadow", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](9, 10, ctx.menuIsOpen$));
      _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("@mainContent", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](10, 12, ctx.menuIsOpen$) ? "menuIsOpen" : "menuIsClosed");
    }
  },
  dependencies: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_5__.PageRouterOutlet, _shared_components_layers_alert_popup_alert_popup_component__WEBPACK_IMPORTED_MODULE_1__.AlertPopupComponent, _shared_components_menu_menu_component__WEBPACK_IMPORTED_MODULE_2__.MenuComponent, _angular_common__WEBPACK_IMPORTED_MODULE_6__.AsyncPipe],
  encapsulation: 2,
  data: {
    animation: [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.trigger)("mainContent", [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)("menuIsOpen", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(200, 70)scale(0.7,0.7)"
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)("menuIsClosed", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(0, 0)scale(1,1)"
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)("menuIsClosed => menuIsOpen", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)("300ms ease-in-out", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(200, 70)scale(0.7,0.7)"
    }))), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)("menuIsOpen => menuIsClosed", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)("300ms ease-in-out", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(0, 0)scale(1,1)"
    })))]), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.trigger)("mainContentShade", [(0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)("menuIsOpen", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(165, 75)scale(0.65,0.65)"
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.state)("menuIsClosed", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(0, 0)scale(1,1)"
    })), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)("menuIsClosed => menuIsOpen", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)("300ms 100ms ease-in-out", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(165, 75)scale(0.65,0.65)"
    }))), (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.transition)("menuIsOpen => menuIsClosed", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.animate)("300ms ease-in-out", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_7__.style)({
      transform: "translate(0, 0)scale(1,1)"
    })))])]
  }
});

/***/ }),

/***/ "./src/app/app.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule),
/* harmony export */   "asyncBoot": () => (/* binding */ asyncBoot)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./node_modules/@angular/common/fesm2015/http.mjs");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@ngxs/store/__ivy_ngcc__/fesm5/ngxs-store.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/app.component.ts");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/app/shared/index.ts");











function asyncBoot() {
  return () => new Promise(resolve => {
    setTimeout(() => {
      resolve();
    }); // }, 1000);
  });
}
class AppModule {}

AppModule.ɵfac = function AppModule_Factory(t) {
  return new (t || AppModule)();
};

AppModule.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
  type: AppModule,
  bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent]
});
AppModule.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjector"]({
  providers: [{
    provide: _angular_core__WEBPACK_IMPORTED_MODULE_5__.APP_INITIALIZER,
    useFactory: asyncBoot,
    multi: true
  }],
  imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_6__.NativeScriptModule, _nativescript_angular__WEBPACK_IMPORTED_MODULE_6__.NativeScriptCommonModule, _nativescript_angular__WEBPACK_IMPORTED_MODULE_6__.NativeScriptHttpClientModule, _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_8__.HttpClientModule, _nativescript_angular__WEBPACK_IMPORTED_MODULE_6__.NativeScriptAnimationsModule, _ngxs_store__WEBPACK_IMPORTED_MODULE_0__.NgxsModule.forRoot([_core__WEBPACK_IMPORTED_MODULE_3__.ConfigState, _core__WEBPACK_IMPORTED_MODULE_3__.ProductState], {
    developmentMode: true
  }), _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule, _shared__WEBPACK_IMPORTED_MODULE_4__.SharedModule]
});

/***/ }),

/***/ "./src/app/core/animations/fade.animation.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fade": () => (/* binding */ Fade)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/animations/fesm2015/animations.mjs");

const Fade = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)("fade", [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(":enter", [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 0 }),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)("300ms 100ms ease-in", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 1 })),
    ]),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(":leave", [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 1 }),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)("300ms 100ms ease-in", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 0 })),
    ]),
]);


/***/ }),

/***/ "./src/app/core/animations/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fade": () => (/* reexport safe */ _fade_animation__WEBPACK_IMPORTED_MODULE_1__.Fade),
/* harmony export */   "SlideUp": () => (/* reexport safe */ _slide_animation__WEBPACK_IMPORTED_MODULE_2__.SlideUp),
/* harmony export */   "SlideUpFadeStagger": () => (/* reexport safe */ _stagger_animation__WEBPACK_IMPORTED_MODULE_0__.SlideUpFadeStagger)
/* harmony export */ });
/* harmony import */ var _stagger_animation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/animations/stagger.animation.ts");
/* harmony import */ var _fade_animation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/animations/fade.animation.ts");
/* harmony import */ var _slide_animation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/animations/slide.animation.ts");





/***/ }),

/***/ "./src/app/core/animations/slide.animation.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SlideUp": () => (/* binding */ SlideUp)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/animations/fesm2015/animations.mjs");

const SlideUp = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)("slideUp", [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(":enter", [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ transform: "translate(0, 100)" }),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)("300ms ease-in-out", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ transform: "translate(0,0)" })),
    ]),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(":leave", [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ transform: "translate(0,0)" }),
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)("300ms cubic-bezier(0.17, 0.89, 0.24, 1.11)", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ transform: "translate(0, 300)" })),
    ]),
]);


/***/ }),

/***/ "./src/app/core/animations/stagger.animation.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SlideUpFadeStagger": () => (/* binding */ SlideUpFadeStagger)
/* harmony export */ });
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/animations/fesm2015/animations.mjs");

const SlideUpFadeStagger = (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.trigger)("slideUpFadeStagger", [
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(":enter", [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(":enter", [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 0, transform: "translate(0, 40)" }),
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.stagger)("50ms", [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)("300ms 300ms", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 1, transform: "tranlsate(0, 0)" })),
            ]),
        ], { optional: true }),
    ]),
    (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.transition)(":leave", [
        (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.query)(":leave", [
            (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.stagger)("50ms", [
                (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.animate)("300ms", (0,_angular_animations__WEBPACK_IMPORTED_MODULE_0__.style)({ opacity: 0, transform: "translate(0, 40)" })),
            ]),
        ], { optional: true }),
    ]),
]);


/***/ }),

/***/ "./src/app/core/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiRoutes": () => (/* reexport safe */ _models__WEBPACK_IMPORTED_MODULE_1__.ApiRoutes),
/* harmony export */   "ApiService": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.ApiService),
/* harmony export */   "Config": () => (/* reexport safe */ _state__WEBPACK_IMPORTED_MODULE_3__.Config),
/* harmony export */   "ConfigState": () => (/* reexport safe */ _state__WEBPACK_IMPORTED_MODULE_3__.ConfigState),
/* harmony export */   "DEFAULT_ANIMATION_CURVE": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.DEFAULT_ANIMATION_CURVE),
/* harmony export */   "DataService": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.DataService),
/* harmony export */   "Fade": () => (/* reexport safe */ _animations__WEBPACK_IMPORTED_MODULE_0__.Fade),
/* harmony export */   "Icons": () => (/* reexport safe */ _models__WEBPACK_IMPORTED_MODULE_1__.Icons),
/* harmony export */   "JsAnimationService": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.JsAnimationService),
/* harmony export */   "LayersService": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.LayersService),
/* harmony export */   "NavigationService": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.NavigationService),
/* harmony export */   "Product": () => (/* reexport safe */ _state__WEBPACK_IMPORTED_MODULE_3__.Product),
/* harmony export */   "ProductState": () => (/* reexport safe */ _state__WEBPACK_IMPORTED_MODULE_3__.ProductState),
/* harmony export */   "Routes": () => (/* reexport safe */ _models__WEBPACK_IMPORTED_MODULE_1__.Routes),
/* harmony export */   "SlideUp": () => (/* reexport safe */ _animations__WEBPACK_IMPORTED_MODULE_0__.SlideUp),
/* harmony export */   "SlideUpFadeStagger": () => (/* reexport safe */ _animations__WEBPACK_IMPORTED_MODULE_0__.SlideUpFadeStagger),
/* harmony export */   "StylingService": () => (/* reexport safe */ _services__WEBPACK_IMPORTED_MODULE_2__.StylingService)
/* harmony export */ });
/* harmony import */ var _animations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/animations/index.ts");
/* harmony import */ var _models__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/models/index.ts");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/services/index.ts");
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/core/state/index.ts");






/***/ }),

/***/ "./src/app/core/models/constants/api-routes.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiRoutes": () => (/* binding */ ApiRoutes)
/* harmony export */ });
const ApiRoutes = {
    productGroups: "/product-groups.json",
    categories: "/categories.json",
    staticText: "/static-text.json",
};


/***/ }),

/***/ "./src/app/core/models/constants/icons.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Icons": () => (/* binding */ Icons)
/* harmony export */ });
const Icons = {
    heart: String.fromCharCode(0xf32e),
    heartOutline: String.fromCharCode(0xf33b),
    play: String.fromCharCode(0xf472),
    back: String.fromCharCode(0xf208),
    star: String.fromCharCode(0xf535),
    menu: String.fromCharCode(0xf3fd),
    close: String.fromCharCode(0xf223),
    home: String.fromCharCode(0xf346),
    account: String.fromCharCode(0xf451),
    downloads: String.fromCharCode(0xf289),
    settings: String.fromCharCode(0xf1a2),
    notifications: String.fromCharCode(0xf421),
    help: String.fromCharCode(0xf18d),
    info: String.fromCharCode(0xf35a),
    share: String.fromCharCode(0xf51a),
    filter: String.fromCharCode(0xf2f5),
    search: String.fromCharCode(0xf505),
    check: String.fromCharCode(0xf207),
    comment: String.fromCharCode(0xf1ec),
    warn: String.fromCharCode(0xf5ba),
    filmOutline: String.fromCharCode(0xf2cc),
    edit: String.fromCharCode(0xf448),
    save: String.fromCharCode(0xf4fa),
};


/***/ }),

/***/ "./src/app/core/models/constants/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiRoutes": () => (/* reexport safe */ _api_routes__WEBPACK_IMPORTED_MODULE_0__.ApiRoutes),
/* harmony export */   "Icons": () => (/* reexport safe */ _icons__WEBPACK_IMPORTED_MODULE_1__.Icons),
/* harmony export */   "Routes": () => (/* reexport safe */ _routes__WEBPACK_IMPORTED_MODULE_2__.Routes)
/* harmony export */ });
/* harmony import */ var _api_routes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/models/constants/api-routes.ts");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/models/constants/icons.ts");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/models/constants/routes.ts");





/***/ }),

/***/ "./src/app/core/models/constants/routes.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Routes": () => (/* binding */ Routes)
/* harmony export */ });
const Routes = {
    home: "/home",
    details: "/details/:id",
    profile: "/profile",
    config: "/config",
};


/***/ }),

/***/ "./src/app/core/models/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiRoutes": () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.ApiRoutes),
/* harmony export */   "Icons": () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.Icons),
/* harmony export */   "Routes": () => (/* reexport safe */ _constants__WEBPACK_IMPORTED_MODULE_0__.Routes)
/* harmony export */ });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/models/constants/index.ts");
/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/models/interfaces/index.ts");




/***/ }),

/***/ "./src/app/core/models/interfaces/category.interface.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/models/interfaces/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _category_interface__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/models/interfaces/category.interface.ts");
/* harmony import */ var _product_interface__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/models/interfaces/product.interface.ts");
/* harmony import */ var _product_group_interface__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/models/interfaces/product-group.interface.ts");
/* harmony import */ var _remote_styles_interface__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/core/models/interfaces/remote-styles.interface.ts");
/* harmony import */ var _profile_interface__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/app/core/models/interfaces/profile.interface.ts");







/***/ }),

/***/ "./src/app/core/models/interfaces/product-group.interface.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/models/interfaces/product.interface.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/models/interfaces/profile.interface.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/models/interfaces/remote-styles.interface.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/services/api.service.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiService": () => (/* binding */ ApiService)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _models_constants_api_routes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/models/constants/api-routes.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/common/fesm2015/http.mjs");





class ApiService {
    constructor(http) {
        this.http = http;
    }
    getProductGroups$(baseUrl) {
        return this.http
            .get(this._formatUrl(baseUrl, _models_constants_api_routes__WEBPACK_IMPORTED_MODULE_0__.ApiRoutes.productGroups))
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((res) => res.productGroups));
    }
    getCategories$(baseUrl) {
        return this.http
            .get(this._formatUrl(baseUrl, _models_constants_api_routes__WEBPACK_IMPORTED_MODULE_0__.ApiRoutes.categories))
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((res) => res.categories));
    }
    getStaticText$(baseUrl) {
        return this.http
            .get(this._formatUrl(baseUrl, _models_constants_api_routes__WEBPACK_IMPORTED_MODULE_0__.ApiRoutes.staticText))
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((res) => res.staticText));
    }
    getRemoteStyles$(styleUrl) {
        return this.http.get(styleUrl, {
            responseType: "text",
        });
    }
    getRemoteStylesOptions$() {
        return this.http
            .get("https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/styles/styles.json", {
            responseType: "json",
        })
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_1__.map)((res) => res === null || res === void 0 ? void 0 : res.styles));
    }
    _formatUrl(baseUrl, extension) {
        if (baseUrl.endsWith("/")) {
            return `${baseUrl}${extension}`.trim();
        }
        return `${baseUrl}/${extension}`.trim();
    }
}
ApiService.ɵfac = function ApiService_Factory(t) { return new (t || ApiService)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient)); };
ApiService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({ token: ApiService, factory: ApiService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "./src/app/core/services/data.service.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");

class DataService {
}
DataService.ɵfac = function DataService_Factory(t) { return new (t || DataService)(); };
DataService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: DataService, factory: DataService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "./src/app/core/services/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApiService": () => (/* reexport safe */ _api_service__WEBPACK_IMPORTED_MODULE_0__.ApiService),
/* harmony export */   "DEFAULT_ANIMATION_CURVE": () => (/* reexport safe */ _ui__WEBPACK_IMPORTED_MODULE_3__.DEFAULT_ANIMATION_CURVE),
/* harmony export */   "DataService": () => (/* reexport safe */ _data_service__WEBPACK_IMPORTED_MODULE_1__.DataService),
/* harmony export */   "JsAnimationService": () => (/* reexport safe */ _ui__WEBPACK_IMPORTED_MODULE_3__.JsAnimationService),
/* harmony export */   "LayersService": () => (/* reexport safe */ _ui__WEBPACK_IMPORTED_MODULE_3__.LayersService),
/* harmony export */   "NavigationService": () => (/* reexport safe */ _navigation_service__WEBPACK_IMPORTED_MODULE_2__.NavigationService),
/* harmony export */   "StylingService": () => (/* reexport safe */ _ui__WEBPACK_IMPORTED_MODULE_3__.StylingService)
/* harmony export */ });
/* harmony import */ var _api_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/services/api.service.ts");
/* harmony import */ var _data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/services/data.service.ts");
/* harmony import */ var _navigation_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/services/navigation.service.ts");
/* harmony import */ var _ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/core/services/ui/index.ts");






/***/ }),

/***/ "./src/app/core/services/navigation.service.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NavigationService": () => (/* binding */ NavigationService)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");



class NavigationService {
    constructor(routerExtensions) {
        this.routerExtensions = routerExtensions;
    }
    navigate(path, params = null, clearHistory = false) {
        const routeArray = [path];
        if (params) {
            if (Array.isArray(params)) {
                routeArray.push(...params);
            }
            else {
                routeArray.push(params);
            }
        }
        this.routerExtensions.navigate(routeArray, { clearHistory: clearHistory });
    }
    back() {
        this.routerExtensions.back();
    }
}
NavigationService.ɵfac = function NavigationService_Factory(t) { return new (t || NavigationService)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.RouterExtensions)); };
NavigationService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({ token: NavigationService, factory: NavigationService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "./src/app/core/services/ui/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DEFAULT_ANIMATION_CURVE": () => (/* reexport safe */ _layers_service__WEBPACK_IMPORTED_MODULE_0__.DEFAULT_ANIMATION_CURVE),
/* harmony export */   "JsAnimationService": () => (/* reexport safe */ _js_animation_service__WEBPACK_IMPORTED_MODULE_2__.JsAnimationService),
/* harmony export */   "LayersService": () => (/* reexport safe */ _layers_service__WEBPACK_IMPORTED_MODULE_0__.LayersService),
/* harmony export */   "StylingService": () => (/* reexport safe */ _stlying_service__WEBPACK_IMPORTED_MODULE_1__.StylingService)
/* harmony export */ });
/* harmony import */ var _layers_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/services/ui/layers.service.ts");
/* harmony import */ var _stlying_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/services/ui/stlying.service.ts");
/* harmony import */ var _js_animation_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/services/ui/js-animation.service.ts");





/***/ }),

/***/ "./src/app/core/services/ui/js-animation.service.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JsAnimationService": () => (/* binding */ JsAnimationService)
/* harmony export */ });
/* harmony import */ var popmotion__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/popmotion/dist/es/animations/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



class JsAnimationService {
    constructor(zone) {
        this.zone = zone;
    }
    animateWithPopmotion(from, to, onUpdate, duration) {
        return new Promise((resolve) => {
            this.zone.runOutsideAngular(() => {
                (0,popmotion__WEBPACK_IMPORTED_MODULE_0__.animate)({
                    from: from,
                    to: to,
                    duration: duration,
                    onUpdate: (latest) => onUpdate(latest),
                    onComplete: () => resolve(),
                });
            });
        });
    }
    animateSpringWithPopmotion(from, to, onUpdate, duration, damping = 10, stiffness = 700) {
        return new Promise((resolve) => {
            this.zone.runOutsideAngular(() => {
                (0,popmotion__WEBPACK_IMPORTED_MODULE_0__.animate)({
                    from: from,
                    to: to,
                    duration: duration,
                    damping: damping,
                    stiffness: stiffness,
                    type: "spring",
                    onUpdate: (latest) => onUpdate(latest),
                    onComplete: () => resolve(),
                });
            });
        });
    }
    animateStretch(view) {
        return this.animateWithPopmotion("1,1", "1.2,0.8", (latest) => {
            const [scaleX, scaleY] = latest.split(",").map((val) => +val);
            view.scaleX = scaleX;
            view.scaleY = scaleY;
        }, 200).then(() => {
            this.animateSpringWithPopmotion("1.2,0.8", "1,1", (latest) => {
                const [scaleX, scaleY] = latest.split(",").map((val) => +val);
                view.scaleX = scaleX;
                view.scaleY = scaleY;
            }, 1000);
        });
    }
}
JsAnimationService.ɵfac = function JsAnimationService_Factory(t) { return new (t || JsAnimationService)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgZone)); };
JsAnimationService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: JsAnimationService, factory: JsAnimationService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "./src/app/core/services/ui/layers.service.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DEFAULT_ANIMATION_CURVE": () => (/* binding */ DEFAULT_ANIMATION_CURVE),
/* harmony export */   "LayersService": () => (/* binding */ LayersService)
/* harmony export */ });
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@nativescript/core/core-types/index.js");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@nativescript/core/ui/dialogs/index.ios.js");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@nativescript/core/ui/layouts/root-layout/root-layout-common.js");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/@nativescript/core/ui/proxy-view-container/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/rxjs/dist/cjs/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");





const DEFAULT_ANIMATION_CURVE = _nativescript_core__WEBPACK_IMPORTED_MODULE_1__.CoreTypes.AnimationCurve.cubicBezier(0.17, 0.89, 0.24, 1.11);
class LayersService {
    constructor(zone, injector, componentFactoryResolver, applicationRef) {
        this.zone = zone;
        this.injector = injector;
        this.componentFactoryResolver = componentFactoryResolver;
        this.applicationRef = applicationRef;
        this._layers$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__.BehaviorSubject({
            menu: {
                isOpen: false,
            },
            alertPopup: {
                isOpen: false,
            },
            quickviewBottomsheet: {
                view: null,
                isAnimating: false,
                productId: undefined,
            },
            searchBottomsheet: {
                view: null,
                isAnimating: false,
            },
            filterBottomsheet: {
                view: null,
                isAnimating: false,
            },
        });
    }
    getLayers$() {
        return this._layers$.asObservable();
    }
    openMenu() {
        _nativescript_core__WEBPACK_IMPORTED_MODULE_3__.Dialogs.confirm("Do you want open menu?").then(function (result) {
            console.log("Dialog result: " + result);
        });
    }
    closeMenu() {
        console.log("Close menu tapped");
    }
    openAlertPopup() {
        this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { alertPopup: {
                isOpen: true,
            } }));
    }
    closeAlertPopup() {
        this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { alertPopup: {
                isOpen: false,
            } }));
    }
    // Quickview Bottomsheet ----------
    openQuickviewBottomsheet(productId) {
        this._getView(_shared__WEBPACK_IMPORTED_MODULE_0__.QuickviewBottomsheetComponent).then((quickviewBottomsheet) => {
            this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { quickviewBottomsheet: {
                    view: quickviewBottomsheet,
                    isAnimating: true,
                    productId: productId,
                } }));
            (0,_nativescript_core__WEBPACK_IMPORTED_MODULE_4__.getRootLayout)()
                .open(quickviewBottomsheet, {
                shadeCover: {
                    color: "#000",
                    opacity: 0.5,
                    tapToClose: true,
                },
                animation: {
                    enterFrom: {
                        translateY: 500,
                        duration: 250,
                        curve: DEFAULT_ANIMATION_CURVE,
                    },
                    exitTo: {
                        translateY: 500,
                        duration: 250,
                        curve: DEFAULT_ANIMATION_CURVE,
                    },
                },
            })
                .then(() => {
                this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { quickviewBottomsheet: Object.assign(Object.assign({}, this.getLayersCurrentValue().quickviewBottomsheet), { isAnimating: false }) }));
            });
        });
    }
    closeQuickviewBottomsheet() {
        const quickViewBottomsheet = this.getLayersCurrentValue()
            .quickviewBottomsheet.view;
        if (quickViewBottomsheet) {
            this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { quickviewBottomsheet: Object.assign(Object.assign({}, this.getLayersCurrentValue().quickviewBottomsheet), { isAnimating: true }) }));
            (0,_nativescript_core__WEBPACK_IMPORTED_MODULE_4__.getRootLayout)()
                .close(quickViewBottomsheet)
                .then(() => {
                this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { quickviewBottomsheet: {
                        view: null,
                        isAnimating: false,
                        productId: undefined,
                    } }));
            });
        }
    }
    // Search Bottomsheet ----------
    openSearchBottomsheet() {
        this._getView(_shared__WEBPACK_IMPORTED_MODULE_0__.SearchBottomsheetComponent).then((searchBottomsheet) => {
            this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { searchBottomsheet: {
                    view: searchBottomsheet,
                    isAnimating: true,
                } }));
            (0,_nativescript_core__WEBPACK_IMPORTED_MODULE_4__.getRootLayout)()
                .open(searchBottomsheet, {
                shadeCover: {
                    color: "#000",
                    opacity: 0.5,
                    tapToClose: true,
                },
                animation: {
                    enterFrom: {
                        translateY: 800,
                        duration: 250,
                        curve: DEFAULT_ANIMATION_CURVE,
                    },
                    exitTo: {
                        translateY: 800,
                        duration: 250,
                        curve: DEFAULT_ANIMATION_CURVE,
                    },
                },
            })
                .then(() => {
                this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { searchBottomsheet: Object.assign(Object.assign({}, this.getLayersCurrentValue().searchBottomsheet), { isAnimating: false }) }));
            });
        });
    }
    closeSearchBottomsheet() {
        const searchBottomsheet = this.getLayersCurrentValue().searchBottomsheet
            .view;
        if (searchBottomsheet) {
            this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { searchBottomsheet: Object.assign(Object.assign({}, this.getLayersCurrentValue().searchBottomsheet), { isAnimating: true }) }));
            (0,_nativescript_core__WEBPACK_IMPORTED_MODULE_4__.getRootLayout)()
                .close(searchBottomsheet)
                .then(() => {
                this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { searchBottomsheet: {
                        view: null,
                        isAnimating: false,
                    } }));
            });
        }
    }
    // Filter Bottomsheet ----------
    openFilterBottomsheet() {
        this._getView(_shared__WEBPACK_IMPORTED_MODULE_0__.FilterBottomsheetComponent).then((filterBottomsheet) => {
            this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { filterBottomsheet: {
                    view: filterBottomsheet,
                    isAnimating: true,
                } }));
            (0,_nativescript_core__WEBPACK_IMPORTED_MODULE_4__.getRootLayout)()
                .open(filterBottomsheet, {
                shadeCover: {
                    color: "#000",
                    opacity: 0.5,
                    tapToClose: true,
                },
                animation: {
                    enterFrom: {
                        translateY: 500,
                        duration: 250,
                        curve: DEFAULT_ANIMATION_CURVE,
                    },
                    exitTo: {
                        translateY: 500,
                        duration: 250,
                        curve: DEFAULT_ANIMATION_CURVE,
                    },
                },
            })
                .then(() => {
                this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { filterBottomsheet: Object.assign(Object.assign({}, this.getLayersCurrentValue().filterBottomsheet), { isAnimating: false }) }));
            });
        });
    }
    closeFilterBottomsheet() {
        const filterBottomsheet = this.getLayersCurrentValue().filterBottomsheet
            .view;
        if (filterBottomsheet) {
            this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { filterBottomsheet: Object.assign(Object.assign({}, this.getLayersCurrentValue().filterBottomsheet), { isAnimating: true }) }));
            (0,_nativescript_core__WEBPACK_IMPORTED_MODULE_4__.getRootLayout)()
                .close(filterBottomsheet)
                .then(() => {
                this._layers$.next(Object.assign(Object.assign({}, this.getLayersCurrentValue()), { filterBottomsheet: {
                        view: null,
                        isAnimating: false,
                    } }));
            });
        }
    }
    getLayersCurrentValue() {
        return this._layers$.value;
    }
    _getView(component) {
        return new Promise((resolve) => {
            const componentFactory = this.componentFactoryResolver.resolveComponentFactory(component);
            this.zone.run(() => {
                const componentRef = componentFactory.create(this.injector);
                let componentView = componentRef.location.nativeElement;
                if (componentView instanceof _nativescript_core__WEBPACK_IMPORTED_MODULE_5__.ProxyViewContainer) {
                    componentView = componentView.getChildAt(0);
                }
                if (componentView.parent) {
                    componentView.parent.removeChild(componentView);
                }
                componentView.__ngRef = componentRef;
                this.applicationRef.attachView(componentRef.hostView);
                componentRef.changeDetectorRef.detectChanges();
                resolve(componentView);
            });
        });
    }
}
LayersService.ɵfac = function LayersService_Factory(t) { return new (t || LayersService)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgZone), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.Injector), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ComponentFactoryResolver), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_6__.ApplicationRef)); };
LayersService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjectable"]({ token: LayersService, factory: LayersService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "./src/app/core/services/ui/stlying.service.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StylingService": () => (/* binding */ StylingService)
/* harmony export */ });
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@nativescript/core/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");


class StylingService {
    constructor() { }
    updateAppCSS(styles) {
        try {
            const sanitizedStyles = styles.replace(/(\r\n|\n|\r)/gm, "");
            _nativescript_core__WEBPACK_IMPORTED_MODULE_0__.Application.addCss(sanitizedStyles);
        }
        catch (err) {
            console.log("error updating app css");
        }
    }
}
StylingService.ɵfac = function StylingService_Factory(t) { return new (t || StylingService)(); };
StylingService.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({ token: StylingService, factory: StylingService.ɵfac, providedIn: "root" });


/***/ }),

/***/ "./src/app/core/state/config/config.actions.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Config": () => (/* binding */ Config)
/* harmony export */ });
var Config;
(function (Config) {
    class UpdateDataUrl {
        constructor(url) {
            this.url = url;
        }
    }
    UpdateDataUrl.type = "[Config] Update Data URL";
    Config.UpdateDataUrl = UpdateDataUrl;
    class UpdateStylingUrl {
        constructor(url) {
            this.url = url;
        }
    }
    UpdateStylingUrl.type = "[Config] Update Styling URL";
    Config.UpdateStylingUrl = UpdateStylingUrl;
    class UpdateStyleOptions {
    }
    UpdateStyleOptions.type = "[Config] Update Style Options";
    Config.UpdateStyleOptions = UpdateStyleOptions;
    class UpdateStaticText {
    }
    UpdateStaticText.type = "[Config] Update Static Text";
    Config.UpdateStaticText = UpdateStaticText;
})(Config || (Config = {}));


/***/ }),

/***/ "./src/app/core/state/config/config.model.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/state/config/config.state.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfigState": () => (/* binding */ ConfigState)
/* harmony export */ });
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@ngxs/store/__ivy_ngcc__/fesm5/ngxs-store.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _config_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/state/config/config.actions.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/rxjs/dist/cjs/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _product__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/core/state/product/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");









let ConfigState = class ConfigState {
    constructor(apiService, stylingService, store) {
        this.apiService = apiService;
        this.stylingService = stylingService;
        this.store = store;
    }
    updateDataUrl(ctx, action) {
        const state = ctx.getState();
        if (action.url) {
            ctx.setState(Object.assign(Object.assign({}, state), { dataUrl: action.url }));
            // TODO: there is a race condition if the dispatch happens at the same time
            this.store
                .dispatch(new _product__WEBPACK_IMPORTED_MODULE_3__.Product.LoadCategories(action.url))
                .toPromise()
                .then(() => this.store.dispatch(new _product__WEBPACK_IMPORTED_MODULE_3__.Product.LoadProductGroups(action.url)));
            return ctx.dispatch([new _config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateStaticText()]);
        }
    }
    updateStylingUrl(ctx, action) {
        const state = ctx.getState();
        if (action.url) {
            ctx.setState(Object.assign(Object.assign({}, state), { stylingUrl: action.url }));
            return this.apiService.getRemoteStyles$(action.url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)((style) => {
                this.stylingService.updateAppCSS(style);
            }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)((err) => {
                console.log("error loading remote style", err);
                return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(err);
            }));
        }
    }
    updateStyleOptions(ctx, action) {
        const state = ctx.getState();
        return this.apiService.getRemoteStylesOptions$().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)((styleOptions) => {
            ctx.setState(Object.assign(Object.assign({}, state), { styleOptions: styleOptions }));
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)((err) => {
            console.log("error loading style options", err);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(err);
        }));
    }
    updateStaticText(ctx) {
        const state = ctx.getState();
        return this.apiService.getStaticText$(state.dataUrl).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)((staticText) => {
            // TODO: add error handling catchError?
            ctx.setState(Object.assign(Object.assign({}, state), { staticText: staticText }));
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.catchError)((err) => {
            console.log("error loading static text", err);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.of)(err);
        }));
    }
    static dataUrl(state) {
        return state.dataUrl;
    }
    static stylingUrl(state) {
        return state.stylingUrl;
    }
    static staticText(state) {
        return state.staticText;
    }
    static styleOptions(state) {
        return state.styleOptions;
    }
};
ConfigState.ɵfac = function ConfigState_Factory(t) { return new (t || ConfigState)(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_app_core__WEBPACK_IMPORTED_MODULE_1__.ApiService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_app_core__WEBPACK_IMPORTED_MODULE_1__.StylingService), _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵinject"](_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Store)); };
ConfigState.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_6__["ɵɵdefineInjectable"]({ token: ConfigState, factory: ConfigState.ɵfac });
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Action)(_config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateDataUrl),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, _config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateDataUrl]),
    __metadata("design:returntype", void 0)
], ConfigState.prototype, "updateDataUrl", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Action)(_config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateStylingUrl),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, _config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateStylingUrl]),
    __metadata("design:returntype", void 0)
], ConfigState.prototype, "updateStylingUrl", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Action)(_config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateStyleOptions),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, _config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateStyleOptions]),
    __metadata("design:returntype", void 0)
], ConfigState.prototype, "updateStyleOptions", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Action)(_config_actions__WEBPACK_IMPORTED_MODULE_2__.Config.UpdateStaticText),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ConfigState.prototype, "updateStaticText", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ConfigState, "dataUrl", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ConfigState, "stylingUrl", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ConfigState, "staticText", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ConfigState, "styleOptions", null);
ConfigState = __decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.State)({
        name: "config",
        defaults: {
            // sample data urls:
            // default: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/
            // travel: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/travel/
            // indo: https://raw.githubusercontent.com/williamjuan027/movies-app-api/translate/indo/data/
            dataUrl: "",
            // sample styling urls:
            // default: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/styles/primary.css
            // greenish: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/styles/greenish.css
            // spotify: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/styles/spotify.css
            // netflix: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/styles/netflix.css
            // airbnb: https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/styles/airbnb.css
            stylingUrl: "",
            styleOptions: [],
            staticText: undefined,
        },
    }),
    __metadata("design:paramtypes", [_app_core__WEBPACK_IMPORTED_MODULE_1__.ApiService,
        _app_core__WEBPACK_IMPORTED_MODULE_1__.StylingService,
        _ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Store])
], ConfigState);



/***/ }),

/***/ "./src/app/core/state/config/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Config": () => (/* reexport safe */ _config_actions__WEBPACK_IMPORTED_MODULE_0__.Config),
/* harmony export */   "ConfigState": () => (/* reexport safe */ _config_state__WEBPACK_IMPORTED_MODULE_2__.ConfigState)
/* harmony export */ });
/* harmony import */ var _config_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/state/config/config.actions.ts");
/* harmony import */ var _config_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/state/config/config.model.ts");
/* harmony import */ var _config_state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/state/config/config.state.ts");





/***/ }),

/***/ "./src/app/core/state/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Config": () => (/* reexport safe */ _config__WEBPACK_IMPORTED_MODULE_0__.Config),
/* harmony export */   "ConfigState": () => (/* reexport safe */ _config__WEBPACK_IMPORTED_MODULE_0__.ConfigState),
/* harmony export */   "Product": () => (/* reexport safe */ _product__WEBPACK_IMPORTED_MODULE_1__.Product),
/* harmony export */   "ProductState": () => (/* reexport safe */ _product__WEBPACK_IMPORTED_MODULE_1__.ProductState)
/* harmony export */ });
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/state/config/index.ts");
/* harmony import */ var _product__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/state/product/index.ts");




/***/ }),

/***/ "./src/app/core/state/product/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Product": () => (/* reexport safe */ _product_actions__WEBPACK_IMPORTED_MODULE_0__.Product),
/* harmony export */   "ProductState": () => (/* reexport safe */ _product_state__WEBPACK_IMPORTED_MODULE_2__.ProductState)
/* harmony export */ });
/* harmony import */ var _product_actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/state/product/product.actions.ts");
/* harmony import */ var _product_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/state/product/product.model.ts");
/* harmony import */ var _product_state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/state/product/product.state.ts");





/***/ }),

/***/ "./src/app/core/state/product/product.actions.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Product": () => (/* binding */ Product)
/* harmony export */ });
var Product;
(function (Product) {
    class LoadCategories {
        constructor(url) {
            this.url = url;
        }
    }
    LoadCategories.type = "[Product] Load Categories";
    Product.LoadCategories = LoadCategories;
    class LoadProductGroups {
        constructor(url) {
            this.url = url;
        }
    }
    LoadProductGroups.type = "[Product] Load Products Groups";
    Product.LoadProductGroups = LoadProductGroups;
})(Product || (Product = {}));


/***/ }),

/***/ "./src/app/core/state/product/product.model.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);



/***/ }),

/***/ "./src/app/core/state/product/product.state.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProductState": () => (/* binding */ ProductState)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/rxjs/dist/cjs/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@ngxs/store/__ivy_ngcc__/fesm5/ngxs-store.js");
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _product_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/core/state/product/product.actions.ts");
/* harmony import */ var _assets_local_data_categories_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/assets/local-data/categories.json");
/* harmony import */ var _assets_local_data_productGroups_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/assets/local-data/productGroups.json");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
var ProductState_1;









let ProductState = ProductState_1 = class ProductState {
    constructor(apiService) {
        this.apiService = apiService;
    }
    loadCategories(ctx, action) {
        const state = ctx.getState();
        return this.apiService.getCategories$(action.url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)((categories) => {
            ctx.setState(Object.assign(Object.assign({}, state), { categories: categories }));
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((err) => {
            console.log("error loading categories", err);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(err);
        }));
    }
    loadProductGroups(ctx, action) {
        const state = ctx.getState();
        return this.apiService.getProductGroups$(action.url).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.tap)((productGroups) => {
            ctx.setState(Object.assign(Object.assign({}, state), { productGroups: productGroups }));
        }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)((err) => {
            console.log("error loading product groups", err);
            return (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.of)(err);
        }));
    }
    static categories(state) {
        return state.categories;
    }
    static productGroups(state) {
        var _a;
        // filter out featured temporarily
        return (((_a = state.productGroups) === null || _a === void 0 ? void 0 : _a.filter((group) => group.groupKey !== "featured")) ||
            []);
    }
    static featuredProduct(state) {
        var _a, _b, _c;
        return (((_c = (_b = (_a = state.productGroups) === null || _a === void 0 ? void 0 : _a.find((group) => group.groupKey === "featured")) === null || _b === void 0 ? void 0 : _b.products) === null || _c === void 0 ? void 0 : _c[0]) || undefined);
    }
    static productById(productId) {
        return (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.createSelector)([ProductState_1], (state) => {
            return state.productGroups
                .reduce((products, productGroups) => {
                products.push(...productGroups.products);
                return products;
            }, [])
                .find((product) => product.id === productId);
        });
    }
};
ProductState.ɵfac = function ProductState_Factory(t) { return new (t || ProductState)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_app_core__WEBPACK_IMPORTED_MODULE_1__.ApiService)); };
ProductState.ɵprov = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({ token: ProductState, factory: ProductState.ɵfac });
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Action)(_product_actions__WEBPACK_IMPORTED_MODULE_2__.Product.LoadCategories),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, _product_actions__WEBPACK_IMPORTED_MODULE_2__.Product.LoadCategories]),
    __metadata("design:returntype", void 0)
], ProductState.prototype, "loadCategories", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Action)(_product_actions__WEBPACK_IMPORTED_MODULE_2__.Product.LoadProductGroups),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, _product_actions__WEBPACK_IMPORTED_MODULE_2__.Product.LoadProductGroups]),
    __metadata("design:returntype", void 0)
], ProductState.prototype, "loadProductGroups", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ProductState, "categories", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ProductState, "productGroups", null);
__decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Selector)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ProductState, "featuredProduct", null);
ProductState = ProductState_1 = __decorate([
    (0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.State)({
        name: "product",
        defaults: {
            categories: _assets_local_data_categories_json__WEBPACK_IMPORTED_MODULE_3__.categories,
            productGroups: _assets_local_data_productGroups_json__WEBPACK_IMPORTED_MODULE_4__.productGroups,
        },
    }),
    __metadata("design:paramtypes", [_app_core__WEBPACK_IMPORTED_MODULE_1__.ApiService])
], ProductState);



/***/ }),

/***/ "./src/app/features/loading/loading.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadingComponent": () => (/* binding */ LoadingComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");

class LoadingComponent {
}
LoadingComponent.ɵfac = function LoadingComponent_Factory(t) { return new (t || LoadingComponent)(); };
LoadingComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: LoadingComponent, selectors: [["ns-loading"]], decls: 2, vars: 3, consts: [["rows", "*", "columns", "*", "height", "100%", "width", "100%"], ["width", "300", "height", "300", "verticalAlignment", "center", "horizontalAlignment", "center", 3, "src", "loop", "autoPlay"]], template: function LoadingComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "LottieView", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", "~/assets/lottie/splashscreen.json")("loop", true)("autoPlay", true);
    } }, encapsulation: 2 });


/***/ }),

/***/ "./src/app/features/loading/loading.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoadingModule": () => (/* binding */ LoadingModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _loading_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/loading/loading.component.ts");
/* harmony import */ var _nativescript_community_ui_lottie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript-community/ui-lottie/lottie.ios.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");






(0,_nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.registerElement)('LottieView', () => _nativescript_community_ui_lottie__WEBPACK_IMPORTED_MODULE_2__.LottieView);
class LoadingModule {
}
LoadingModule.ɵfac = function LoadingModule_Factory(t) { return new (t || LoadingModule)(); };
LoadingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({ type: LoadingModule, bootstrap: [_loading_component__WEBPACK_IMPORTED_MODULE_0__.LoadingComponent] });
LoadingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.NativeScriptModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.NativeScriptCommonModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule] });


/***/ }),

/***/ "./src/app/shared/components/cards/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CARDS_COMPONENTS": () => (/* binding */ CARDS_COMPONENTS),
/* harmony export */   "SearchCardComponent": () => (/* reexport safe */ _search_card_search_card_component__WEBPACK_IMPORTED_MODULE_1__.SearchCardComponent),
/* harmony export */   "ThumbnailCardComponent": () => (/* reexport safe */ _thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_0__.ThumbnailCardComponent)
/* harmony export */ });
/* harmony import */ var _thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/components/cards/thumbnail-card/thumbnail-card.component.ts");
/* harmony import */ var _search_card_search_card_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/components/cards/search-card/search-card.component.ts");


const CARDS_COMPONENTS = [_thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_0__.ThumbnailCardComponent, _search_card_search_card_component__WEBPACK_IMPORTED_MODULE_1__.SearchCardComponent];




/***/ }),

/***/ "./src/app/shared/components/cards/search-card/search-card.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchCardComponent": () => (/* binding */ SearchCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");

class SearchCardComponent {
}
SearchCardComponent.ɵfac = function SearchCardComponent_Factory(t) { return new (t || SearchCardComponent)(); };
SearchCardComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: SearchCardComponent, selectors: [["ns-search-card"]], inputs: { imageSrc: "imageSrc", title: "title", description: "description" }, decls: 5, vars: 3, consts: [["rows", "*", "columns", "auto, 10, *", "marginRight", "10"], ["row", "0", "col", "0", "height", "120", "width", "90", "stretch", "aspectFill", 1, "glow-shadow", 3, "src"], ["row", "0", "col", "2"], ["fontSize", "25", "textWrap", "true", 1, "bold", 3, "text"], ["textWrap", "true", "fontSize", "18", 3, "text"]], template: function SearchCardComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "Image", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "StackLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "Label", 3)(4, "Label", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.imageSrc);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", ctx.title);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", ctx.description.substring(0, 60) + "...");
    } }, encapsulation: 2 });


/***/ }),

/***/ "./src/app/shared/components/cards/thumbnail-card/thumbnail-card.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ThumbnailCardComponent": () => (/* binding */ ThumbnailCardComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");

class ThumbnailCardComponent {
}
ThumbnailCardComponent.ɵfac = function ThumbnailCardComponent_Factory(t) { return new (t || ThumbnailCardComponent)(); };
ThumbnailCardComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: ThumbnailCardComponent, selectors: [["ns-thumbnail-card"]], inputs: { imageSrc: "imageSrc" }, decls: 4, vars: 1, consts: [["height", "160", "width", "125", "rows", "*", "columns", "*", "marginRight", "10"], ["height", "95%", "width", "95%", 1, "glow-shadow"], [1, "bg-color-default", "border-radius-m"], ["stretch", "aspectFill", 3, "src"]], template: function ThumbnailCardComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "ContentView", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](2, "GridLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](3, "Image", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("src", ctx.imageSrc);
    } }, encapsulation: 2 });


/***/ }),

/***/ "./src/app/shared/components/header/header.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/core/platform/index.ios.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");





function HeaderComponent_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "GridLayout", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function HeaderComponent_ng_container_1_Template_GridLayout_tap_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r4); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r3.back()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.icons.back);
} }
function HeaderComponent_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "GridLayout", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function HeaderComponent_ng_container_2_Template_GridLayout_tap_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r6); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r5.openMenu()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r1.icons.menu);
} }
function HeaderComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "GridLayout", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function HeaderComponent_ng_container_3_Template_GridLayout_tap_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r8); const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r7.rightActionButton.onTap()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r2.rightActionButton.icon);
} }
class HeaderComponent {
    constructor(navigationService, layersService) {
        this.navigationService = navigationService;
        this.layersService = layersService;
        this.icons = _app_core__WEBPACK_IMPORTED_MODULE_0__.Icons;
        this.ios = _nativescript_core__WEBPACK_IMPORTED_MODULE_2__.isIOS;
    }
    back() {
        this.navigationService.back();
    }
    openMenu() {
        this.layersService.openMenu();
    }
}
HeaderComponent.ɵfac = function HeaderComponent_Factory(t) { return new (t || HeaderComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.NavigationService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.LayersService)); };
HeaderComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: HeaderComponent, selectors: [["ns-header"]], inputs: { headerTitle: "headerTitle", hasBackButton: "hasBackButton", hasMenuButton: "hasMenuButton", rightActionButton: "rightActionButton" }, decls: 6, vars: 8, consts: [["verticalAlignment", "top", "row", "0", "rows", "*", "columns", "60, *, auto, *, 60", 3, "height", "padding"], [4, "ngIf"], ["row", "0", "col", "2", "verticalAlignment", "center", "horizontalAlignment", "center", 1, "bold", "text-color-primary", "font-size-h2", "title", 3, "text"], ["row", "0", "col", "0", "padding", "10", 3, "tap"], ["verticalAlignment", "center", "color", "#fff", "fontSize", "25", 1, "ionicons", "title", 3, "text"], ["verticalAlignment", "center", "testID", "navBarLeftButton", 1, "ionicons", "font-size-h1", "text-color-gray", 3, "text"], ["row", "0", "col", "4", "padding", "10", 3, "tap"], ["verticalAlignment", "center", "textAlignment", "right", "testID", "navBarRightButton", 1, "ionicons", "font-size-h1", "text-color-gray", 3, "text"]], template: function HeaderComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](1, HeaderComponent_ng_container_1_Template, 3, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, HeaderComponent_ng_container_2_Template, 3, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, HeaderComponent_ng_container_3_Template, 3, 1, "ng-container", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "Label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipe"](5, "uppercase");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("height", ctx.ios ? 60 : 82)("padding", ctx.ios ? "0" : "22 0 0");
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.hasBackButton);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.hasMenuButton);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.rightActionButton);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵpipeBind1"](5, 6, ctx.headerTitle));
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_3__.UpperCasePipe], encapsulation: 2 });


/***/ }),

/***/ "./src/app/shared/components/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertPopupComponent": () => (/* reexport safe */ _layers__WEBPACK_IMPORTED_MODULE_1__.AlertPopupComponent),
/* harmony export */   "CARDS_COMPONENTS": () => (/* reexport safe */ _cards__WEBPACK_IMPORTED_MODULE_0__.CARDS_COMPONENTS),
/* harmony export */   "COMPONENTS": () => (/* binding */ COMPONENTS),
/* harmony export */   "FilterBottomsheetComponent": () => (/* reexport safe */ _layers__WEBPACK_IMPORTED_MODULE_1__.FilterBottomsheetComponent),
/* harmony export */   "HeaderComponent": () => (/* reexport safe */ _header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent),
/* harmony export */   "LAYERS": () => (/* reexport safe */ _layers__WEBPACK_IMPORTED_MODULE_1__.LAYERS),
/* harmony export */   "MenuComponent": () => (/* reexport safe */ _menu_menu_component__WEBPACK_IMPORTED_MODULE_3__.MenuComponent),
/* harmony export */   "QuickviewBottomsheetComponent": () => (/* reexport safe */ _layers__WEBPACK_IMPORTED_MODULE_1__.QuickviewBottomsheetComponent),
/* harmony export */   "SearchBottomsheetComponent": () => (/* reexport safe */ _layers__WEBPACK_IMPORTED_MODULE_1__.SearchBottomsheetComponent),
/* harmony export */   "SearchCardComponent": () => (/* reexport safe */ _cards__WEBPACK_IMPORTED_MODULE_0__.SearchCardComponent),
/* harmony export */   "TagComponent": () => (/* reexport safe */ _tag_tag_component__WEBPACK_IMPORTED_MODULE_4__.TagComponent),
/* harmony export */   "ThumbnailCardComponent": () => (/* reexport safe */ _cards__WEBPACK_IMPORTED_MODULE_0__.ThumbnailCardComponent)
/* harmony export */ });
/* harmony import */ var _cards__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/components/cards/index.ts");
/* harmony import */ var _layers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/components/layers/index.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/header/header.component.ts");
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/shared/components/menu/menu.component.ts");
/* harmony import */ var _tag_tag_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/app/shared/components/tag/tag.component.ts");





const COMPONENTS = [
    ..._cards__WEBPACK_IMPORTED_MODULE_0__.CARDS_COMPONENTS,
    ..._layers__WEBPACK_IMPORTED_MODULE_1__.LAYERS,
    _header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent,
    _menu_menu_component__WEBPACK_IMPORTED_MODULE_3__.MenuComponent,
    _tag_tag_component__WEBPACK_IMPORTED_MODULE_4__.TagComponent,
];







/***/ }),

/***/ "./src/app/shared/components/layers/alert-popup/alert-popup.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertPopupComponent": () => (/* binding */ AlertPopupComponent)
/* harmony export */ });
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/rxjs/dist/cjs/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");





class AlertPopupComponent {
    constructor(layersService, jsAnimationService) {
        this.layersService = layersService;
        this.jsAnimationService = jsAnimationService;
        this._isAnimating = false;
        this._alertIsOpen = false;
        this._destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.Subject();
    }
    ngOnInit() {
        this.layersService
            .getLayers$()
            .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)((layers) => layers.alertPopup.isOpen), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.skipWhile)((isOpen) => isOpen === this._alertIsOpen), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.distinctUntilChanged)(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.takeUntil)(this._destroy$))
            .subscribe((isOpen) => {
            if (isOpen) {
                this._animateOpen();
            }
            else {
                this._animateClose();
            }
        });
    }
    ngDoCheck() {
        // without calling popmotion outside of Angular Zone, this will be triggered multiple times
        // uncomment next line to see that in effect
        // console.log("ngDoCheck");
    }
    ngOnDestroy() {
        this._destroy$.next(true);
        this._destroy$.complete();
    }
    popupContainerLoaded(args) {
        this._popupContainer = args.object;
        this._popupContainer.visibility = "collapsed";
    }
    close() {
        if (this._isAnimating) {
            return;
        }
        this.layersService.closeAlertPopup();
    }
    animateStretch() {
        if (this._popupContainer) {
            if (this._isAnimating) {
                return;
            }
            this._isAnimating = true;
            this.jsAnimationService
                .animateStretch(this._popupContainer)
                .then(() => {
                this._isAnimating = false;
            })
                .catch((err) => {
                this._isAnimating = false;
            });
        }
    }
    _animateOpen() {
        this._popupContainer.scaleX = 0;
        this._popupContainer.scaleY = 0;
        this._popupContainer.opacity = 0;
        this._popupContainer.visibility = "visible";
        this.jsAnimationService
            .animateWithPopmotion("0,0,0", "1.1,1.1,1", (latest) => {
            const [scaleX, scaleY, opacity] = latest
                .split(",")
                .map((val) => +val);
            this._popupContainer.scaleX = scaleX;
            this._popupContainer.scaleY = scaleY;
            this._popupContainer.opacity = opacity;
        }, 200)
            .then(() => {
            this.jsAnimationService
                .animateSpringWithPopmotion("1.1,1.1", "1,1", (latest) => {
                const [scaleX, scaleY] = latest.split(",").map((val) => +val);
                this._popupContainer.scaleX = scaleX;
                this._popupContainer.scaleY = scaleY;
            }, 1000)
                .then(() => {
                this._alertIsOpen = true;
            });
        });
    }
    _animateClose() {
        this.jsAnimationService
            .animateWithPopmotion("1,1,1", "0,0,0", (latest) => {
            const [scaleX, scaleY, opacity] = latest
                .split(",")
                .map((val) => +val);
            this._popupContainer.scaleX = scaleX;
            this._popupContainer.scaleY = scaleY;
            this._popupContainer.opacity = opacity;
        }, 200)
            .then(() => {
            this._popupContainer.visibility = "collapsed";
            this._alertIsOpen = false;
        });
    }
}
AlertPopupComponent.ɵfac = function AlertPopupComponent_Factory(t) { return new (t || AlertPopupComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.LayersService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.JsAnimationService)); };
AlertPopupComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({ type: AlertPopupComponent, selectors: [["ns-alert-popup"]], decls: 12, vars: 0, consts: [["opacity", "0", 1, "v-center", "h-center", 3, "loaded"], ["rows", "auto, auto, auto, auto", "androidElevation", "15", 1, "p-xl", "bg-color-default", "border-radius-m", "m-l"], ["row", "0", "text", "ALERT!!!", 1, "bold", "font-size-h1", "text-color-primary", "text-center"], ["row", "1", "textWrap", "true", 1, "font-size-h3", "text-color-gray", "text-center", "m-t-xl"], ["text", "You just got a bouncy popup powered by "], ["text", "Popmotion ", 1, "medium", "text-color-primary"], ["text", "in "], ["text", "Nativescript", 1, "medium", "text-color-primary"], ["text", "\uD83E\uDD73\uD83C\uDF89"], ["row", "2", "text", "animate", "testID", "animateButton", 1, "button-primary", "m-t-xl", "m-x-l", 3, "tap"], ["row", "3", "text", "close", "testID", "closeButton", 1, "button-text", "m-t-s", "m-x-l", 3, "tap"]], template: function AlertPopupComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("loaded", function AlertPopupComponent_Template_GridLayout_loaded_0_listener($event) { return ctx.popupContainerLoaded($event); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "GridLayout", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "Label", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "Label", 3)(4, "FormattedString");
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "Span", 4)(6, "Span", 5)(7, "Span", 6)(8, "Span", 7)(9, "Span", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](10, "Button", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("tap", function AlertPopupComponent_Template_Button_tap_10_listener() { return ctx.animateStretch(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](11, "Button", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("tap", function AlertPopupComponent_Template_Button_tap_11_listener() { return ctx.close(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    } }, encapsulation: 2 });


/***/ }),

/***/ "./src/app/shared/components/layers/filter-bottomsheet/filter-bottomsheet.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterBottomsheetComponent": () => (/* binding */ FilterBottomsheetComponent)
/* harmony export */ });
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _tag_tag_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/components/tag/tag.component.ts");





function FilterBottomsheetComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ContentView", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "ns-tag", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const tag_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("tagText", tag_r2.text)("selected", tag_r2.selected);
} }
function FilterBottomsheetComponent_ng_container_10_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](1, "ContentView", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](2, "ns-tag", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const tag_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("tagText", tag_r3.text)("selected", tag_r3.selected);
} }
class FilterBottomsheetComponent {
    constructor(layersService) {
        this.layersService = layersService;
        this.icons = _app_core__WEBPACK_IMPORTED_MODULE_0__.Icons;
        this.languageTags = [
            { text: "English", selected: true },
            { text: "Spanish", selected: false },
            { text: "French", selected: false },
        ];
        this.durationTags = [
            { text: "Short", selected: true },
            { text: "Medium", selected: false },
            { text: "Long", selected: false },
        ];
    }
    shadeLoaded(args) {
        this._shade = args.object;
        setTimeout(() => {
            this._shade.animate({
                opacity: 1,
                duration: 150,
            });
        }, 100);
    }
    apply() {
        this.close();
    }
    close() {
        this._shade.animate({
            opacity: 0,
            duration: 100,
        });
        setTimeout(() => {
            this.layersService.closeFilterBottomsheet();
        }, 50);
    }
}
FilterBottomsheetComponent.ɵfac = function FilterBottomsheetComponent_Factory(t) { return new (t || FilterBottomsheetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.LayersService)); };
FilterBottomsheetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineComponent"]({ type: FilterBottomsheetComponent, selectors: [["ns-filter-bottomsheet"]], decls: 13, vars: 2, consts: [["verticalAlignment", "bottom", "rows", "*", "height", "100%"], ["opacity", "0", "row", "0", "backgroundColor", "rgba(0,0,0,0.3)", 3, "loaded", "tap"], ["row", "0", "verticalAlignment", "bottom", "rows", "auto, auto, auto", "columns", "*", "borderRadius", "15 15 0 0", 1, "bg-color-default"], ["row", "0", "col", "0", "text", "FILTER", "margin", "25", "fontSize", "30", 1, "bold", "text-color-primary"], ["row", "1", "col", "0", "padding", "0 25 20 25"], ["text", "Language", "marginBottom", "10", "fontSize", "20", 1, "medium"], [4, "ngFor", "ngForOf"], ["text", "Duration", "margin", "15 0 10 0", "fontSize", "20", 1, "medium"], ["row", "2", "col", "0", "padding", "15", 1, "bg-color-primary", 3, "tap"], ["text", "APPLY", "textAlignment", "center", "fontSize", "20", "color", "#fff", "testID", "applyButton", 1, "medium"], ["marginRight", "10"], [3, "tagText", "selected"]], template: function FilterBottomsheetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](0, "GridLayout", 0)(1, "ContentView", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("loaded", function FilterBottomsheetComponent_Template_ContentView_loaded_1_listener($event) { return ctx.shadeLoaded($event); })("tap", function FilterBottomsheetComponent_Template_ContentView_tap_1_listener() { return ctx.close(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](2, "GridLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](3, "Label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](4, "StackLayout", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](5, "Label", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](6, "FlexboxLayout");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](7, FilterBottomsheetComponent_ng_container_7_Template, 3, 2, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](8, "Label", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](9, "FlexboxLayout");
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵtemplate"](10, FilterBottomsheetComponent_ng_container_10_Template, 3, 2, "ng-container", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementStart"](11, "GridLayout", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵlistener"]("tap", function FilterBottomsheetComponent_Template_GridLayout_tap_11_listener() { return ctx.apply(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelement"](12, "Label", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵelementEnd"]()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.languageTags);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵproperty"]("ngForOf", ctx.durationTags);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_3__.NgForOf, _tag_tag_component__WEBPACK_IMPORTED_MODULE_1__.TagComponent], encapsulation: 2, data: { animation: [_app_core__WEBPACK_IMPORTED_MODULE_0__.Fade] } });


/***/ }),

/***/ "./src/app/shared/components/layers/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertPopupComponent": () => (/* reexport safe */ _alert_popup_alert_popup_component__WEBPACK_IMPORTED_MODULE_3__.AlertPopupComponent),
/* harmony export */   "FilterBottomsheetComponent": () => (/* reexport safe */ _filter_bottomsheet_filter_bottomsheet_component__WEBPACK_IMPORTED_MODULE_2__.FilterBottomsheetComponent),
/* harmony export */   "LAYERS": () => (/* binding */ LAYERS),
/* harmony export */   "QuickviewBottomsheetComponent": () => (/* reexport safe */ _quickview_bottomsheet_quickview_bottomsheet_component__WEBPACK_IMPORTED_MODULE_0__.QuickviewBottomsheetComponent),
/* harmony export */   "SearchBottomsheetComponent": () => (/* reexport safe */ _search_bottomsheet_search_bottomsheet_component__WEBPACK_IMPORTED_MODULE_1__.SearchBottomsheetComponent)
/* harmony export */ });
/* harmony import */ var _quickview_bottomsheet_quickview_bottomsheet_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/components/layers/quickview-bottomsheet/quickview-bottomsheet.component.ts");
/* harmony import */ var _search_bottomsheet_search_bottomsheet_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/components/layers/search-bottomsheet/search-bottomsheet.component.ts");
/* harmony import */ var _filter_bottomsheet_filter_bottomsheet_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/layers/filter-bottomsheet/filter-bottomsheet.component.ts");
/* harmony import */ var _alert_popup_alert_popup_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/shared/components/layers/alert-popup/alert-popup.component.ts");




const LAYERS = [
    _quickview_bottomsheet_quickview_bottomsheet_component__WEBPACK_IMPORTED_MODULE_0__.QuickviewBottomsheetComponent,
    _search_bottomsheet_search_bottomsheet_component__WEBPACK_IMPORTED_MODULE_1__.SearchBottomsheetComponent,
    _filter_bottomsheet_filter_bottomsheet_component__WEBPACK_IMPORTED_MODULE_2__.FilterBottomsheetComponent,
    _alert_popup_alert_popup_component__WEBPACK_IMPORTED_MODULE_3__.AlertPopupComponent
];






/***/ }),

/***/ "./src/app/shared/components/layers/quickview-bottomsheet/quickview-bottomsheet.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QuickviewBottomsheetComponent": () => (/* binding */ QuickviewBottomsheetComponent)
/* harmony export */ });
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@ngxs/store/__ivy_ngcc__/fesm5/ngxs-store.js");
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _cards_thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/cards/thumbnail-card/thumbnail-card.component.ts");









function QuickviewBottomsheetComponent_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "ContentView", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ns-thumbnail-card", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "StackLayout", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "Label", 8)(5, "Label", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const productDetails_r1 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("imageSrc", productDetails_r1.image.thumbnail);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", productDetails_r1.title);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", productDetails_r1.description.substring(0, 90) + "...");
  }
}

class QuickviewBottomsheetComponent {
  constructor(store, layersService, navigationService) {
    this.store = store;
    this.layersService = layersService;
    this.navigationService = navigationService;
    this.state$ = this.layersService.getLayers$().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(layers => layers.quickviewBottomsheet));
    this.productDetails$ = this.state$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)(state => state.productId), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(productId => this._productId = productId), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.switchMap)(productId => this.store.select(_app_core__WEBPACK_IMPORTED_MODULE_1__.ProductState.productById(productId))));
    this.icons = _app_core__WEBPACK_IMPORTED_MODULE_1__.Icons;
  }

  close() {
    this.layersService.closeQuickviewBottomsheet();
  }

  navigateToProductDetails() {
    this.navigationService.navigate(_app_core__WEBPACK_IMPORTED_MODULE_1__.Routes.details, {
      id: this._productId
    });
    this.close();
  }

}

QuickviewBottomsheetComponent.ɵfac = function QuickviewBottomsheetComponent_Factory(t) {
  return new (t || QuickviewBottomsheetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Store), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_1__.LayersService), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_1__.NavigationService));
};

QuickviewBottomsheetComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: QuickviewBottomsheetComponent,
  selectors: [["ns-quickview-bottomsheet"]],
  decls: 6,
  vars: 4,
  consts: [["verticalAlignment", "bottom", "padding", "20", "rows", "auto, auto", "columns", "auto, *", "borderRadius", "15 15 0 0", 1, "bg-color-default", 3, "tap"], [4, "ngIf"], ["row", "1", "col", "0", "colSpan", "2", "rows", "auto", "columns", "auto, *", "padding", "10 5 0 5", 1, "m-t-l", "border-t-gray"], ["col", "0", "fontSize", "20", "marginRight", "5", 1, "ionicons", "text-color-gray", 3, "text"], ["col", "1", "text", "Details and More", "fontSize", "18", 1, "text-color-gray"], ["row", "0", "col", "0"], [3, "imageSrc"], ["row", "0", "col", "1", "padding", "10 10 15 10"], ["fontSize", "30", "textWrap", "true", 1, "bold", 3, "text"], ["textWrap", "true", "fontSize", "18", 1, "text-color-gray", 3, "text"]],
  template: function QuickviewBottomsheetComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "GridLayout", 0);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("tap", function QuickviewBottomsheetComponent_Template_GridLayout_tap_0_listener() {
        return ctx.navigateToProductDetails();
      });
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, QuickviewBottomsheetComponent_ng_container_1_Template, 6, 3, "ng-container", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](2, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](3, "GridLayout", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](4, "Label", 3)(5, "Label", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()();
    }

    if (rf & 2) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](2, 2, ctx.productDetails$));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", ctx.icons.info);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_5__.NgIf, _cards_thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_2__.ThumbnailCardComponent, _angular_common__WEBPACK_IMPORTED_MODULE_5__.AsyncPipe],
  encapsulation: 2
});

/***/ }),

/***/ "./src/app/shared/components/layers/search-bottomsheet/search-bottomsheet.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SearchBottomsheetComponent": () => (/* binding */ SearchBottomsheetComponent)
/* harmony export */ });
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



class SearchBottomsheetComponent {
    // categories$ = this.dataService.getCategories();
    // searchResult$ = this.dataService.getRecommendedMovies();
    constructor(dataService, layersService, navigationService) {
        this.dataService = dataService;
        this.layersService = layersService;
        this.navigationService = navigationService;
        // @Select(ProductState.categories) categories$;
        this.icons = _app_core__WEBPACK_IMPORTED_MODULE_0__.Icons;
    }
    openFilterBottomsheet() {
        this.layersService.openFilterBottomsheet();
    }
    close() {
        this.layersService.closeSearchBottomsheet();
    }
    navigateToMovieDetails(movieId) {
        this.navigationService.navigate(_app_core__WEBPACK_IMPORTED_MODULE_0__.Routes.details, { id: movieId });
        this.close();
    }
}
SearchBottomsheetComponent.ɵfac = function SearchBottomsheetComponent_Factory(t) { return new (t || SearchBottomsheetComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.DataService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.LayersService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.NavigationService)); };
SearchBottomsheetComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: SearchBottomsheetComponent, selectors: [["ns-search-bottomsheet"]], decls: 11, vars: 2, consts: [["verticalAlignment", "bottom", "paddingTop", "25", "rows", "auto, auto, auto, auto", "columns", "*, auto", "borderRadius", "15 15 0 0", 1, "bg-color-default"], ["row", "0", "col", "0", "margin", "0 25", "text", "SEARCH", "fontSize", "30", "testID", "searchTitle", 1, "bold", "text-color-primary"], ["row", "0", "col", "1", "padding", "10", "margin", "0 25", 3, "tap"], ["verticalAlignment", "center", "textAlignment", "right", "color", "#444", "fontSize", "25", "testID", "searchIcon", 1, "ionicons", 3, "text"], ["row", "1", "col", "0", "colSpan", "2", "columns", "auto, *", "margin", "15 25 0 25", "padding", "10", "borderRadius", "10", "backgroundColor", "#eee"], ["col", "0", "verticalAlignment", "center", "color", "#777", "fontSize", "25", 1, "ionicons", 3, "text"], ["col", "1", "marginLeft", "10", "fontSize", "20", "hint", "Batman", "testID", "input"], ["row", "2", "col", "0", "colSpan", "2", "orientation", "horizontal", "width", "100%"], ["orientation", "horizontal", "padding", "10 25"], ["row", "3", "col", "0", "colSpan", "2", "height", "400"], ["margin", "10 25 25 25"]], template: function SearchBottomsheetComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "Label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "GridLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function SearchBottomsheetComponent_Template_GridLayout_tap_2_listener() { return ctx.openFilterBottomsheet(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "Label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "GridLayout", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "Label", 5)(6, "TextField", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](7, "ScrollView", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](8, "StackLayout", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](9, "ScrollView", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](10, "StackLayout", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx.icons.filter);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx.icons.search);
    } }, encapsulation: 2 });


/***/ }),

/***/ "./src/app/shared/components/menu/menu.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuComponent": () => (/* binding */ MenuComponent)
/* harmony export */ });
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");




function MenuComponent_ng_container_4_Template(rf, ctx) { if (rf & 1) {
    const _r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "GridLayout", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function MenuComponent_ng_container_4_Template_GridLayout_tap_1_listener() { const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r3); const option_r1 = restoredCtx.$implicit; return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](option_r1.onTap && option_r1.onTap()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 6)(3, "Label", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const option_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", option_r1.icon);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", option_r1.displayName);
} }
class MenuComponent {
    constructor(layersService, navigationService) {
        this.layersService = layersService;
        this.navigationService = navigationService;
        this.icons = _app_core__WEBPACK_IMPORTED_MODULE_0__.Icons;
        this.menuOptions = [
            {
                displayName: "Home",
                icon: this.icons.home,
                onTap: () => {
                    this.navigationService.navigate(_app_core__WEBPACK_IMPORTED_MODULE_0__.Routes.home, null, true);
                    this.closeMenu();
                },
            },
            {
                displayName: "Profile",
                icon: this.icons.account,
                onTap: () => {
                    this.navigationService.navigate(_app_core__WEBPACK_IMPORTED_MODULE_0__.Routes.profile, null, true);
                    this.closeMenu();
                },
            },
            { displayName: "Downloads", icon: this.icons.downloads },
            {
                displayName: "Settings",
                icon: this.icons.settings,
                onTap: () => {
                    this.navigationService.navigate(_app_core__WEBPACK_IMPORTED_MODULE_0__.Routes.config, null, true);
                    this.closeMenu();
                },
            },
            { displayName: "Help", icon: this.icons.help },
        ];
    }
    closeMenu() {
        this.layersService.closeMenu();
    }
}
MenuComponent.ɵfac = function MenuComponent_Factory(t) { return new (t || MenuComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.LayersService), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdirectiveInject"](_app_core__WEBPACK_IMPORTED_MODULE_0__.NavigationService)); };
MenuComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: MenuComponent, selectors: [["ns-menu"]], decls: 5, vars: 2, consts: [["paddingTop", "30"], ["color", "#444", "fontSize", "40", "padding", "20", 1, "ionicons", 3, "text", "tap"], ["margin", "15 20 0 25", "text", "Hello", "fontSize", "25", 1, "bold", "text-color-gray"], ["margin", "-5 20 20 25", "text", "Luca", "fontSize", "40", 1, "bold", "text-color-gray"], [4, "ngFor", "ngForOf"], ["columns", "40, 10, *", "rows", "auto", "padding", "10 15 10 25", 3, "tap"], ["col", "0", "fontSize", "25", 1, "ionicons", "text-color-gray", 3, "text"], ["col", "2", "fontSize", "20", 1, "text-color-gray", 3, "text"]], template: function MenuComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "StackLayout", 0)(1, "Label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function MenuComponent_Template_Label_tap_1_listener() { return ctx.closeMenu(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 2)(3, "Label", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, MenuComponent_ng_container_4_Template, 4, 2, "ng-container", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx.icons.close);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx.menuOptions);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf], encapsulation: 2, data: { animation: [_app_core__WEBPACK_IMPORTED_MODULE_0__.SlideUpFadeStagger] } });


/***/ }),

/***/ "./src/app/shared/components/tag/tag.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TagComponent": () => (/* binding */ TagComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");

class TagComponent {
    constructor() {
        this.selected = false;
    }
}
TagComponent.ɵfac = function TagComponent_Factory(t) { return new (t || TagComponent)(); };
TagComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineComponent"]({ type: TagComponent, selectors: [["ns-tag"]], inputs: { tagText: "tagText", selected: "selected" }, decls: 2, vars: 9, consts: [["rows", "auto", "columns", "auto", "padding", "8 15", "borderRadius", "20", 1, "border-primary"], ["fontSize", "18", 1, "medium", 3, "text"]], template: function TagComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelement"](1, "Label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("bg-color-primary", ctx.selected)("bg-color-default", !ctx.selected);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵadvance"](1);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵclassProp"]("text-color-light", ctx.selected)("text-color-primary", !ctx.selected);
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵproperty"]("text", ctx.tagText);
    } }, encapsulation: 2 });


/***/ }),

/***/ "./src/app/shared/index.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertPopupComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.AlertPopupComponent),
/* harmony export */   "CARDS_COMPONENTS": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.CARDS_COMPONENTS),
/* harmony export */   "COMPONENTS": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.COMPONENTS),
/* harmony export */   "FilterBottomsheetComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.FilterBottomsheetComponent),
/* harmony export */   "HeaderComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.HeaderComponent),
/* harmony export */   "LAYERS": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.LAYERS),
/* harmony export */   "MenuComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.MenuComponent),
/* harmony export */   "QuickviewBottomsheetComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.QuickviewBottomsheetComponent),
/* harmony export */   "SearchBottomsheetComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.SearchBottomsheetComponent),
/* harmony export */   "SearchCardComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.SearchCardComponent),
/* harmony export */   "SharedModule": () => (/* reexport safe */ _shared_module__WEBPACK_IMPORTED_MODULE_1__.SharedModule),
/* harmony export */   "TagComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.TagComponent),
/* harmony export */   "ThumbnailCardComponent": () => (/* reexport safe */ _components__WEBPACK_IMPORTED_MODULE_0__.ThumbnailCardComponent)
/* harmony export */ });
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/components/index.ts");
/* harmony import */ var _shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/shared.module.ts");




/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SharedModule": () => (/* binding */ SharedModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _components_cards_thumbnail_card_thumbnail_card_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/components/cards/thumbnail-card/thumbnail-card.component.ts");
/* harmony import */ var _components_cards_search_card_search_card_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/shared/components/cards/search-card/search-card.component.ts");
/* harmony import */ var _components_layers_quickview_bottomsheet_quickview_bottomsheet_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/layers/quickview-bottomsheet/quickview-bottomsheet.component.ts");
/* harmony import */ var _components_layers_search_bottomsheet_search_bottomsheet_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./src/app/shared/components/layers/search-bottomsheet/search-bottomsheet.component.ts");
/* harmony import */ var _components_layers_filter_bottomsheet_filter_bottomsheet_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./src/app/shared/components/layers/filter-bottomsheet/filter-bottomsheet.component.ts");
/* harmony import */ var _components_layers_alert_popup_alert_popup_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./src/app/shared/components/layers/alert-popup/alert-popup.component.ts");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./src/app/shared/components/header/header.component.ts");
/* harmony import */ var _components_menu_menu_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./src/app/shared/components/menu/menu.component.ts");
/* harmony import */ var _components_tag_tag_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./src/app/shared/components/tag/tag.component.ts");












class SharedModule {
}
SharedModule.ɵfac = function SharedModule_Factory(t) { return new (t || SharedModule)(); };
SharedModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineNgModule"]({ type: SharedModule });
SharedModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵdefineInjector"]({ imports: [_angular_common__WEBPACK_IMPORTED_MODULE_10__.CommonModule, _nativescript_angular__WEBPACK_IMPORTED_MODULE_11__.NativeScriptCommonModule] });


/***/ }),

/***/ "./src/polyfills.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _nativescript_core_globals__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@nativescript/core/globals/index.js");
/* harmony import */ var _nativescript_zone_js_dist_pre_zone_polyfills__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@nativescript/zone-js/dist/pre-zone-polyfills.js");
/* harmony import */ var zone_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/zone.js/fesm2015/zone.js");
/* harmony import */ var zone_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(zone_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _nativescript_zone_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@nativescript/zone-js/dist/index.js");
/**
 * NativeScript Polyfills
 */
// Install @nativescript/core polyfills (XHR, setTimeout, requestAnimationFrame)

// Install @nativescript/angular specific polyfills

/**
 * Zone.js and patches
 */
// Add pre-zone.js patches needed for the NativeScript platform

// Zone JS is required by default for Angular itself

// Add NativeScript specific Zone JS patches



/***/ }),

/***/ "~/package.json":
/***/ ((module) => {

module.exports = require("~/package.json");

/***/ }),

/***/ "./src/assets/local-data/categories.json":
/***/ ((module) => {

module.exports = JSON.parse('{"categories":[{"displayName":"Action","categoryKey":"action","image":"~/assets/images/categories/action.png","tinted":true},{"displayName":"Adventure","categoryKey":"adventure","image":"~/assets/images/categories/adventure.png","tinted":true},{"displayName":"Drama","categoryKey":"drama","image":"~/assets/images/categories/drama.png","tinted":true},{"displayName":"Family","categoryKey":"family","image":"~/assets/images/categories/family.png","tinted":true},{"displayName":"Romance","categoryKey":"romance","image":"~/assets/images/categories/romance.png","tinted":true}]}');

/***/ }),

/***/ "./src/assets/local-data/productGroups.json":
/***/ ((module) => {

module.exports = JSON.parse('{"productGroups":[{"displayName":"Featured","groupKey":"featured","products":[{"id":1,"title":"Avengers: Endgame","description":"With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos\' actions and restore balance to the universe.","keyInformation":[{"year":"2019"},{"country":"USA"},{"duration":181}],"rating":4,"categories":["action","adventure","drama"],"groups":["featured"],"tinted":true,"related":[],"image":{"thumbnail":"","cover":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/avengers-endgame-cover.png"}}]},{"displayName":"My List","groupKey":"favorite","products":[{"id":2,"title":"Frozen","description":"When the newly crowned Queen Elsa accidentally uses her power to turn things into ice to curse her home in infinite winter, her sister Anna teams up with a mountain man, his playful reindeer, and a snowman to change the weather condition.","keyInformation":[{"year":"2013"},{"country":"USA"},{"duration":102}],"rating":4,"categories":["animation","adventure","comedy"],"groups":["recommended"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/frozen.png","cover":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/frozen-cover.png"}},{"id":4,"title":"Home Alone","description":"An eight-year-old troublemaker must protect his house from a pair of burglars when he is accidentally left home alone by his family during Christmas vacation.","keyInformation":[{"year":"1990"},{"country":"USA"},{"duration":103}],"rating":4,"categories":["comedy","family"],"groups":["recommended"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/home-alone.png"}},{"id":5,"title":"Jurassic Park","description":"A pragmatic paleontologist visiting an almost complete theme park is tasked with protecting a couple of kids after a power failure causes the park\'s cloned dinosaurs to run loose.","keyInformation":[{"year":"1993"},{"country":"USA"},{"duration":127}],"rating":4,"categories":["action","adventure","sci-fi"],"groups":["recommended"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/jurassic-park.png"}},{"id":6,"title":"Kung Fu Panda","description":"The Dragon Warrior has to clash against the savage Tai Lung as China\'s fate hangs in the balance. However, the Dragon Warrior mantle is supposedly mistaken to be bestowed upon an obese panda who is a novice in martial arts.","keyInformation":[{"year":"2008"},{"country":"USA"},{"duration":92}],"rating":4,"categories":["animation","action","adventure"],"groups":["favorite"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/kungfu-panda.png"}}]},{"displayName":"Recommendations","groupKey":"recommendations","products":[{"id":7,"title":"Lady and the Tramp","description":"The romantic tale of a sheltered uptown Cocker Spaniel dog and a streetwise downtown Mutt.","keyInformation":[{"year":"2019"},{"country":"USA"},{"duration":121}],"rating":3,"categories":["adventure","comedy","drama"],"groups":["favorite"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/lady-and-the-tramp.png"}},{"id":8,"title":"Ratatouille","description":"A rat who can cook makes an unusual alliance with a young kitchen worker at a famous restaurant.","keyInformation":[{"year":"2007"},{"country":"USA"},{"duration":120}],"rating":4,"categories":["action","adventure","comedy"],"groups":["favorite"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products/ratatouille.png"}},{"id":9,"title":"Twilight","description":"When Bella Swan moves to a small town in the Pacific Northwest, she falls in love with Edward Cullen, a mysterious classmate who reveals himself to be a 108-year-old vampire.","keyInformation":[{"year":"2008"},{"country":"USA"},{"duration":122}],"rating":4,"categories":["drama","fantasy","romance"],"groups":["recommended","favorite"],"related":[],"image":{"thumbnail":"https://raw.githubusercontent.com/williamjuan027/movies-app-api/main/data/default/images/products//twilight.png"}}]}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("./runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor"], () => (__webpack_exec__("./src/polyfills.ts"), __webpack_exec__("./node_modules/@nativescript/core/bundle-entry-points.js"), __webpack_exec__("./src/main.ts")));
var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnVuZGxlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ21CO0FBQ3FFO0FBQzNDO0FBQ3lCO0FBQ3RFLGdGQUF5QjtBQUN6QixvQ0FBb0MsMkVBQW9CLG1CQUFtQixzREFBUztBQUNwRiwrQkFBK0IsMkVBQW9CLG1CQUFtQiwrRUFBYTtBQUNuRixDQUFDOzs7Ozs7Ozs7Ozs7QUNSRDs7QUFFQSxzQ0FBc0Msa0NBQWtDLFVBQVUscUNBQXFDLEVBQUUsbURBQW1ELHlGQUF5RixFQUFFLEVBQUUseURBQXlELDJFQUEyRSxFQUFFLEVBQUUscURBQXFELDJGQUEyRixFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELCtGQUErRixFQUFFLDREQUE0RCxFQUFFLEVBQUUsd0RBQXdELGlHQUFpRyxFQUFFLDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDZGQUE2RixFQUFFLDREQUE0RCxFQUFFLEVBQUUsaUVBQWlFLCtEQUErRCxFQUFFLEVBQUUsd0RBQXdELHNDQUFzQyxFQUFFLG9FQUFvRSxFQUFFLHVFQUF1RSxFQUFFLGlFQUFpRSxFQUFFLDRFQUE0RSxFQUFFLHlFQUF5RSxFQUFFLG1FQUFtRSxFQUFFLHVDQUF1QyxFQUFFLDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLDJEQUEyRCxFQUFFLDBEQUEwRCxFQUFFLDZDQUE2QyxFQUFFLGlFQUFpRSxFQUFFLGlFQUFpRSxFQUFFLGdFQUFnRSxFQUFFLG9DQUFvQyxFQUFFLDhEQUE4RCxFQUFFLDhEQUE4RCxFQUFFLDhEQUE4RCxFQUFFLHVDQUF1QyxFQUFFLDRGQUE0RixFQUFFLHVHQUF1RyxFQUFFLEVBQUUsdUNBQXVDLEVBQUUscURBQXFELHNFQUFzRSxFQUFFLEVBQUUsb0RBQW9ELHFFQUFxRSxFQUFFLEVBQUUsb0RBQW9ELHFFQUFxRSxFQUFFLEVBQUUsb0RBQW9ELHFFQUFxRSxFQUFFLEVBQUUscURBQXFELHFFQUFxRSxFQUFFLEVBQUUsb0RBQW9ELG9FQUFvRSxFQUFFLEVBQUUsb0RBQW9ELG9FQUFvRSxFQUFFLEVBQUUsb0RBQW9ELG9FQUFvRSxFQUFFLEVBQUUsc0RBQXNELHlFQUF5RSxFQUFFLDBFQUEwRSxFQUFFLEVBQUUsc0RBQXNELHlFQUF5RSxFQUFFLDBFQUEwRSxFQUFFLEVBQUUsc0RBQXNELHlFQUF5RSxFQUFFLDBFQUEwRSxFQUFFLEVBQUUsdURBQXVELHlFQUF5RSxFQUFFLEVBQUUsc0RBQXNELHdFQUF3RSxFQUFFLEVBQUUsc0RBQXNELHdFQUF3RSxFQUFFLEVBQUUsc0RBQXNELHdFQUF3RSxFQUFFLEVBQUUsdURBQXVELDRFQUE0RSxFQUFFLEVBQUUsc0RBQXNELDJFQUEyRSxFQUFFLEVBQUUsc0RBQXNELDJFQUEyRSxFQUFFLEVBQUUsc0RBQXNELDJFQUEyRSxFQUFFLEVBQUUsb0NBQW9DLEVBQUUsNkRBQTZELDBFQUEwRSxFQUFFLEVBQUUsNkRBQTZELDBFQUEwRSxFQUFFLEVBQUUsNkRBQTZELDBFQUEwRSxFQUFFLEVBQUUsc0NBQXNDLEVBQUUsK0RBQStELDBFQUEwRSxFQUFFLGtGQUFrRixFQUFFLCtFQUErRSxFQUFFLHFFQUFxRSxFQUFFLGlGQUFpRixFQUFFLGdFQUFnRSxFQUFFLEVBQUUsNERBQTRELDBFQUEwRSxFQUFFLHlFQUF5RSxFQUFFLHFFQUFxRSxFQUFFLGdFQUFnRSxFQUFFLHlFQUF5RSxFQUFFLDJEQUEyRCxFQUFFLHlFQUF5RSxFQUFFLHNEQUFzRCxFQUFFLEVBQUUsb0RBQW9ELHFGQUFxRixFQUFFLEVBQUUsaUVBQWlFLDRFQUE0RSxFQUFFLDZGQUE2RixFQUFFLDREQUE0RCxFQUFFLEVBQUUsbUVBQW1FLHVFQUF1RSxFQUFFLEVBQUUsaUVBQWlFLDBFQUEwRSxFQUFFLEVBQUUsZ0VBQWdFLHlFQUF5RSxFQUFFLEVBQUUsaUVBQWlFLGtGQUFrRixFQUFFLEVBQUUsaUVBQWlFLHFGQUFxRixFQUFFLEVBQUUsK0RBQStELDhFQUE4RSxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsNkRBQTZELGlGQUFpRixFQUFFLDJEQUEyRCxFQUFFLEVBQUUsaUVBQWlFLHFGQUFxRixFQUFFLGtFQUFrRSxFQUFFLEVBQUUsOERBQThELHlHQUF5RyxFQUFFLCtEQUErRCxFQUFFLEVBQUUsZ0VBQWdFLGlGQUFpRixFQUFFLEVBQUUsZ0VBQWdFLGlGQUFpRixFQUFFLEVBQUUsZ0VBQWdFLGlGQUFpRixFQUFFLEVBQUUsNERBQTRELGlGQUFpRixFQUFFLEVBQUUsc0RBQXNELG1GQUFtRixFQUFFLEVBQUUsMENBQTBDLEVBQUUsNERBQTRELDhEQUE4RCxFQUFFLEVBQUUseURBQXlELGtFQUFrRSxFQUFFLEVBQUUsc0RBQXNELCtEQUErRCxFQUFFLEVBQUUseURBQXlELGtFQUFrRSxFQUFFLEVBQUUseURBQXlELG9FQUFvRSxFQUFFO0FBQ3orVSxpRUFBZSw0QkFBNEI7QUFDM0MsUUFBUSx5QkFBeUIsRUFBRSxtQkFBTyxDQUFDLDZEQUEyQztBQUN0Rjs7Ozs7Ozs7Ozs7Ozs7QUNMaUU7QUFDN0I7QUFDUTtBQUM1QztBQUNBLE1BQU0sa0RBQWtEO0FBQ3hEO0FBQ0E7QUFDQSw0QkFBNEIsMEtBQXFDO0FBQ2pFLEtBQUs7QUFDTDtBQUNBO0FBQ0EsNEJBQTRCLHNMQUEyQztBQUN2RSxLQUFLO0FBQ0w7QUFDQTtBQUNBLDRCQUE0QixzTEFBMkM7QUFDdkUsS0FBSztBQUNMO0FBQ0E7QUFDQSw0QkFBNEIsa0xBQXlDO0FBQ3JFLEtBQUs7QUFDTDtBQUNBO0FBQ0EsNEJBQTRCLGtNQUFpRDtBQUM3RSxLQUFLO0FBQ0w7QUFDTztBQUNQO0FBQ0EsK0RBQStEO0FBQy9ELHNDQUFzQyw4REFBbUIsR0FBRyx3QkFBd0I7QUFDcEYsc0NBQXNDLDhEQUFtQixHQUFHLFVBQVUsbUZBQWdDLFVBQVUsMkVBQXdCLEdBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUIzSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNYSxZQUFOLENBQW1CO0VBQ3RCQyxXQUFXLENBQUNDLGFBQUQsRUFBZ0I7SUFDdkIsS0FBS0EsYUFBTCxHQUFxQkEsYUFBckI7SUFDQSxLQUFLQyxXQUFMLEdBQW1CLEtBQUtELGFBQUwsQ0FDZEUsVUFEYyxHQUVkQyxJQUZjLENBRVRiLG1EQUFHLENBQUVILEtBQUQsSUFBV0EsS0FBSyxDQUFDaUIsSUFBTixDQUFXQyxNQUF2QixDQUZNLENBQW5CO0VBR0g7O0VBQ0RDLFNBQVMsR0FBRztJQUNSLEtBQUtOLGFBQUwsQ0FBbUJNLFNBQW5CO0VBQ0g7O0FBVHFCOztBQVcxQlIsWUFBWSxDQUFDUyxJQUFiLEdBQW9CLFNBQVNDLG9CQUFULENBQThCQyxDQUE5QixFQUFpQztFQUFFLE9BQU8sS0FBS0EsQ0FBQyxJQUFJWCxZQUFWLEVBQXdCTiwrREFBQSxDQUFxQkMsZ0RBQXJCLENBQXhCLENBQVA7QUFBeUUsQ0FBaEk7O0FBQ0FLLFlBQVksQ0FBQ2EsSUFBYixHQUFvQixhQUFjbkIsK0RBQUEsQ0FBcUI7RUFBRXFCLElBQUksRUFBRWYsWUFBUjtFQUFzQmdCLFNBQVMsRUFBRSxDQUFDLENBQUMsUUFBRCxDQUFELENBQWpDO0VBQStDQyxLQUFLLEVBQUUsRUFBdEQ7RUFBMERDLElBQUksRUFBRSxFQUFoRTtFQUFvRUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFELEVBQUksa0JBQUosQ0FBRCxFQUEwQixDQUFDLFNBQUQsRUFBWSxLQUFaLEVBQW1CLHFCQUFuQixFQUEwQyxPQUExQyxDQUExQixFQUE4RSxDQUFDLEtBQUQsRUFBUSxHQUFSLENBQTlFLEVBQTRGLENBQUMsS0FBRCxFQUFRLEdBQVIsRUFBYSxTQUFiLEVBQXdCLEdBQXhCLENBQTVGLEVBQTBILENBQUMsQ0FBRCxFQUFJLGtCQUFKLENBQTFILENBQTVFO0VBQWdPQyxRQUFRLEVBQUUsU0FBU0MscUJBQVQsQ0FBK0JDLEVBQS9CLEVBQW1DQyxHQUFuQyxFQUF3QztJQUFFLElBQUlELEVBQUUsR0FBRyxDQUFULEVBQVk7TUFDL1U1Qiw0REFBQSxDQUFrQixDQUFsQixFQUFxQixZQUFyQixFQUFtQyxDQUFuQyxFQUFzQyxDQUF0QyxFQUF5QyxZQUF6QyxFQUF1RCxDQUF2RCxFQUEwRCxDQUExRCxFQUE2RCxhQUE3RCxFQUE0RSxDQUE1RTtNQUNBQSx1REFBQSxDQUFhLENBQWIsRUFBZ0IsU0FBaEI7TUFDQUEsMERBQUE7TUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsWUFBckIsRUFBbUMsQ0FBbkM7TUFDQUEsb0RBQUEsQ0FBVSxDQUFWLEVBQWEsT0FBYjtNQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO01BQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixhQUFoQixFQUErQixDQUEvQjtNQUNBQSwwREFBQTtNQUNBQSw0REFBQSxDQUFrQixDQUFsQixFQUFxQixZQUFyQixFQUFtQyxDQUFuQztNQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO01BQ0FBLG9EQUFBLENBQVUsRUFBVixFQUFjLE9BQWQ7TUFDQUEsdURBQUEsQ0FBYSxFQUFiLEVBQWlCLG9CQUFqQjtNQUNBQSwwREFBQTtNQUNBQSx1REFBQSxDQUFhLEVBQWIsRUFBaUIsZ0JBQWpCLEVBQW1DLENBQW5DO01BQ0FBLDBEQUFBO0lBQ0g7O0lBQUMsSUFBSTRCLEVBQUUsR0FBRyxDQUFULEVBQVk7TUFDVjVCLHVEQUFBLENBQWEsQ0FBYjtNQUNBQSx5REFBQSxDQUFlLGFBQWYsRUFBOEJBLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQjZCLEdBQUcsQ0FBQ3BCLFdBQXpCLENBQTlCO01BQ0FULHdEQUFBLENBQWMsbUJBQWQsRUFBbUNBLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQjZCLEdBQUcsQ0FBQ3BCLFdBQXpCLElBQXdDLFlBQXhDLEdBQXVELGNBQTFGO01BQ0FULHVEQUFBLENBQWEsQ0FBYjtNQUNBQSx5REFBQSxDQUFlLGFBQWYsRUFBOEJBLHlEQUFBLENBQWUsQ0FBZixFQUFrQixFQUFsQixFQUFzQjZCLEdBQUcsQ0FBQ3BCLFdBQTFCLENBQTlCO01BQ0FULHdEQUFBLENBQWMsY0FBZCxFQUE4QkEseURBQUEsQ0FBZSxFQUFmLEVBQW1CLEVBQW5CLEVBQXVCNkIsR0FBRyxDQUFDcEIsV0FBM0IsSUFBMEMsWUFBMUMsR0FBeUQsY0FBdkY7SUFDSDtFQUFFLENBdkJnRDtFQXVCOUM2QixZQUFZLEVBQUUsQ0FBQ3BDLG1FQUFELEVBQXNCQyw0R0FBdEIsRUFBOENDLGlGQUE5QyxFQUFnRUMsc0RBQWhFLENBdkJnQztFQXVCK0NzQyxhQUFhLEVBQUUsQ0F2QjlEO0VBdUJpRUMsSUFBSSxFQUFFO0lBQUVDLFNBQVMsRUFBRSxDQUMvSGhELDREQUFPLENBQUMsYUFBRCxFQUFnQixDQUNuQkYsMERBQUssQ0FBQyxZQUFELEVBQWVELDBEQUFLLENBQUM7TUFBRW9ELFNBQVMsRUFBRTtJQUFiLENBQUQsQ0FBcEIsQ0FEYyxFQUVuQm5ELDBEQUFLLENBQUMsY0FBRCxFQUFpQkQsMERBQUssQ0FBQztNQUFFb0QsU0FBUyxFQUFFO0lBQWIsQ0FBRCxDQUF0QixDQUZjLEVBR25CckQsK0RBQVUsQ0FBQyw0QkFBRCxFQUErQkcsNERBQU8sQ0FBQyxtQkFBRCxFQUFzQkYsMERBQUssQ0FBQztNQUFFb0QsU0FBUyxFQUFFO0lBQWIsQ0FBRCxDQUEzQixDQUF0QyxDQUhTLEVBSW5CckQsK0RBQVUsQ0FBQyw0QkFBRCxFQUErQkcsNERBQU8sQ0FBQyxtQkFBRCxFQUFzQkYsMERBQUssQ0FBQztNQUFFb0QsU0FBUyxFQUFFO0lBQWIsQ0FBRCxDQUEzQixDQUF0QyxDQUpTLENBQWhCLENBRHdILEVBTy9IakQsNERBQU8sQ0FBQyxrQkFBRCxFQUFxQixDQUN4QkYsMERBQUssQ0FBQyxZQUFELEVBQWVELDBEQUFLLENBQUM7TUFBRW9ELFNBQVMsRUFBRTtJQUFiLENBQUQsQ0FBcEIsQ0FEbUIsRUFFeEJuRCwwREFBSyxDQUFDLGNBQUQsRUFBaUJELDBEQUFLLENBQUM7TUFBRW9ELFNBQVMsRUFBRTtJQUFiLENBQUQsQ0FBdEIsQ0FGbUIsRUFHeEJyRCwrREFBVSxDQUFDLDRCQUFELEVBQStCRyw0REFBTyxDQUFDLHlCQUFELEVBQTRCRiwwREFBSyxDQUFDO01BQUVvRCxTQUFTLEVBQUU7SUFBYixDQUFELENBQWpDLENBQXRDLENBSGMsRUFJeEJyRCwrREFBVSxDQUFDLDRCQUFELEVBQStCRyw0REFBTyxDQUFDLG1CQUFELEVBQXNCRiwwREFBSyxDQUFDO01BQUVvRCxTQUFTLEVBQUU7SUFBYixDQUFELENBQTNCLENBQXRDLENBSmMsQ0FBckIsQ0FQd0g7RUFBYjtBQXZCdkUsQ0FBckIsQ0FBbEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2EsU0FBVCxHQUFxQjtFQUN4QixPQUFPLE1BQU0sSUFBSUMsT0FBSixDQUFhQyxPQUFELElBQWE7SUFDbENDLFVBQVUsQ0FBQyxNQUFNO01BQ2JELE9BQU87SUFDVixDQUZTLENBQVYsQ0FEa0MsQ0FJbEM7RUFDSCxDQUxZLENBQWI7QUFNSDtBQUNNLE1BQU1FLFNBQU4sQ0FBZ0I7O0FBRXZCQSxTQUFTLENBQUNoRCxJQUFWLEdBQWlCLFNBQVNpRCxpQkFBVCxDQUEyQi9DLENBQTNCLEVBQThCO0VBQUUsT0FBTyxLQUFLQSxDQUFDLElBQUk4QyxTQUFWLEdBQVA7QUFBZ0MsQ0FBakY7O0FBQ0FBLFNBQVMsQ0FBQ0UsSUFBVixHQUFpQixhQUFjakUsOERBQUEsQ0FBb0I7RUFBRXFCLElBQUksRUFBRTBDLFNBQVI7RUFBbUJJLFNBQVMsRUFBRSxDQUFDN0Qsd0RBQUQ7QUFBOUIsQ0FBcEIsQ0FBL0I7QUFDQXlELFNBQVMsQ0FBQ0ssSUFBVixHQUFpQixhQUFjcEUsOERBQUEsQ0FBb0I7RUFBRXNFLFNBQVMsRUFBRSxDQUN4RDtJQUNJQyxPQUFPLEVBQUV0QiwwREFEYjtJQUVJdUIsVUFBVSxFQUFFYixTQUZoQjtJQUdJYyxLQUFLLEVBQUU7RUFIWCxDQUR3RCxDQUFiO0VBTTVDQyxPQUFPLEVBQUUsQ0FBQ3hCLHFFQUFELEVBQ1JFLDJFQURRLEVBRVJDLCtFQUZRLEVBR1JOLHlEQUhRLEVBSVJDLGtFQUpRLEVBS1JHLCtFQUxRLEVBTVJHLDJEQUFBLENBQW1CLENBQUNFLDhDQUFELEVBQWNDLCtDQUFkLENBQW5CLEVBQWdEO0lBQUVtQixlQUFlLEVBQUU7RUFBbkIsQ0FBaEQsQ0FOUSxFQU9SckIsaUVBUFEsRUFRUkcsaURBUlE7QUFObUMsQ0FBcEIsQ0FBL0I7Ozs7Ozs7Ozs7OztBQ3ZCMEU7QUFDbkUsYUFBYSw0REFBTztBQUMzQixJQUFJLCtEQUFVO0FBQ2QsUUFBUSwwREFBSyxHQUFHLFlBQVk7QUFDNUIsUUFBUSw0REFBTyx3QkFBd0IsMERBQUssR0FBRyxZQUFZO0FBQzNEO0FBQ0EsSUFBSSwrREFBVTtBQUNkLFFBQVEsMERBQUssR0FBRyxZQUFZO0FBQzVCLFFBQVEsNERBQU8sd0JBQXdCLDBEQUFLLEdBQUcsWUFBWTtBQUMzRDtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQ1ZvQztBQUNIO0FBQ0M7Ozs7Ozs7Ozs7Ozs7QUNGd0M7QUFDbkUsZ0JBQWdCLDREQUFPO0FBQzlCLElBQUksK0RBQVU7QUFDZCxRQUFRLDBEQUFLLEdBQUcsZ0NBQWdDO0FBQ2hELFFBQVEsNERBQU8sc0JBQXNCLDBEQUFLLEdBQUcsNkJBQTZCO0FBQzFFO0FBQ0EsSUFBSSwrREFBVTtBQUNkLFFBQVEsMERBQUssR0FBRyw2QkFBNkI7QUFDN0MsUUFBUSw0REFBTywrQ0FBK0MsMERBQUssR0FBRyxnQ0FBZ0M7QUFDdEc7QUFDQTs7Ozs7Ozs7Ozs7OztBQ1YyRjtBQUNwRiwyQkFBMkIsNERBQU87QUFDekMsSUFBSSwrREFBVTtBQUNkLFFBQVEsMERBQUs7QUFDYixZQUFZLDBEQUFLLEdBQUcsMkNBQTJDO0FBQy9ELFlBQVksNERBQU87QUFDbkIsZ0JBQWdCLDREQUFPLGdCQUFnQiwwREFBSyxHQUFHLDBDQUEwQztBQUN6RjtBQUNBLGFBQWEsZ0JBQWdCO0FBQzdCO0FBQ0EsSUFBSSwrREFBVTtBQUNkLFFBQVEsMERBQUs7QUFDYixZQUFZLDREQUFPO0FBQ25CLGdCQUFnQiw0REFBTyxVQUFVLDBEQUFLLEdBQUcsMkNBQTJDO0FBQ3BGO0FBQ0EsYUFBYSxnQkFBZ0I7QUFDN0I7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqQjZCO0FBQ0o7QUFDRTtBQUNIOzs7Ozs7Ozs7Ozs7QUNIakI7QUFDUDtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDSk87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEI2QjtBQUNMO0FBQ0M7Ozs7Ozs7Ozs7OztBQ0ZsQjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMNEI7QUFDQzs7Ozs7Ozs7O0FDRG5COzs7Ozs7Ozs7Ozs7OztBQ0EyQjtBQUNEO0FBQ007QUFDQTtBQUNOOzs7Ozs7Ozs7QUNKMUI7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBd0M7QUFDYjtBQUNzQjtBQUN2QjtBQUNPO0FBQ3BDO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyxpRkFBdUI7QUFDakUsa0JBQWtCLG1EQUFHO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyw4RUFBb0I7QUFDOUQsa0JBQWtCLG1EQUFHO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyw4RUFBb0I7QUFDOUQsa0JBQWtCLG1EQUFHO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Qsa0JBQWtCLG1EQUFHO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixRQUFRLEVBQUUsVUFBVTtBQUMxQztBQUNBLGtCQUFrQixRQUFRLEdBQUcsVUFBVTtBQUN2QztBQUNBO0FBQ0EsbURBQW1ELDZCQUE2QixzREFBVyxDQUFDLDREQUFhO0FBQ3pHLGlDQUFpQyxnRUFBcUIsR0FBRyxpRUFBaUU7Ozs7Ozs7Ozs7Ozs7QUM1Q3RGO0FBQzdCO0FBQ1A7QUFDQSxxREFBcUQ7QUFDckQsa0NBQWtDLGdFQUFxQixHQUFHLG1FQUFtRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ovRjtBQUNDO0FBQ007QUFDaEI7Ozs7Ozs7Ozs7Ozs7O0FDSG9DO0FBQ3JCO0FBQ1E7QUFDckM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFEQUFxRCw0QkFBNEI7QUFDakY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxvQ0FBb0Msc0RBQVcsQ0FBQyxtRUFBbUI7QUFDcEksd0NBQXdDLGdFQUFxQixHQUFHLCtFQUErRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEI5RztBQUNDO0FBQ0s7Ozs7Ozs7Ozs7Ozs7O0FDRkE7QUFDaUI7QUFDcEI7QUFDN0I7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0Isa0RBQWdCO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixrREFBZ0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBLG1FQUFtRSxxQ0FBcUMsc0RBQVcsQ0FBQyxpREFBUztBQUM3SCx5Q0FBeUMsZ0VBQXFCLEdBQUcsaUZBQWlGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuRHREO0FBQ0E7QUFDckQ7QUFDMkU7QUFDOUU7QUFDN0IsZ0NBQWdDLG9GQUFvQztBQUNwRTtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsaURBQWU7QUFDM0M7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLCtEQUFlO0FBQ3ZCO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQsbUNBQW1DO0FBQzVGO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQSx5REFBeUQsbUNBQW1DO0FBQzVGO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixrRUFBNkI7QUFDbkQsNkRBQTZELG1DQUFtQztBQUNoRztBQUNBO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkIsWUFBWSxpRUFBYTtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckIsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBLGlFQUFpRSxtQ0FBbUMsb0RBQW9ELHdEQUF3RCxvQkFBb0IsR0FBRztBQUN2TyxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQsbUNBQW1DLG9EQUFvRCx3REFBd0QsbUJBQW1CLEdBQUc7QUFDbE8sWUFBWSxpRUFBYTtBQUN6QjtBQUNBO0FBQ0EsaUVBQWlFLG1DQUFtQztBQUNwRztBQUNBO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLCtEQUEwQjtBQUNoRCw2REFBNkQsbUNBQW1DO0FBQ2hHO0FBQ0E7QUFDQSxtQkFBbUI7QUFDbkIsWUFBWSxpRUFBYTtBQUN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckIsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBLGlFQUFpRSxtQ0FBbUMsaURBQWlELHFEQUFxRCxvQkFBb0IsR0FBRztBQUNqTyxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2REFBNkQsbUNBQW1DLGlEQUFpRCxxREFBcUQsbUJBQW1CLEdBQUc7QUFDNU4sWUFBWSxpRUFBYTtBQUN6QjtBQUNBO0FBQ0EsaUVBQWlFLG1DQUFtQztBQUNwRztBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQiwrREFBMEI7QUFDaEQsNkRBQTZELG1DQUFtQztBQUNoRztBQUNBO0FBQ0EsbUJBQW1CO0FBQ25CLFlBQVksaUVBQWE7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2I7QUFDQSxpRUFBaUUsbUNBQW1DLGlEQUFpRCxxREFBcUQsb0JBQW9CLEdBQUc7QUFDak8sYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkRBQTZELG1DQUFtQyxpREFBaUQscURBQXFELG1CQUFtQixHQUFHO0FBQzVOLFlBQVksaUVBQWE7QUFDekI7QUFDQTtBQUNBLGlFQUFpRSxtQ0FBbUM7QUFDcEc7QUFDQTtBQUNBLHVCQUF1QjtBQUN2QixhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZDQUE2QyxrRUFBa0I7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0EseURBQXlELGdDQUFnQyxzREFBVyxDQUFDLGlEQUFTLEdBQUcsc0RBQVcsQ0FBQyxtREFBVyxHQUFHLHNEQUFXLENBQUMsbUVBQTJCLEdBQUcsc0RBQVcsQ0FBQyx5REFBaUI7QUFDbE4sb0NBQW9DLGdFQUFxQixHQUFHLHVFQUF1RTs7Ozs7Ozs7Ozs7Ozs7QUM5TmxGO0FBQ2I7QUFDN0I7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksa0VBQWtCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJEQUEyRDtBQUMzRCxxQ0FBcUMsZ0VBQXFCLEdBQUcseUVBQXlFOzs7Ozs7Ozs7Ozs7QUNmL0g7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyx3QkFBd0I7Ozs7Ozs7OztBQ3hCZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBbUQ7QUFDWjtBQUNNO0FBQ2I7QUFDaEI7QUFDVztBQUNEO0FBQ0o7QUFDRTtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQsWUFBWSxxQkFBcUI7QUFDeEY7QUFDQTtBQUNBLDhCQUE4Qiw0REFBc0I7QUFDcEQ7QUFDQSxvREFBb0QsK0RBQXlCO0FBQzdFLHFDQUFxQyxvRUFBdUI7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUF1RCxZQUFZLHdCQUF3QjtBQUMzRixxRUFBcUUsbURBQUc7QUFDeEU7QUFDQSxhQUFhLEdBQUcsMERBQVU7QUFDMUI7QUFDQSx1QkFBdUIsd0NBQUU7QUFDekIsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOERBQThELG1EQUFHO0FBQ2pFLHVEQUF1RCxZQUFZLDRCQUE0QjtBQUMvRixTQUFTLEdBQUcsMERBQVU7QUFDdEI7QUFDQSxtQkFBbUIsd0NBQUU7QUFDckIsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLGtFQUFrRSxtREFBRztBQUNyRTtBQUNBLHVEQUF1RCxZQUFZLHdCQUF3QjtBQUMzRixTQUFTLEdBQUcsMERBQVU7QUFDdEI7QUFDQSxtQkFBbUIsd0NBQUU7QUFDckIsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxREFBcUQsOEJBQThCLHNEQUFXLENBQUMsaURBQWEsR0FBRyxzREFBVyxDQUFDLHFEQUFpQixHQUFHLHNEQUFXLENBQUMsOENBQVE7QUFDbkssa0NBQWtDLGdFQUFxQixHQUFHLCtDQUErQztBQUN6RztBQUNBLElBQUksbURBQU0sQ0FBQyxpRUFBb0I7QUFDL0I7QUFDQSw2Q0FBNkMsaUVBQW9CO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBLElBQUksbURBQU0sQ0FBQyxvRUFBdUI7QUFDbEM7QUFDQSw2Q0FBNkMsb0VBQXVCO0FBQ3BFO0FBQ0E7QUFDQTtBQUNBLElBQUksbURBQU0sQ0FBQyxzRUFBeUI7QUFDcEM7QUFDQSw2Q0FBNkMsc0VBQXlCO0FBQ3RFO0FBQ0E7QUFDQTtBQUNBLElBQUksbURBQU0sQ0FBQyxvRUFBdUI7QUFDbEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUkscURBQVE7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxxREFBUTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHFEQUFRO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUkscURBQVE7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxrREFBSztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULEtBQUs7QUFDTCxxQ0FBcUMsaURBQVU7QUFDL0MsUUFBUSxxREFBYztBQUN0QixRQUFRLDhDQUFLO0FBQ2I7QUFDdUI7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqSlU7QUFDRjtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZOO0FBQ0M7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEUTtBQUNGO0FBQ0E7Ozs7Ozs7Ozs7OztBQ0Z6QjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUMsMEJBQTBCOzs7Ozs7Ozs7QUNoQmpCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBVjtBQUMwQjtBQUN1QjtBQUNzQjtBQUNoQztBQUNLO0FBQzJCO0FBQ007QUFDekM7QUFDSjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrREFBK0QsbURBQUc7QUFDbEUsdURBQXVELFlBQVksd0JBQXdCO0FBQzNGLFNBQVMsR0FBRywwREFBVTtBQUN0QjtBQUNBLG1CQUFtQix3Q0FBRTtBQUNyQixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0Esa0VBQWtFLG1EQUFHO0FBQ3JFLHVEQUF1RCxZQUFZLDhCQUE4QjtBQUNqRyxTQUFTLEdBQUcsMERBQVU7QUFDdEI7QUFDQSxtQkFBbUIsd0NBQUU7QUFDckIsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsMkRBQWM7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLHVEQUF1RCwrQkFBK0Isc0RBQVcsQ0FBQyxpREFBYTtBQUMvRyxtQ0FBbUMsZ0VBQXFCLEdBQUcsaURBQWlEO0FBQzVHO0FBQ0EsSUFBSSxtREFBTSxDQUFDLG9FQUFzQjtBQUNqQztBQUNBLDZDQUE2QyxvRUFBc0I7QUFDbkU7QUFDQTtBQUNBO0FBQ0EsSUFBSSxtREFBTSxDQUFDLHVFQUF5QjtBQUNwQztBQUNBLDZDQUE2Qyx1RUFBeUI7QUFDdEU7QUFDQTtBQUNBO0FBQ0EsSUFBSSxxREFBUTtBQUNaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLHFEQUFRO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUkscURBQVE7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSSxrREFBSztBQUNUO0FBQ0E7QUFDQSx3QkFBd0IsMEVBQXFCO0FBQzdDLDJCQUEyQixnRkFBMkI7QUFDdEQsU0FBUztBQUNULEtBQUs7QUFDTCxxQ0FBcUMsaURBQVU7QUFDL0M7QUFDd0I7Ozs7Ozs7Ozs7Ozs7QUNsR1k7QUFDN0I7QUFDUDtBQUNBLCtEQUErRDtBQUMvRCxzQ0FBc0MsK0RBQW9CLEdBQUcsNlVBQTZVO0FBQzFZLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSwwREFBZTtBQUN2QixNQUFNO0FBQ04sUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLE9BQU8sb0JBQW9COzs7Ozs7Ozs7Ozs7Ozs7OztBQ1hvQjtBQUNTO0FBQzZCO0FBQzlCO0FBQ1E7QUFDM0I7QUFDcEMsc0VBQWUscUJBQXFCLHlFQUFVO0FBQ3ZDO0FBQ1A7QUFDQSx5REFBeUQ7QUFDekQsbUNBQW1DLDhEQUFtQixHQUFHLGlDQUFpQyxnRUFBZ0IsR0FBRztBQUM3RyxtQ0FBbUMsOERBQW1CLEdBQUcsVUFBVSxxRUFBa0I7QUFDckYsUUFBUSwyRUFBd0I7QUFDaEMsUUFBUSx5REFBWSxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7O0FDYjREO0FBQ1Q7QUFDbkUsMEJBQTBCLDRGQUFzQixFQUFFLG1GQUFtQjtBQUNsQjtBQUNOOzs7Ozs7Ozs7Ozs7O0FDSmhCO0FBQzdCO0FBQ1A7QUFDQSxxRUFBcUU7QUFDckUseUNBQXlDLCtEQUFvQixHQUFHLHNFQUFzRSxrRUFBa0Usa1pBQWtaO0FBQzFsQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSwwREFBZTtBQUN2QixNQUFNO0FBQ04sUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsT0FBTyxvQkFBb0I7Ozs7Ozs7Ozs7Ozs7QUNqQlM7QUFDN0I7QUFDUDtBQUNBLDJFQUEyRTtBQUMzRSw0Q0FBNEMsK0RBQW9CLEdBQUcsNEVBQTRFLHNCQUFzQix3VEFBd1Q7QUFDN2QsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsMERBQWU7QUFDdkIsTUFBTTtBQUNOLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYTtBQUNyQixPQUFPLG9CQUFvQjs7Ozs7Ozs7Ozs7Ozs7OztBQ2J5QztBQUN6QjtBQUNQO0FBQ0o7QUFDTTtBQUN0Qyw0REFBNEQ7QUFDNUQsZ0JBQWdCLDhEQUFtQjtBQUNuQyxJQUFJLHFFQUEwQjtBQUM5QixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHdEQUFhLHVGQUF1RiwyREFBZ0IsT0FBTyxlQUFlLDJEQUFnQixJQUFJLE9BQU8seURBQWMsa0JBQWtCO0FBQ3pNLElBQUksdURBQVk7QUFDaEIsSUFBSSwwREFBZTtBQUNuQixJQUFJLG1FQUF3QjtBQUM1QixFQUFFO0FBQ0YsbUJBQW1CLDJEQUFnQjtBQUNuQyxJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDQSw0REFBNEQ7QUFDNUQsZ0JBQWdCLDhEQUFtQjtBQUNuQyxJQUFJLHFFQUEwQjtBQUM5QixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHdEQUFhLHVGQUF1RiwyREFBZ0IsT0FBTyxlQUFlLDJEQUFnQixJQUFJLE9BQU8seURBQWMsc0JBQXNCO0FBQzdNLElBQUksdURBQVk7QUFDaEIsSUFBSSwwREFBZTtBQUNuQixJQUFJLG1FQUF3QjtBQUM1QixFQUFFO0FBQ0YsbUJBQW1CLDJEQUFnQjtBQUNuQyxJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDQSw0REFBNEQ7QUFDNUQsZ0JBQWdCLDhEQUFtQjtBQUNuQyxJQUFJLHFFQUEwQjtBQUM5QixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHdEQUFhLHVGQUF1RiwyREFBZ0IsT0FBTyxlQUFlLDJEQUFnQixJQUFJLE9BQU8seURBQWMscUNBQXFDO0FBQzVOLElBQUksdURBQVk7QUFDaEIsSUFBSSwwREFBZTtBQUNuQixJQUFJLG1FQUF3QjtBQUM1QixFQUFFO0FBQ0YsbUJBQW1CLDJEQUFnQjtBQUNuQyxJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw0Q0FBSztBQUMxQixtQkFBbUIscURBQUs7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZEQUE2RCxrQ0FBa0MsK0RBQW9CLENBQUMsd0RBQW9CLEdBQUcsK0RBQW9CLENBQUMsb0RBQWdCO0FBQ2hMLHFDQUFxQywrREFBb0IsR0FBRyw2REFBNkQsb0lBQW9JLHMxQkFBczFCO0FBQ25sQyxRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsb0RBQVM7QUFDakIsUUFBUSwwREFBZTtBQUN2QixNQUFNO0FBQ04sUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWEsU0FBUyx5REFBYztBQUM1QyxPQUFPLGlCQUFpQixpREFBTyxFQUFFLDBEQUFnQixxQkFBcUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3RTNCO0FBQ1Q7QUFDMEI7QUFDTjtBQUNIO0FBQzVDO0FBQ1AsT0FBTyxvREFBZ0I7QUFDdkIsT0FBTywyQ0FBTTtBQUNiLElBQUkscUVBQWU7QUFDbkIsSUFBSSwrREFBYTtBQUNqQixJQUFJLDREQUFZO0FBQ2hCO0FBQ3dCO0FBQ0M7QUFDaUI7QUFDSjtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCMEI7QUFDL0I7QUFDbUQ7QUFDOUM7QUFDSjtBQUN6QjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2QkFBNkIseUNBQU87QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsbURBQUcsd0NBQXdDLHlEQUFTLDRDQUE0QyxvRUFBb0IsSUFBSSx5REFBUztBQUNuSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EscUVBQXFFLHNDQUFzQywrREFBb0IsQ0FBQyxvREFBZ0IsR0FBRywrREFBb0IsQ0FBQyx5REFBcUI7QUFDN0wseUNBQXlDLCtEQUFvQixHQUFHLGk4QkFBaThCO0FBQ2pnQyxRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhLHdGQUF3RiwwQ0FBMEM7QUFDdkosUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsMERBQWU7QUFDdkIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx3REFBYSx5RUFBeUUsOEJBQThCO0FBQzVILFFBQVEsMERBQWU7QUFDdkIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx3REFBYSx5RUFBeUUscUJBQXFCO0FBQ25ILFFBQVEsMERBQWU7QUFDdkIsT0FBTyxvQkFBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0SDRCO0FBQ25CO0FBQ0o7QUFDTTtBQUNRO0FBQzlDLHVFQUF1RTtBQUN2RSxJQUFJLHFFQUEwQjtBQUM5QixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksMERBQWU7QUFDbkIsSUFBSSxtRUFBd0I7QUFDNUIsRUFBRTtBQUNGO0FBQ0EsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCO0FBQ0Esd0VBQXdFO0FBQ3hFLElBQUkscUVBQTBCO0FBQzlCLElBQUksNERBQWlCO0FBQ3JCLElBQUksdURBQVk7QUFDaEIsSUFBSSwwREFBZTtBQUNuQixJQUFJLG1FQUF3QjtBQUM1QixFQUFFO0FBQ0Y7QUFDQSxJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDTztBQUNQO0FBQ0E7QUFDQSxxQkFBcUIsNENBQUs7QUFDMUI7QUFDQSxjQUFjLGlDQUFpQztBQUMvQyxjQUFjLGtDQUFrQztBQUNoRCxjQUFjLGlDQUFpQztBQUMvQztBQUNBO0FBQ0EsY0FBYywrQkFBK0I7QUFDN0MsY0FBYyxpQ0FBaUM7QUFDL0MsY0FBYywrQkFBK0I7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxtRkFBbUYsNkNBQTZDLCtEQUFvQixDQUFDLG9EQUFnQjtBQUNySyxnREFBZ0QsK0RBQW9CLEdBQUcsdWhDQUF1aEM7QUFDOWxDLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsd0RBQWEsZ0dBQWdHLGlDQUFpQyxxRkFBcUYscUJBQXFCO0FBQ2hRLFFBQVEsMERBQWU7QUFDdkIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSwwREFBZTtBQUN2QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSwwREFBZTtBQUN2QixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhLG9GQUFvRixxQkFBcUI7QUFDOUgsUUFBUSx1REFBWTtBQUNwQixRQUFRLDBEQUFlO0FBQ3ZCLE1BQU07QUFDTixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLE9BQU8saUJBQWlCLG9EQUFVLEVBQUUsNERBQWUsNkJBQTZCLFlBQVksMkNBQUksS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Rkc7QUFDVDtBQUNBO0FBQ3JCO0FBQ25FO0FBQ1AsSUFBSSxpSEFBNkI7QUFDakMsSUFBSSx3R0FBMEI7QUFDOUIsSUFBSSx3R0FBMEI7QUFDOUIsSUFBSSxtRkFBbUI7QUFDdkI7QUFDd0U7QUFDTjtBQUNBO0FBQ2Q7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2JwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFNBQVN5QixxREFBVCxDQUErRHZELEVBQS9ELEVBQW1FQyxHQUFuRSxFQUF3RTtFQUFFLElBQUlELEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDbEY1QixxRUFBQSxDQUEyQixDQUEzQjtJQUNBQSw0REFBQSxDQUFrQixDQUFsQixFQUFxQixhQUFyQixFQUFvQyxDQUFwQztJQUNBQSx1REFBQSxDQUFhLENBQWIsRUFBZ0IsbUJBQWhCLEVBQXFDLENBQXJDO0lBQ0FBLDBEQUFBO0lBQ0FBLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLGFBQXJCLEVBQW9DLENBQXBDO0lBQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixPQUFoQixFQUF5QixDQUF6QixFQUE0QixDQUE1QixFQUErQixPQUEvQixFQUF3QyxDQUF4QztJQUNBQSwwREFBQTtJQUNBQSxtRUFBQTtFQUNIOztFQUFDLElBQUk0QixFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ1YsTUFBTTBELGlCQUFpQixHQUFHekQsR0FBRyxDQUFDMEQsSUFBOUI7SUFDQXZGLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLFVBQWQsRUFBMEJzRixpQkFBaUIsQ0FBQ0UsS0FBbEIsQ0FBd0JDLFNBQWxEO0lBQ0F6Rix1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCc0YsaUJBQWlCLENBQUNJLEtBQXhDO0lBQ0ExRix1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCc0YsaUJBQWlCLENBQUNLLFdBQWxCLENBQThCQyxTQUE5QixDQUF3QyxDQUF4QyxFQUEyQyxFQUEzQyxJQUFpRCxLQUF2RTtFQUNIO0FBQUU7O0FBQ0ksTUFBTUMsNkJBQU4sQ0FBb0M7RUFDdkN0RixXQUFXLENBQUN1RixLQUFELEVBQVF0RixhQUFSLEVBQXVCdUYsaUJBQXZCLEVBQTBDO0lBQ2pELEtBQUtELEtBQUwsR0FBYUEsS0FBYjtJQUNBLEtBQUt0RixhQUFMLEdBQXFCQSxhQUFyQjtJQUNBLEtBQUt1RixpQkFBTCxHQUF5QkEsaUJBQXpCO0lBQ0EsS0FBS0MsTUFBTCxHQUFjLEtBQUt4RixhQUFMLENBQ1RFLFVBRFMsR0FFVEMsSUFGUyxDQUVKYixtREFBRyxDQUFFbUcsTUFBRCxJQUFZQSxNQUFNLENBQUNDLG9CQUFwQixDQUZDLENBQWQ7SUFHQSxLQUFLQyxlQUFMLEdBQXVCLEtBQUtILE1BQUwsQ0FBWXJGLElBQVosQ0FBaUJiLG1EQUFHLENBQUVILEtBQUQsSUFBV0EsS0FBSyxDQUFDeUcsU0FBbEIsQ0FBcEIsRUFBa0R2QixtREFBRyxDQUFFdUIsU0FBRCxJQUFnQixLQUFLQyxVQUFMLEdBQWtCRCxTQUFuQyxDQUFyRCxFQUFxR3RCLHlEQUFTLENBQUVzQixTQUFELElBQWUsS0FBS04sS0FBTCxDQUFXUSxNQUFYLENBQWtCN0MsK0RBQUEsQ0FBeUIyQyxTQUF6QixDQUFsQixDQUFoQixDQUE5RyxDQUF2QjtJQUNBLEtBQUtJLEtBQUwsR0FBYXhCLDRDQUFiO0VBQ0g7O0VBQ0R5QixLQUFLLEdBQUc7SUFDSixLQUFLakcsYUFBTCxDQUFtQmtHLHlCQUFuQjtFQUNIOztFQUNEQyx3QkFBd0IsR0FBRztJQUN2QixLQUFLWixpQkFBTCxDQUF1QmEsUUFBdkIsQ0FBZ0MxQixxREFBaEMsRUFBZ0Q7TUFBRTRCLEVBQUUsRUFBRSxLQUFLVDtJQUFYLENBQWhEO0lBQ0EsS0FBS0ksS0FBTDtFQUNIOztBQWpCc0M7O0FBbUIzQ1osNkJBQTZCLENBQUM5RSxJQUE5QixHQUFxQyxTQUFTZ0cscUNBQVQsQ0FBK0M5RixDQUEvQyxFQUFrRDtFQUFFLE9BQU8sS0FBS0EsQ0FBQyxJQUFJNEUsNkJBQVYsRUFBeUM3RiwrREFBQSxDQUFxQkMsOENBQXJCLENBQXpDLEVBQXlFRCwrREFBQSxDQUFxQkUsb0RBQXJCLENBQXpFLEVBQWlIRiwrREFBQSxDQUFxQkUsd0RBQXJCLENBQWpILENBQVA7QUFBc0ssQ0FBL1A7O0FBQ0EyRiw2QkFBNkIsQ0FBQzFFLElBQTlCLEdBQXFDLGFBQWNuQiwrREFBQSxDQUFxQjtFQUFFcUIsSUFBSSxFQUFFd0UsNkJBQVI7RUFBdUN2RSxTQUFTLEVBQUUsQ0FBQyxDQUFDLDBCQUFELENBQUQsQ0FBbEQ7RUFBa0ZDLEtBQUssRUFBRSxDQUF6RjtFQUE0RkMsSUFBSSxFQUFFLENBQWxHO0VBQXFHQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLG1CQUFELEVBQXNCLFFBQXRCLEVBQWdDLFNBQWhDLEVBQTJDLElBQTNDLEVBQWlELE1BQWpELEVBQXlELFlBQXpELEVBQXVFLFNBQXZFLEVBQWtGLFNBQWxGLEVBQTZGLGNBQTdGLEVBQTZHLFdBQTdHLEVBQTBILENBQTFILEVBQTZILGtCQUE3SCxFQUFpSixDQUFqSixFQUFvSixLQUFwSixDQUFELEVBQTZKLENBQUMsQ0FBRCxFQUFJLE1BQUosQ0FBN0osRUFBMEssQ0FBQyxLQUFELEVBQVEsR0FBUixFQUFhLEtBQWIsRUFBb0IsR0FBcEIsRUFBeUIsU0FBekIsRUFBb0MsR0FBcEMsRUFBeUMsTUFBekMsRUFBaUQsTUFBakQsRUFBeUQsU0FBekQsRUFBb0UsU0FBcEUsRUFBK0UsU0FBL0UsRUFBMEYsVUFBMUYsRUFBc0csQ0FBdEcsRUFBeUcsT0FBekcsRUFBa0gsZUFBbEgsQ0FBMUssRUFBOFMsQ0FBQyxLQUFELEVBQVEsR0FBUixFQUFhLFVBQWIsRUFBeUIsSUFBekIsRUFBK0IsYUFBL0IsRUFBOEMsR0FBOUMsRUFBbUQsQ0FBbkQsRUFBc0QsVUFBdEQsRUFBa0UsaUJBQWxFLEVBQXFGLENBQXJGLEVBQXdGLE1BQXhGLENBQTlTLEVBQStZLENBQUMsS0FBRCxFQUFRLEdBQVIsRUFBYSxNQUFiLEVBQXFCLGtCQUFyQixFQUF5QyxVQUF6QyxFQUFxRCxJQUFyRCxFQUEyRCxDQUEzRCxFQUE4RCxpQkFBOUQsQ0FBL1ksRUFBaWUsQ0FBQyxLQUFELEVBQVEsR0FBUixFQUFhLEtBQWIsRUFBb0IsR0FBcEIsQ0FBamUsRUFBMmYsQ0FBQyxDQUFELEVBQUksVUFBSixDQUEzZixFQUE0Z0IsQ0FBQyxLQUFELEVBQVEsR0FBUixFQUFhLEtBQWIsRUFBb0IsR0FBcEIsRUFBeUIsU0FBekIsRUFBb0MsYUFBcEMsQ0FBNWdCLEVBQWdrQixDQUFDLFVBQUQsRUFBYSxJQUFiLEVBQW1CLFVBQW5CLEVBQStCLE1BQS9CLEVBQXVDLENBQXZDLEVBQTBDLE1BQTFDLEVBQWtELENBQWxELEVBQXFELE1BQXJELENBQWhrQixFQUE4bkIsQ0FBQyxVQUFELEVBQWEsTUFBYixFQUFxQixVQUFyQixFQUFpQyxJQUFqQyxFQUF1QyxDQUF2QyxFQUEwQyxpQkFBMUMsRUFBNkQsQ0FBN0QsRUFBZ0UsTUFBaEUsQ0FBOW5CLENBQTdHO0VBQXF6QkMsUUFBUSxFQUFFLFNBQVNzRixzQ0FBVCxDQUFnRHBGLEVBQWhELEVBQW9EQyxHQUFwRCxFQUF5RDtJQUFFLElBQUlELEVBQUUsR0FBRyxDQUFULEVBQVk7TUFDdDhCNUIsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsWUFBckIsRUFBbUMsQ0FBbkM7TUFDQUEsd0RBQUEsQ0FBYyxLQUFkLEVBQXFCLFNBQVNrSCxnRUFBVCxHQUE0RTtRQUFFLE9BQU9yRixHQUFHLENBQUM4RSx3QkFBSixFQUFQO01BQXdDLENBQTNJO01BQ0EzRyx3REFBQSxDQUFjLENBQWQsRUFBaUJtRixxREFBakIsRUFBd0UsQ0FBeEUsRUFBMkUsQ0FBM0UsRUFBOEUsY0FBOUUsRUFBOEYsQ0FBOUY7TUFDQW5GLG9EQUFBLENBQVUsQ0FBVixFQUFhLE9BQWI7TUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsWUFBckIsRUFBbUMsQ0FBbkM7TUFDQUEsdURBQUEsQ0FBYSxDQUFiLEVBQWdCLE9BQWhCLEVBQXlCLENBQXpCLEVBQTRCLENBQTVCLEVBQStCLE9BQS9CLEVBQXdDLENBQXhDO01BQ0FBLDBEQUFBO0lBQ0g7O0lBQUMsSUFBSTRCLEVBQUUsR0FBRyxDQUFULEVBQVk7TUFDVjVCLHVEQUFBLENBQWEsQ0FBYjtNQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0JBLHlEQUFBLENBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQjZCLEdBQUcsQ0FBQ3NFLGVBQXpCLENBQXRCO01BQ0FuRyx1REFBQSxDQUFhLENBQWI7TUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCNkIsR0FBRyxDQUFDMkUsS0FBSixDQUFVWSxJQUFoQztJQUNIO0VBQUUsQ0FiaUU7RUFhL0Q5RSxZQUFZLEVBQUUsQ0FBQ25DLGlEQUFELEVBQVVDLGtHQUFWLEVBQXFDRCxzREFBckMsQ0FiaUQ7RUFhR3dDLGFBQWEsRUFBRTtBQWJsQixDQUFyQixDQUFuRDs7Ozs7Ozs7Ozs7OztBQzlDMEY7QUFDdEQ7QUFDSjtBQUN6QjtBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLDRDQUFLO0FBQzFCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MscURBQWMsSUFBSSxhQUFhO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBLG1GQUFtRiw2Q0FBNkMsK0RBQW9CLENBQUMsa0RBQWMsR0FBRywrREFBb0IsQ0FBQyxvREFBZ0IsR0FBRywrREFBb0IsQ0FBQyx3REFBb0I7QUFDdlAsZ0RBQWdELCtEQUFvQixHQUFHLDB1Q0FBMHVDO0FBQ2p6QyxRQUFRLDREQUFpQjtBQUN6QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsd0RBQWEsbUZBQW1GLHFDQUFxQztBQUM3SSxRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsMERBQWU7QUFDdkIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDBEQUFlO0FBQ3ZCLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSwwREFBZTtBQUN2QixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsMERBQWU7QUFDdkIsTUFBTTtBQUNOLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsT0FBTyxvQkFBb0I7Ozs7Ozs7Ozs7Ozs7OztBQzlDc0U7QUFDN0Q7QUFDSjtBQUNNO0FBQ3RDLDBEQUEwRDtBQUMxRCxnQkFBZ0IsOERBQW1CO0FBQ25DLElBQUkscUVBQTBCO0FBQzlCLElBQUksNERBQWlCO0FBQ3JCLElBQUksd0RBQWEscUZBQXFGLG9CQUFvQiwyREFBZ0IsT0FBTyx5Q0FBeUMsT0FBTyx5REFBYyx5Q0FBeUM7QUFDeFAsSUFBSSx1REFBWTtBQUNoQixJQUFJLDBEQUFlO0FBQ25CLElBQUksbUVBQXdCO0FBQzVCLEVBQUU7QUFDRjtBQUNBLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDTztBQUNQO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQiw0Q0FBSztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELGtEQUFXO0FBQy9EO0FBQ0EsaUJBQWlCO0FBQ2pCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9EQUFvRCxxREFBYztBQUNsRTtBQUNBLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2IsY0FBYyxzREFBc0Q7QUFDcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0Qsb0RBQWE7QUFDakU7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiLGNBQWMsNENBQTRDO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlEQUF5RCxnQ0FBZ0MsK0RBQW9CLENBQUMsb0RBQWdCLEdBQUcsK0RBQW9CLENBQUMsd0RBQW9CO0FBQzFLLG1DQUFtQywrREFBb0IsR0FBRyx5cEJBQXlwQjtBQUNudEIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx3REFBYSxpRUFBaUUseUJBQXlCO0FBQy9HLFFBQVEsMERBQWU7QUFDdkIsUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsMERBQWU7QUFDdkIsTUFBTTtBQUNOLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsT0FBTyxpQkFBaUIsb0RBQVUsNkJBQTZCLFlBQVkseURBQWtCLEtBQUs7Ozs7Ozs7Ozs7Ozs7QUN0RTlEO0FBQzdCO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1REFBdUQ7QUFDdkQsa0NBQWtDLCtEQUFvQixHQUFHLHVEQUF1RCwwQ0FBMEMsa09BQWtPO0FBQzVYLFFBQVEsNERBQWlCO0FBQ3pCLFFBQVEsdURBQVk7QUFDcEIsUUFBUSwwREFBZTtBQUN2QixNQUFNO0FBQ04sUUFBUSx5REFBYztBQUN0QixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEseURBQWM7QUFDdEIsUUFBUSx3REFBYTtBQUNyQixPQUFPLG9CQUFvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQkU7QUFDa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ2tCO0FBQzdCO0FBQzZDO0FBQ047QUFDcUI7QUFDTjtBQUNBO0FBQ2Q7QUFDakI7QUFDSjtBQUNGO0FBQzlDO0FBQ1A7QUFDQSx1REFBdUQ7QUFDdkQsa0NBQWtDLDhEQUFtQixHQUFHLG9CQUFvQjtBQUM1RSxrQ0FBa0MsOERBQW1CLEdBQUcsVUFBVSwwREFBWSxFQUFFLDRFQUF3QixHQUFHOzs7Ozs7Ozs7Ozs7OztBQ2hCM0c7QUFDQTtBQUNBO0FBQ0E7QUFDb0M7QUFDcEM7QUFDeUM7QUFDekM7QUFDQTtBQUNBO0FBQ0E7QUFDdUQ7QUFDdkQ7QUFDaUI7QUFDakI7QUFDK0I7Ozs7Ozs7O0FDZi9CIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9tYWluLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwLmNzcyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9hcHAtcm91dGluZy5tb2R1bGUudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvYXBwLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9hcHAubW9kdWxlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvYW5pbWF0aW9ucy9mYWRlLmFuaW1hdGlvbi50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL2FuaW1hdGlvbnMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9hbmltYXRpb25zL3NsaWRlLmFuaW1hdGlvbi50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL2FuaW1hdGlvbnMvc3RhZ2dlci5hbmltYXRpb24udHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9pbmRleC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL21vZGVscy9jb25zdGFudHMvYXBpLXJvdXRlcy50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL21vZGVscy9jb25zdGFudHMvaWNvbnMudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9tb2RlbHMvY29uc3RhbnRzL2luZGV4LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvbW9kZWxzL2NvbnN0YW50cy9yb3V0ZXMudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9tb2RlbHMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9tb2RlbHMvaW50ZXJmYWNlcy9jYXRlZ29yeS5pbnRlcmZhY2UudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9tb2RlbHMvaW50ZXJmYWNlcy9pbmRleC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL21vZGVscy9pbnRlcmZhY2VzL3Byb2R1Y3QtZ3JvdXAuaW50ZXJmYWNlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvbW9kZWxzL2ludGVyZmFjZXMvcHJvZHVjdC5pbnRlcmZhY2UudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9tb2RlbHMvaW50ZXJmYWNlcy9wcm9maWxlLmludGVyZmFjZS50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL21vZGVscy9pbnRlcmZhY2VzL3JlbW90ZS1zdHlsZXMuaW50ZXJmYWNlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvc2VydmljZXMvYXBpLnNlcnZpY2UudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zZXJ2aWNlcy9kYXRhLnNlcnZpY2UudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zZXJ2aWNlcy9pbmRleC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL3NlcnZpY2VzL25hdmlnYXRpb24uc2VydmljZS50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL3NlcnZpY2VzL3VpL2luZGV4LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvc2VydmljZXMvdWkvanMtYW5pbWF0aW9uLnNlcnZpY2UudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zZXJ2aWNlcy91aS9sYXllcnMuc2VydmljZS50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL3NlcnZpY2VzL3VpL3N0bHlpbmcuc2VydmljZS50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL3N0YXRlL2NvbmZpZy9jb25maWcuYWN0aW9ucy50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9jb3JlL3N0YXRlL2NvbmZpZy9jb25maWcubW9kZWwudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zdGF0ZS9jb25maWcvY29uZmlnLnN0YXRlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvc3RhdGUvY29uZmlnL2luZGV4LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvc3RhdGUvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zdGF0ZS9wcm9kdWN0L2luZGV4LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2NvcmUvc3RhdGUvcHJvZHVjdC9wcm9kdWN0LmFjdGlvbnMudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zdGF0ZS9wcm9kdWN0L3Byb2R1Y3QubW9kZWwudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvY29yZS9zdGF0ZS9wcm9kdWN0L3Byb2R1Y3Quc3RhdGUudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvZmVhdHVyZXMvbG9hZGluZy9sb2FkaW5nLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9mZWF0dXJlcy9sb2FkaW5nL2xvYWRpbmcubW9kdWxlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2NhcmRzL2luZGV4LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2NhcmRzL3NlYXJjaC1jYXJkL3NlYXJjaC1jYXJkLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9jYXJkcy90aHVtYm5haWwtY2FyZC90aHVtYm5haWwtY2FyZC5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvbGF5ZXJzL2FsZXJ0LXBvcHVwL2FsZXJ0LXBvcHVwLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9sYXllcnMvZmlsdGVyLWJvdHRvbXNoZWV0L2ZpbHRlci1ib3R0b21zaGVldC5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvbGF5ZXJzL2luZGV4LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL3NoYXJlZC9jb21wb25lbnRzL2xheWVycy9xdWlja3ZpZXctYm90dG9tc2hlZXQvcXVpY2t2aWV3LWJvdHRvbXNoZWV0LmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy9sYXllcnMvc2VhcmNoLWJvdHRvbXNoZWV0L3NlYXJjaC1ib3R0b21zaGVldC5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvc2hhcmVkL2NvbXBvbmVudHMvbWVudS9tZW51LmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9zaGFyZWQvY29tcG9uZW50cy90YWcvdGFnLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9zaGFyZWQvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvc2hhcmVkL3NoYXJlZC5tb2R1bGUudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9wb2x5ZmlsbHMudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy9leHRlcm5hbCBjb21tb25qcyBcIn4vcGFja2FnZS5qc29uXCIiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQWRkZWQgYnkgYXBwLWNzcy1sb2FkZXJcbmltcG9ydCBcIi4vYXBwLmNzc1wiO1xuaW1wb3J0IHsgcGxhdGZvcm1OYXRpdmVTY3JpcHQsIHJ1bk5hdGl2ZVNjcmlwdEFuZ3VsYXJBcHAgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgeyBBcHBNb2R1bGUgfSBmcm9tIFwiLi9hcHAvYXBwLm1vZHVsZVwiO1xuaW1wb3J0IHsgTG9hZGluZ01vZHVsZSB9IGZyb20gXCIuL2FwcC9mZWF0dXJlcy9sb2FkaW5nL2xvYWRpbmcubW9kdWxlXCI7XG5ydW5OYXRpdmVTY3JpcHRBbmd1bGFyQXBwKHtcbiAgICBhcHBNb2R1bGVCb290c3RyYXA6IChyZWFzb24pID0+IHBsYXRmb3JtTmF0aXZlU2NyaXB0KCkuYm9vdHN0cmFwTW9kdWxlKEFwcE1vZHVsZSksXG4gICAgbG9hZGluZ01vZHVsZTogKHJlYXNvbikgPT4gcGxhdGZvcm1OYXRpdmVTY3JpcHQoKS5ib290c3RyYXBNb2R1bGUoTG9hZGluZ01vZHVsZSksXG59KTtcbiIsIi8qIENTUzJKU09OICovXG5cbmNvbnN0IF9fX0NTUzJKU09OX0xPQURFUl9FWFBPUlRfX18gPSB7XCJ0eXBlXCI6XCJzdHlsZXNoZWV0XCIsXCJzdHlsZXNoZWV0XCI6e1wicnVsZXNcIjpbe1widHlwZVwiOlwiY29tbWVudFwiLFwiY29tbWVudFwiOlwiIEZvbnRzIFwifSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZmFcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LWZhbWlseVwiLFwidmFsdWVcIjpcIkZvbnRBd2Vzb21lLCBmb250YXdlc29tZS13ZWJmb250XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmlvbmljb25zXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1mYW1pbHlcIixcInZhbHVlXCI6XCJJb25pY29ucywgaW9uaWNvbnNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYm9sZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtZmFtaWx5XCIsXCJ2YWx1ZVwiOlwiXFxcIlBvcHBpbnMgQm9sZFxcXCIsIFxcXCJQb3BwaW5zLUJvbGRcXFwiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCI3MDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubWVkaXVtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1mYW1pbHlcIixcInZhbHVlXCI6XCJcXFwiUG9wcGlucyBNZWRpdW1cXFwiLCBcXFwiUG9wcGlucy1NZWRpdW1cXFwiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCI1MDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucmVndWxhclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtZmFtaWx5XCIsXCJ2YWx1ZVwiOlwiXFxcIlBvcHBpbnMgUmVndWxhclxcXCIsIFxcXCJQb3BwaW5zLVJlZ3VsYXJcXFwiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCI0MDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubGlnaHRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LWZhbWlseVwiLFwidmFsdWVcIjpcIlxcXCJQb3BwaW5zIExpZ2h0XFxcIiwgXFxcIlBvcHBpbnMtTGlnaHRcXFwiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCIzMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuaW9uLWFsZXJ0OmJlZm9yZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbnRlbnRcIixcInZhbHVlXCI6XCJcXFwiXFxcXGYxMDFcXFwiXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLXJvb3RcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiY29tbWVudFwiLFwiY29tbWVudFwiOlwiIENvbG9ycyBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLXByaW1hcnlcIixcInZhbHVlXCI6XCIjNjVhZGYxXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1iZy1kZWZhdWx0XCIsXCJ2YWx1ZVwiOlwiI2ZlZmVmZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29sb3ItYmctZ3JheVwiLFwidmFsdWVcIjpcIiM0NDRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLXRleHQtb24tcHJpbWFyeVwiLFwidmFsdWVcIjpcIiNmZWZlZmVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLXRleHQtZGVmYXVsdFwiLFwidmFsdWVcIjpcIiMzOTM4MzhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLXRleHQtZ3JheVwiLFwidmFsdWVcIjpcIiM0NDRcIn0se1widHlwZVwiOlwiY29tbWVudFwiLFwiY29tbWVudFwiOlwiIFNwYWNpbmcgXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1zcGFjaW5nLXhsXCIsXCJ2YWx1ZVwiOlwiMjVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLXNwYWNpbmctbFwiLFwidmFsdWVcIjpcIjE1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1zcGFjaW5nLW1cIixcInZhbHVlXCI6XCIxMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tc3BhY2luZy1zXCIsXCJ2YWx1ZVwiOlwiNVwifSx7XCJ0eXBlXCI6XCJjb21tZW50XCIsXCJjb21tZW50XCI6XCIgQm9yZGVyIFJhZGl1cyBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWJvcmRlci1yYWRpdXMtbFwiLFwidmFsdWVcIjpcIjE1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1ib3JkZXItcmFkaXVzLW1cIixcInZhbHVlXCI6XCIxMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tYm9yZGVyLXJhZGl1cy1zXCIsXCJ2YWx1ZVwiOlwiNVwifSx7XCJ0eXBlXCI6XCJjb21tZW50XCIsXCJjb21tZW50XCI6XCIgRm9udCBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWZvbnQtc2l6ZS1oMVwiLFwidmFsdWVcIjpcIjI1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1mb250LXNpemUtaDJcIixcInZhbHVlXCI6XCIyMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZm9udC1zaXplLWgzXCIsXCJ2YWx1ZVwiOlwiMThcIn0se1widHlwZVwiOlwiY29tbWVudFwiLFwiY29tbWVudFwiOlwiIFNoYWRvd3MgXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1ib3gtc2hhZG93LWRlZmF1bHRcIixcInZhbHVlXCI6XCIwIDAgNXB4IHJnYmEoMCwgMCwgMCwgMC44KVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tdGV4dC1zaGFkb3ctZGVmYXVsdFwiLFwidmFsdWVcIjpcIjFweCAxcHggMXB4IHJnYmEoMTAxLCAxNzMsIDI0MSwgMC44KVwifV19LHtcInR5cGVcIjpcImNvbW1lbnRcIixcImNvbW1lbnRcIjpcIiBTcGFjaW5nIFwifSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC14bFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLXhsKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1sKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1tKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1zKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXhsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy14bClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1sKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLW0pXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tc1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmctcylcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmctbClcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLWwpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teC1tXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLW0pXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1tKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXgtc1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1zKVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmctcylcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS10LXhsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmcteGwpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC1sXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmctbClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS10LW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1tKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXQtc1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLXMpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi14bFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLXhsKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWItbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCJ2YXIoLS1zcGFjaW5nLWwpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi1tXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmctbSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1iLXNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1zKVwifV19LHtcInR5cGVcIjpcImNvbW1lbnRcIixcImNvbW1lbnRcIjpcIiBGb250IFwifSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZm9udC1zaXplLWgxXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwidmFyKC0tZm9udC1zaXplLWgxKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5mb250LXNpemUtaDJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCJ2YXIoLS1mb250LXNpemUtaDIpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmZvbnQtc2l6ZS1oM1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcInZhcigtLWZvbnQtc2l6ZS1oMylcIn1dfSx7XCJ0eXBlXCI6XCJjb21tZW50XCIsXCJjb21tZW50XCI6XCIgQnV0dG9uIFwifSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYnV0dG9uLXByaW1hcnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCJ2YXIoLS1mb250LXNpemUtaDMpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInZhcigtLWNvbG9yLXByaW1hcnkpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCJ2YXIoLS1jb2xvci10ZXh0LW9uLXByaW1hcnkpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcInZhcigtLXNwYWNpbmctbClcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItcmFkaXVzXCIsXCJ2YWx1ZVwiOlwidmFyKC0tYm9yZGVyLXJhZGl1cy1tKVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInRleHQtdHJhbnNmb3JtXCIsXCJ2YWx1ZVwiOlwibm9uZVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5idXR0b24tdGV4dFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcInZhcigtLWZvbnQtc2l6ZS1oMylcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcInZhcigtLWNvbG9yLXRleHQtZ3JheSlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwidmFyKC0tc3BhY2luZy1sKVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInRleHQtdHJhbnNmb3JtXCIsXCJ2YWx1ZVwiOlwibm9uZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJ0cmFuc3BhcmVudFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci13aWR0aFwiLFwidmFsdWVcIjpcIjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ6LWluZGV4XCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlBhZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidmFyKC0tY29sb3ItYmctZGVmYXVsdClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJsYWJlbFwiLFwiVGV4dEZpZWxkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCJ2YXIoLS1jb2xvci10ZXh0LWRlZmF1bHQpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1mYW1pbHlcIixcInZhbHVlXCI6XCJcXFwiUG9wcGlucyBSZWd1bGFyXFxcIiwgUG9wcGlucy1SZWd1bGFyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCI0MDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudGV4dC1jb2xvci1wcmltYXJ5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCJ2YXIoLS1jb2xvci1wcmltYXJ5KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50ZXh0LWNvbG9yLWxpZ2h0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCJ2YXIoLS1jb2xvci1iZy1kZWZhdWx0KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50ZXh0LWNvbG9yLWdyYXlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcInZhcigtLWNvbG9yLXRleHQtZ3JheSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYmctY29sb3ItcHJpbWFyeVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJ2YXIoLS1jb2xvci1wcmltYXJ5KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5iZy1jb2xvci1kZWZhdWx0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInZhcigtLWNvbG9yLWJnLWRlZmF1bHQpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmJvcmRlci1wcmltYXJ5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidmFyKC0tY29sb3ItcHJpbWFyeSlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItd2lkdGhcIixcInZhbHVlXCI6XCIxXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmJvcmRlci1saWdodFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcInZhcigtLWNvbG9yLWJnLWRlZmF1bHQpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXdpZHRoXCIsXCJ2YWx1ZVwiOlwiMVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ib3JkZXItYi1wcmltYXJ5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS1jb2xvclwiLFwidmFsdWVcIjpcInZhcigtLWNvbG9yLXByaW1hcnkpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS13aWR0aFwiLFwidmFsdWVcIjpcIjFcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYm9yZGVyLXQtZ3JheVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci10b3AtY29sb3JcIixcInZhbHVlXCI6XCJ2YXIoLS1jb2xvci1iZy1ncmF5KSB2YXIoLS1jb2xvci10ZXh0LWdyYXkpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXRvcC13aWR0aFwiLFwidmFsdWVcIjpcIjFcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYm9yZGVyLXJhZGl1cy1sXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcInZhcigtLWJvcmRlci1yYWRpdXMtbClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYm9yZGVyLXJhZGl1cy1tXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcInZhcigtLWJvcmRlci1yYWRpdXMtbSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYm9yZGVyLXJhZGl1cy1zXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcInZhcigtLWJvcmRlci1yYWRpdXMtcylcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZ2xvdy1zaGFkb3dcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3gtc2hhZG93XCIsXCJ2YWx1ZVwiOlwidmFyKC0tYm94LXNoYWRvdy1kZWZhdWx0KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50aXRsZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInRleHQtc2hhZG93XCIsXCJ2YWx1ZVwiOlwidmFyKC0tdGV4dC1zaGFkb3ctZGVmYXVsdClcIn1dfSx7XCJ0eXBlXCI6XCJjb21tZW50XCIsXCJjb21tZW50XCI6XCIgYWxpZ25tZW50cyBcIn0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnRleHQtY2VudGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi52LWNlbnRlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInZlcnRpY2FsLWFsaWduXCIsXCJ2YWx1ZVwiOlwiY2VudGVyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnYtdG9wXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidmVydGljYWwtYWxpZ25cIixcInZhbHVlXCI6XCJ0b3BcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudi1ib3R0b21cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ2ZXJ0aWNhbC1hbGlnblwiLFwidmFsdWVcIjpcImJvdHRvbVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5oLWNlbnRlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn1dfV0sXCJwYXJzaW5nRXJyb3JzXCI6W119fVxuZXhwb3J0IGRlZmF1bHQgX19fQ1NTMkpTT05fTE9BREVSX0VYUE9SVF9fX1xuY29uc3QgeyBhZGRUYWdnZWRBZGRpdGlvbmFsQ1NTIH0gPSByZXF1aXJlKFwiQG5hdGl2ZXNjcmlwdC9jb3JlL3VpL3N0eWxpbmcvc3R5bGUtc2NvcGVcIik7XG5hZGRUYWdnZWRBZGRpdGlvbmFsQ1NTKF9fX0NTUzJKU09OX0xPQURFUl9FWFBPUlRfX18sIFwiL1VzZXJzL2RvdWdsYXNtYWNoYWRvL0RvY3VtZW50cy9BcHBpdW0vYmxvZ1Bvc3QvbmF0aXZlc2NyaXB0LW1vdmllcy1kZW1vLW1hc3Rlci9zcmMvYXBwLmNzc1wiKVxuIiwiaW1wb3J0IHsgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlIH0gZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmNvbnN0IHJvdXRlcyA9IFtcbiAgICB7IHBhdGg6IFwiXCIsIHJlZGlyZWN0VG86IFwiL2hvbWVcIiwgcGF0aE1hdGNoOiBcImZ1bGxcIiB9LFxuICAgIHtcbiAgICAgICAgcGF0aDogXCJob21lXCIsXG4gICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KFwiLi9mZWF0dXJlcy9ob21lL2hvbWUubW9kdWxlXCIpLnRoZW4oKG0pID0+IG0uSG9tZU1vZHVsZSksXG4gICAgfSxcbiAgICB7XG4gICAgICAgIHBhdGg6IFwiZGV0YWlsc1wiLFxuICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydChcIi4vZmVhdHVyZXMvZGV0YWlscy9kZXRhaWxzLm1vZHVsZVwiKS50aGVuKChtKSA9PiBtLkRldGFpbHNNb2R1bGUpLFxuICAgIH0sXG4gICAge1xuICAgICAgICBwYXRoOiBcInByb2ZpbGVcIixcbiAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoXCIuL2ZlYXR1cmVzL3Byb2ZpbGUvcHJvZmlsZS5tb2R1bGVcIikudGhlbigobSkgPT4gbS5Qcm9maWxlTW9kdWxlKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgcGF0aDogXCJjb25maWdcIixcbiAgICAgICAgbG9hZENoaWxkcmVuOiAoKSA9PiBpbXBvcnQoXCIuL2ZlYXR1cmVzL2NvbmZpZy9jb25maWcubW9kdWxlXCIpLnRoZW4oKG0pID0+IG0uQ29uZmlnTW9kdWxlKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgcGF0aDogXCJvdGhlci1hcHBzXCIsXG4gICAgICAgIGxvYWRDaGlsZHJlbjogKCkgPT4gaW1wb3J0KFwiLi9mZWF0dXJlcy9vdGhlci1hcHBzL290aGVyLWFwcHMubW9kdWxlXCIpLnRoZW4oKG0pID0+IG0uT3RoZXJBcHBzTW9kdWxlKSxcbiAgICB9LFxuXTtcbmV4cG9ydCBjbGFzcyBBcHBSb3V0aW5nTW9kdWxlIHtcbn1cbkFwcFJvdXRpbmdNb2R1bGUuybVmYWMgPSBmdW5jdGlvbiBBcHBSb3V0aW5nTW9kdWxlX0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IEFwcFJvdXRpbmdNb2R1bGUpKCk7IH07XG5BcHBSb3V0aW5nTW9kdWxlLsm1bW9kID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lTmdNb2R1bGUoeyB0eXBlOiBBcHBSb3V0aW5nTW9kdWxlIH0pO1xuQXBwUm91dGluZ01vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW05hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZS5mb3JSb290KHJvdXRlcyksIE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZV0gfSk7XG4iLCJpbXBvcnQgeyB0cmFuc2l0aW9uLCBzdHlsZSwgc3RhdGUsIGFuaW1hdGUsIHRyaWdnZXIsIH0gZnJvbSBcIkBhbmd1bGFyL2FuaW1hdGlvbnNcIjtcbmltcG9ydCB7IG1hcCB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuaW1wb3J0IHsgTGF5ZXJzU2VydmljZSB9IGZyb20gXCIuL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiLi9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMiBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgKiBhcyBpMyBmcm9tIFwiLi9zaGFyZWQvY29tcG9uZW50cy9sYXllcnMvYWxlcnQtcG9wdXAvYWxlcnQtcG9wdXAuY29tcG9uZW50XCI7XG5pbXBvcnQgKiBhcyBpNCBmcm9tIFwiLi9zaGFyZWQvY29tcG9uZW50cy9tZW51L21lbnUuY29tcG9uZW50XCI7XG5pbXBvcnQgKiBhcyBpNSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5leHBvcnQgY2xhc3MgQXBwQ29tcG9uZW50IHtcbiAgICBjb25zdHJ1Y3RvcihsYXllcnNTZXJ2aWNlKSB7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZSA9IGxheWVyc1NlcnZpY2U7XG4gICAgICAgIHRoaXMubWVudUlzT3BlbiQgPSB0aGlzLmxheWVyc1NlcnZpY2VcbiAgICAgICAgICAgIC5nZXRMYXllcnMkKClcbiAgICAgICAgICAgIC5waXBlKG1hcCgoc3RhdGUpID0+IHN0YXRlLm1lbnUuaXNPcGVuKSk7XG4gICAgfVxuICAgIGNsb3NlTWVudSgpIHtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlLmNsb3NlTWVudSgpO1xuICAgIH1cbn1cbkFwcENvbXBvbmVudC7JtWZhYyA9IGZ1bmN0aW9uIEFwcENvbXBvbmVudF9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBBcHBDb21wb25lbnQpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTEuTGF5ZXJzU2VydmljZSkpOyB9O1xuQXBwQ29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogQXBwQ29tcG9uZW50LCBzZWxlY3RvcnM6IFtbXCJucy1hcHBcIl1dLCBkZWNsczogMTMsIHZhcnM6IDE0LCBjb25zdHM6IFtbMSwgXCJiZy1jb2xvci1kZWZhdWx0XCJdLCBbXCJjb2x1bW5zXCIsIFwiKiwqXCIsIFwiaW9zT3ZlcmZsb3dTYWZlQXJlYVwiLCBcImZhbHNlXCJdLCBbXCJjb2xcIiwgXCIwXCJdLCBbXCJjb2xcIiwgXCIwXCIsIFwiY29sU3BhblwiLCBcIjJcIl0sIFsxLCBcImJnLWNvbG9yLXByaW1hcnlcIl1dLCB0ZW1wbGF0ZTogZnVuY3Rpb24gQXBwQ29tcG9uZW50X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDAsIFwiUm9vdExheW91dFwiLCAwKSgxLCBcIkdyaWRMYXlvdXRcIiwgMSkoMiwgXCJDb250ZW50Vmlld1wiLCAyKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMywgXCJucy1tZW51XCIpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDQsIFwiR3JpZExheW91dFwiLCAzKTtcbiAgICAgICAgaTAuybXJtXBpcGUoNSwgXCJhc3luY1wiKTtcbiAgICAgICAgaTAuybXJtXBpcGUoNiwgXCJhc3luY1wiKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoNywgXCJDb250ZW50Vmlld1wiLCA0KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCg4LCBcIkdyaWRMYXlvdXRcIiwgMyk7XG4gICAgICAgIGkwLsm1ybVwaXBlKDksIFwiYXN5bmNcIik7XG4gICAgICAgIGkwLsm1ybVwaXBlKDEwLCBcImFzeW5jXCIpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgxMSwgXCJwYWdlLXJvdXRlci1vdXRsZXRcIik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDEyLCBcIm5zLWFsZXJ0LXBvcHVwXCIsIDMpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpKCk7XG4gICAgfSBpZiAocmYgJiAyKSB7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDQpO1xuICAgICAgICBpMC7Jtcm1Y2xhc3NQcm9wKFwiZ2xvdy1zaGFkb3dcIiwgaTAuybXJtXBpcGVCaW5kMSg1LCA2LCBjdHgubWVudUlzT3BlbiQpKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwiQG1haW5Db250ZW50U2hhZGVcIiwgaTAuybXJtXBpcGVCaW5kMSg2LCA4LCBjdHgubWVudUlzT3BlbiQpID8gXCJtZW51SXNPcGVuXCIgOiBcIm1lbnVJc0Nsb3NlZFwiKTtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoNCk7XG4gICAgICAgIGkwLsm1ybVjbGFzc1Byb3AoXCJnbG93LXNoYWRvd1wiLCBpMC7Jtcm1cGlwZUJpbmQxKDksIDEwLCBjdHgubWVudUlzT3BlbiQpKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwiQG1haW5Db250ZW50XCIsIGkwLsm1ybVwaXBlQmluZDEoMTAsIDEyLCBjdHgubWVudUlzT3BlbiQpID8gXCJtZW51SXNPcGVuXCIgOiBcIm1lbnVJc0Nsb3NlZFwiKTtcbiAgICB9IH0sIGRlcGVuZGVuY2llczogW2kyLlBhZ2VSb3V0ZXJPdXRsZXQsIGkzLkFsZXJ0UG9wdXBDb21wb25lbnQsIGk0Lk1lbnVDb21wb25lbnQsIGk1LkFzeW5jUGlwZV0sIGVuY2Fwc3VsYXRpb246IDIsIGRhdGE6IHsgYW5pbWF0aW9uOiBbXG4gICAgICAgICAgICB0cmlnZ2VyKFwibWFpbkNvbnRlbnRcIiwgW1xuICAgICAgICAgICAgICAgIHN0YXRlKFwibWVudUlzT3BlblwiLCBzdHlsZSh7IHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMjAwLCA3MClzY2FsZSgwLjcsMC43KVwiIH0pKSxcbiAgICAgICAgICAgICAgICBzdGF0ZShcIm1lbnVJc0Nsb3NlZFwiLCBzdHlsZSh7IHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMCwgMClzY2FsZSgxLDEpXCIgfSkpLFxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb24oXCJtZW51SXNDbG9zZWQgPT4gbWVudUlzT3BlblwiLCBhbmltYXRlKFwiMzAwbXMgZWFzZS1pbi1vdXRcIiwgc3R5bGUoeyB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDIwMCwgNzApc2NhbGUoMC43LDAuNylcIiB9KSkpLFxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb24oXCJtZW51SXNPcGVuID0+IG1lbnVJc0Nsb3NlZFwiLCBhbmltYXRlKFwiMzAwbXMgZWFzZS1pbi1vdXRcIiwgc3R5bGUoeyB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDAsIDApc2NhbGUoMSwxKVwiIH0pKSksXG4gICAgICAgICAgICBdKSxcbiAgICAgICAgICAgIHRyaWdnZXIoXCJtYWluQ29udGVudFNoYWRlXCIsIFtcbiAgICAgICAgICAgICAgICBzdGF0ZShcIm1lbnVJc09wZW5cIiwgc3R5bGUoeyB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDE2NSwgNzUpc2NhbGUoMC42NSwwLjY1KVwiIH0pKSxcbiAgICAgICAgICAgICAgICBzdGF0ZShcIm1lbnVJc0Nsb3NlZFwiLCBzdHlsZSh7IHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMCwgMClzY2FsZSgxLDEpXCIgfSkpLFxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb24oXCJtZW51SXNDbG9zZWQgPT4gbWVudUlzT3BlblwiLCBhbmltYXRlKFwiMzAwbXMgMTAwbXMgZWFzZS1pbi1vdXRcIiwgc3R5bGUoeyB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDE2NSwgNzUpc2NhbGUoMC42NSwwLjY1KVwiIH0pKSksXG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbihcIm1lbnVJc09wZW4gPT4gbWVudUlzQ2xvc2VkXCIsIGFuaW1hdGUoXCIzMDBtcyBlYXNlLWluLW91dFwiLCBzdHlsZSh7IHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMCwgMClzY2FsZSgxLDEpXCIgfSkpKSxcbiAgICAgICAgICAgIF0pLFxuICAgICAgICBdIH0gfSk7XG4iLCJpbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyBIdHRwQ2xpZW50TW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vbi9odHRwXCI7XG5pbXBvcnQgeyBBUFBfSU5JVElBTElaRVIgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgTmF0aXZlU2NyaXB0TW9kdWxlLCBOYXRpdmVTY3JpcHRBbmltYXRpb25zTW9kdWxlLCBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsIE5hdGl2ZVNjcmlwdEh0dHBDbGllbnRNb2R1bGUsIH0gZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0IHsgTmd4c01vZHVsZSB9IGZyb20gXCJAbmd4cy9zdG9yZVwiO1xuaW1wb3J0IHsgQXBwUm91dGluZ01vZHVsZSB9IGZyb20gXCIuL2FwcC1yb3V0aW5nLm1vZHVsZVwiO1xuaW1wb3J0IHsgQXBwQ29tcG9uZW50IH0gZnJvbSBcIi4vYXBwLmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgQ29uZmlnU3RhdGUsIFByb2R1Y3RTdGF0ZSB9IGZyb20gXCIuL2NvcmVcIjtcbmltcG9ydCB7IFNoYXJlZE1vZHVsZSB9IGZyb20gXCIuL3NoYXJlZFwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAbmd4cy9zdG9yZVwiO1xuZXhwb3J0IGZ1bmN0aW9uIGFzeW5jQm9vdCgpIHtcbiAgICByZXR1cm4gKCkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgIH0pO1xuICAgICAgICAvLyB9LCAxMDAwKTtcbiAgICB9KTtcbn1cbmV4cG9ydCBjbGFzcyBBcHBNb2R1bGUge1xufVxuQXBwTW9kdWxlLsm1ZmFjID0gZnVuY3Rpb24gQXBwTW9kdWxlX0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IEFwcE1vZHVsZSkoKTsgfTtcbkFwcE1vZHVsZS7JtW1vZCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZU5nTW9kdWxlKHsgdHlwZTogQXBwTW9kdWxlLCBib290c3RyYXA6IFtBcHBDb21wb25lbnRdIH0pO1xuQXBwTW9kdWxlLsm1aW5qID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lSW5qZWN0b3IoeyBwcm92aWRlcnM6IFtcbiAgICAgICAge1xuICAgICAgICAgICAgcHJvdmlkZTogQVBQX0lOSVRJQUxJWkVSLFxuICAgICAgICAgICAgdXNlRmFjdG9yeTogYXN5bmNCb290LFxuICAgICAgICAgICAgbXVsdGk6IHRydWUsXG4gICAgICAgIH0sXG4gICAgXSwgaW1wb3J0czogW05hdGl2ZVNjcmlwdE1vZHVsZSxcbiAgICAgICAgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLFxuICAgICAgICBOYXRpdmVTY3JpcHRIdHRwQ2xpZW50TW9kdWxlLFxuICAgICAgICBDb21tb25Nb2R1bGUsXG4gICAgICAgIEh0dHBDbGllbnRNb2R1bGUsXG4gICAgICAgIE5hdGl2ZVNjcmlwdEFuaW1hdGlvbnNNb2R1bGUsXG4gICAgICAgIE5neHNNb2R1bGUuZm9yUm9vdChbQ29uZmlnU3RhdGUsIFByb2R1Y3RTdGF0ZV0sIHsgZGV2ZWxvcG1lbnRNb2RlOiB0cnVlIH0pLFxuICAgICAgICBBcHBSb3V0aW5nTW9kdWxlLFxuICAgICAgICBTaGFyZWRNb2R1bGVdIH0pO1xuIiwiaW1wb3J0IHsgdHJhbnNpdGlvbiwgc3R5bGUsIGFuaW1hdGUsIHRyaWdnZXIgfSBmcm9tIFwiQGFuZ3VsYXIvYW5pbWF0aW9uc1wiO1xuZXhwb3J0IGNvbnN0IEZhZGUgPSB0cmlnZ2VyKFwiZmFkZVwiLCBbXG4gICAgdHJhbnNpdGlvbihcIjplbnRlclwiLCBbXG4gICAgICAgIHN0eWxlKHsgb3BhY2l0eTogMCB9KSxcbiAgICAgICAgYW5pbWF0ZShcIjMwMG1zIDEwMG1zIGVhc2UtaW5cIiwgc3R5bGUoeyBvcGFjaXR5OiAxIH0pKSxcbiAgICBdKSxcbiAgICB0cmFuc2l0aW9uKFwiOmxlYXZlXCIsIFtcbiAgICAgICAgc3R5bGUoeyBvcGFjaXR5OiAxIH0pLFxuICAgICAgICBhbmltYXRlKFwiMzAwbXMgMTAwbXMgZWFzZS1pblwiLCBzdHlsZSh7IG9wYWNpdHk6IDAgfSkpLFxuICAgIF0pLFxuXSk7XG4iLCJleHBvcnQgKiBmcm9tIFwiLi9zdGFnZ2VyLmFuaW1hdGlvblwiO1xuZXhwb3J0ICogZnJvbSBcIi4vZmFkZS5hbmltYXRpb25cIjtcbmV4cG9ydCAqIGZyb20gXCIuL3NsaWRlLmFuaW1hdGlvblwiO1xuIiwiaW1wb3J0IHsgdHJhbnNpdGlvbiwgc3R5bGUsIGFuaW1hdGUsIHRyaWdnZXIgfSBmcm9tIFwiQGFuZ3VsYXIvYW5pbWF0aW9uc1wiO1xuZXhwb3J0IGNvbnN0IFNsaWRlVXAgPSB0cmlnZ2VyKFwic2xpZGVVcFwiLCBbXG4gICAgdHJhbnNpdGlvbihcIjplbnRlclwiLCBbXG4gICAgICAgIHN0eWxlKHsgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZSgwLCAxMDApXCIgfSksXG4gICAgICAgIGFuaW1hdGUoXCIzMDBtcyBlYXNlLWluLW91dFwiLCBzdHlsZSh7IHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMCwwKVwiIH0pKSxcbiAgICBdKSxcbiAgICB0cmFuc2l0aW9uKFwiOmxlYXZlXCIsIFtcbiAgICAgICAgc3R5bGUoeyB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDAsMClcIiB9KSxcbiAgICAgICAgYW5pbWF0ZShcIjMwMG1zIGN1YmljLWJlemllcigwLjE3LCAwLjg5LCAwLjI0LCAxLjExKVwiLCBzdHlsZSh7IHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMCwgMzAwKVwiIH0pKSxcbiAgICBdKSxcbl0pO1xuIiwiaW1wb3J0IHsgdHJhbnNpdGlvbiwgc3R5bGUsIGFuaW1hdGUsIHRyaWdnZXIsIHN0YWdnZXIsIHF1ZXJ5LCB9IGZyb20gXCJAYW5ndWxhci9hbmltYXRpb25zXCI7XG5leHBvcnQgY29uc3QgU2xpZGVVcEZhZGVTdGFnZ2VyID0gdHJpZ2dlcihcInNsaWRlVXBGYWRlU3RhZ2dlclwiLCBbXG4gICAgdHJhbnNpdGlvbihcIjplbnRlclwiLCBbXG4gICAgICAgIHF1ZXJ5KFwiOmVudGVyXCIsIFtcbiAgICAgICAgICAgIHN0eWxlKHsgb3BhY2l0eTogMCwgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZSgwLCA0MClcIiB9KSxcbiAgICAgICAgICAgIHN0YWdnZXIoXCI1MG1zXCIsIFtcbiAgICAgICAgICAgICAgICBhbmltYXRlKFwiMzAwbXMgMzAwbXNcIiwgc3R5bGUoeyBvcGFjaXR5OiAxLCB0cmFuc2Zvcm06IFwidHJhbmxzYXRlKDAsIDApXCIgfSkpLFxuICAgICAgICAgICAgXSksXG4gICAgICAgIF0sIHsgb3B0aW9uYWw6IHRydWUgfSksXG4gICAgXSksXG4gICAgdHJhbnNpdGlvbihcIjpsZWF2ZVwiLCBbXG4gICAgICAgIHF1ZXJ5KFwiOmxlYXZlXCIsIFtcbiAgICAgICAgICAgIHN0YWdnZXIoXCI1MG1zXCIsIFtcbiAgICAgICAgICAgICAgICBhbmltYXRlKFwiMzAwbXNcIiwgc3R5bGUoeyBvcGFjaXR5OiAwLCB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDAsIDQwKVwiIH0pKSxcbiAgICAgICAgICAgIF0pLFxuICAgICAgICBdLCB7IG9wdGlvbmFsOiB0cnVlIH0pLFxuICAgIF0pLFxuXSk7XG4iLCJleHBvcnQgKiBmcm9tIFwiLi9hbmltYXRpb25zXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9tb2RlbHNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3NlcnZpY2VzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9zdGF0ZVwiO1xuIiwiZXhwb3J0IGNvbnN0IEFwaVJvdXRlcyA9IHtcbiAgICBwcm9kdWN0R3JvdXBzOiBcIi9wcm9kdWN0LWdyb3Vwcy5qc29uXCIsXG4gICAgY2F0ZWdvcmllczogXCIvY2F0ZWdvcmllcy5qc29uXCIsXG4gICAgc3RhdGljVGV4dDogXCIvc3RhdGljLXRleHQuanNvblwiLFxufTtcbiIsImV4cG9ydCBjb25zdCBJY29ucyA9IHtcbiAgICBoZWFydDogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYzMmUpLFxuICAgIGhlYXJ0T3V0bGluZTogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYzM2IpLFxuICAgIHBsYXk6IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmNDcyKSxcbiAgICBiYWNrOiBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZjIwOCksXG4gICAgc3RhcjogU3RyaW5nLmZyb21DaGFyQ29kZSgweGY1MzUpLFxuICAgIG1lbnU6IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmM2ZkKSxcbiAgICBjbG9zZTogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYyMjMpLFxuICAgIGhvbWU6IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmMzQ2KSxcbiAgICBhY2NvdW50OiBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZjQ1MSksXG4gICAgZG93bmxvYWRzOiBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZjI4OSksXG4gICAgc2V0dGluZ3M6IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmMWEyKSxcbiAgICBub3RpZmljYXRpb25zOiBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZjQyMSksXG4gICAgaGVscDogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYxOGQpLFxuICAgIGluZm86IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmMzVhKSxcbiAgICBzaGFyZTogU3RyaW5nLmZyb21DaGFyQ29kZSgweGY1MWEpLFxuICAgIGZpbHRlcjogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYyZjUpLFxuICAgIHNlYXJjaDogU3RyaW5nLmZyb21DaGFyQ29kZSgweGY1MDUpLFxuICAgIGNoZWNrOiBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZjIwNyksXG4gICAgY29tbWVudDogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYxZWMpLFxuICAgIHdhcm46IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmNWJhKSxcbiAgICBmaWxtT3V0bGluZTogU3RyaW5nLmZyb21DaGFyQ29kZSgweGYyY2MpLFxuICAgIGVkaXQ6IFN0cmluZy5mcm9tQ2hhckNvZGUoMHhmNDQ4KSxcbiAgICBzYXZlOiBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZjRmYSksXG59O1xuIiwiZXhwb3J0ICogZnJvbSBcIi4vYXBpLXJvdXRlc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vaWNvbnNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3JvdXRlc1wiO1xuIiwiZXhwb3J0IGNvbnN0IFJvdXRlcyA9IHtcbiAgICBob21lOiBcIi9ob21lXCIsXG4gICAgZGV0YWlsczogXCIvZGV0YWlscy86aWRcIixcbiAgICBwcm9maWxlOiBcIi9wcm9maWxlXCIsXG4gICAgY29uZmlnOiBcIi9jb25maWdcIixcbn07XG4iLCJleHBvcnQgKiBmcm9tIFwiLi9jb25zdGFudHNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2ludGVyZmFjZXNcIjtcbiIsImV4cG9ydCB7fTtcbiIsImV4cG9ydCAqIGZyb20gXCIuL2NhdGVnb3J5LmludGVyZmFjZVwiO1xuZXhwb3J0ICogZnJvbSBcIi4vcHJvZHVjdC5pbnRlcmZhY2VcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3Byb2R1Y3QtZ3JvdXAuaW50ZXJmYWNlXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9yZW1vdGUtc3R5bGVzLmludGVyZmFjZVwiO1xuZXhwb3J0ICogZnJvbSBcIi4vcHJvZmlsZS5pbnRlcmZhY2VcIjtcbiIsImV4cG9ydCB7fTtcbiIsImV4cG9ydCB7fTtcbiIsImV4cG9ydCB7fTtcbiIsImV4cG9ydCB7fTtcbiIsImltcG9ydCB7IEh0dHBDbGllbnQgfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uL2h0dHBcIjtcbmltcG9ydCB7IG1hcCB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuaW1wb3J0IHsgQXBpUm91dGVzIH0gZnJvbSBcIi4uL21vZGVscy9jb25zdGFudHMvYXBpLXJvdXRlc1wiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAYW5ndWxhci9jb21tb24vaHR0cFwiO1xuZXhwb3J0IGNsYXNzIEFwaVNlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKGh0dHApIHtcbiAgICAgICAgdGhpcy5odHRwID0gaHR0cDtcbiAgICB9XG4gICAgZ2V0UHJvZHVjdEdyb3VwcyQoYmFzZVVybCkge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0KHRoaXMuX2Zvcm1hdFVybChiYXNlVXJsLCBBcGlSb3V0ZXMucHJvZHVjdEdyb3VwcykpXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlcykgPT4gcmVzLnByb2R1Y3RHcm91cHMpKTtcbiAgICB9XG4gICAgZ2V0Q2F0ZWdvcmllcyQoYmFzZVVybCkge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0KHRoaXMuX2Zvcm1hdFVybChiYXNlVXJsLCBBcGlSb3V0ZXMuY2F0ZWdvcmllcykpXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlcykgPT4gcmVzLmNhdGVnb3JpZXMpKTtcbiAgICB9XG4gICAgZ2V0U3RhdGljVGV4dCQoYmFzZVVybCkge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0KHRoaXMuX2Zvcm1hdFVybChiYXNlVXJsLCBBcGlSb3V0ZXMuc3RhdGljVGV4dCkpXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlcykgPT4gcmVzLnN0YXRpY1RleHQpKTtcbiAgICB9XG4gICAgZ2V0UmVtb3RlU3R5bGVzJChzdHlsZVVybCkge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwLmdldChzdHlsZVVybCwge1xuICAgICAgICAgICAgcmVzcG9uc2VUeXBlOiBcInRleHRcIixcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGdldFJlbW90ZVN0eWxlc09wdGlvbnMkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAgICAgICAuZ2V0KFwiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3dpbGxpYW1qdWFuMDI3L21vdmllcy1hcHAtYXBpL21haW4vc3R5bGVzL3N0eWxlcy5qc29uXCIsIHtcbiAgICAgICAgICAgIHJlc3BvbnNlVHlwZTogXCJqc29uXCIsXG4gICAgICAgIH0pXG4gICAgICAgICAgICAucGlwZShtYXAoKHJlcykgPT4gcmVzID09PSBudWxsIHx8IHJlcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogcmVzLnN0eWxlcykpO1xuICAgIH1cbiAgICBfZm9ybWF0VXJsKGJhc2VVcmwsIGV4dGVuc2lvbikge1xuICAgICAgICBpZiAoYmFzZVVybC5lbmRzV2l0aChcIi9cIikpIHtcbiAgICAgICAgICAgIHJldHVybiBgJHtiYXNlVXJsfSR7ZXh0ZW5zaW9ufWAudHJpbSgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHtiYXNlVXJsfS8ke2V4dGVuc2lvbn1gLnRyaW0oKTtcbiAgICB9XG59XG5BcGlTZXJ2aWNlLsm1ZmFjID0gZnVuY3Rpb24gQXBpU2VydmljZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBBcGlTZXJ2aWNlKShpMC7Jtcm1aW5qZWN0KGkxLkh0dHBDbGllbnQpKTsgfTtcbkFwaVNlcnZpY2UuybVwcm92ID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lSW5qZWN0YWJsZSh7IHRva2VuOiBBcGlTZXJ2aWNlLCBmYWN0b3J5OiBBcGlTZXJ2aWNlLsm1ZmFjLCBwcm92aWRlZEluOiBcInJvb3RcIiB9KTtcbiIsImltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5leHBvcnQgY2xhc3MgRGF0YVNlcnZpY2Uge1xufVxuRGF0YVNlcnZpY2UuybVmYWMgPSBmdW5jdGlvbiBEYXRhU2VydmljZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBEYXRhU2VydmljZSkoKTsgfTtcbkRhdGFTZXJ2aWNlLsm1cHJvdiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdGFibGUoeyB0b2tlbjogRGF0YVNlcnZpY2UsIGZhY3Rvcnk6IERhdGFTZXJ2aWNlLsm1ZmFjLCBwcm92aWRlZEluOiBcInJvb3RcIiB9KTtcbiIsImV4cG9ydCAqIGZyb20gXCIuL2FwaS5zZXJ2aWNlXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9kYXRhLnNlcnZpY2VcIjtcbmV4cG9ydCAqIGZyb20gXCIuL25hdmlnYXRpb24uc2VydmljZVwiO1xuZXhwb3J0ICogZnJvbSBcIi4vdWlcIjtcbiIsImltcG9ydCB7IFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0ICogYXMgaTEgZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuZXhwb3J0IGNsYXNzIE5hdmlnYXRpb25TZXJ2aWNlIHtcbiAgICBjb25zdHJ1Y3Rvcihyb3V0ZXJFeHRlbnNpb25zKSB7XG4gICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucyA9IHJvdXRlckV4dGVuc2lvbnM7XG4gICAgfVxuICAgIG5hdmlnYXRlKHBhdGgsIHBhcmFtcyA9IG51bGwsIGNsZWFySGlzdG9yeSA9IGZhbHNlKSB7XG4gICAgICAgIGNvbnN0IHJvdXRlQXJyYXkgPSBbcGF0aF07XG4gICAgICAgIGlmIChwYXJhbXMpIHtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHBhcmFtcykpIHtcbiAgICAgICAgICAgICAgICByb3V0ZUFycmF5LnB1c2goLi4ucGFyYW1zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJvdXRlQXJyYXkucHVzaChwYXJhbXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShyb3V0ZUFycmF5LCB7IGNsZWFySGlzdG9yeTogY2xlYXJIaXN0b3J5IH0pO1xuICAgIH1cbiAgICBiYWNrKCkge1xuICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMuYmFjaygpO1xuICAgIH1cbn1cbk5hdmlnYXRpb25TZXJ2aWNlLsm1ZmFjID0gZnVuY3Rpb24gTmF2aWdhdGlvblNlcnZpY2VfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgTmF2aWdhdGlvblNlcnZpY2UpKGkwLsm1ybVpbmplY3QoaTEuUm91dGVyRXh0ZW5zaW9ucykpOyB9O1xuTmF2aWdhdGlvblNlcnZpY2UuybVwcm92ID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lSW5qZWN0YWJsZSh7IHRva2VuOiBOYXZpZ2F0aW9uU2VydmljZSwgZmFjdG9yeTogTmF2aWdhdGlvblNlcnZpY2UuybVmYWMsIHByb3ZpZGVkSW46IFwicm9vdFwiIH0pO1xuIiwiZXhwb3J0ICogZnJvbSBcIi4vbGF5ZXJzLnNlcnZpY2VcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3N0bHlpbmcuc2VydmljZVwiO1xuZXhwb3J0ICogZnJvbSAnLi9qcy1hbmltYXRpb24uc2VydmljZSc7XG4iLCJpbXBvcnQgeyBOZ1pvbmUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgYW5pbWF0ZSBhcyBwb3Btb3Rpb25BbmltYXRlIH0gZnJvbSBcInBvcG1vdGlvblwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmV4cG9ydCBjbGFzcyBKc0FuaW1hdGlvblNlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKHpvbmUpIHtcbiAgICAgICAgdGhpcy56b25lID0gem9uZTtcbiAgICB9XG4gICAgYW5pbWF0ZVdpdGhQb3Btb3Rpb24oZnJvbSwgdG8sIG9uVXBkYXRlLCBkdXJhdGlvbikge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuem9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB7XG4gICAgICAgICAgICAgICAgcG9wbW90aW9uQW5pbWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgIGZyb206IGZyb20sXG4gICAgICAgICAgICAgICAgICAgIHRvOiB0byxcbiAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IGR1cmF0aW9uLFxuICAgICAgICAgICAgICAgICAgICBvblVwZGF0ZTogKGxhdGVzdCkgPT4gb25VcGRhdGUobGF0ZXN0KSxcbiAgICAgICAgICAgICAgICAgICAgb25Db21wbGV0ZTogKCkgPT4gcmVzb2x2ZSgpLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBhbmltYXRlU3ByaW5nV2l0aFBvcG1vdGlvbihmcm9tLCB0bywgb25VcGRhdGUsIGR1cmF0aW9uLCBkYW1waW5nID0gMTAsIHN0aWZmbmVzcyA9IDcwMCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgIHRoaXMuem9uZS5ydW5PdXRzaWRlQW5ndWxhcigoKSA9PiB7XG4gICAgICAgICAgICAgICAgcG9wbW90aW9uQW5pbWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgIGZyb206IGZyb20sXG4gICAgICAgICAgICAgICAgICAgIHRvOiB0byxcbiAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IGR1cmF0aW9uLFxuICAgICAgICAgICAgICAgICAgICBkYW1waW5nOiBkYW1waW5nLFxuICAgICAgICAgICAgICAgICAgICBzdGlmZm5lc3M6IHN0aWZmbmVzcyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJzcHJpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgb25VcGRhdGU6IChsYXRlc3QpID0+IG9uVXBkYXRlKGxhdGVzdCksXG4gICAgICAgICAgICAgICAgICAgIG9uQ29tcGxldGU6ICgpID0+IHJlc29sdmUoKSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgYW5pbWF0ZVN0cmV0Y2godmlldykge1xuICAgICAgICByZXR1cm4gdGhpcy5hbmltYXRlV2l0aFBvcG1vdGlvbihcIjEsMVwiLCBcIjEuMiwwLjhcIiwgKGxhdGVzdCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgW3NjYWxlWCwgc2NhbGVZXSA9IGxhdGVzdC5zcGxpdChcIixcIikubWFwKCh2YWwpID0+ICt2YWwpO1xuICAgICAgICAgICAgdmlldy5zY2FsZVggPSBzY2FsZVg7XG4gICAgICAgICAgICB2aWV3LnNjYWxlWSA9IHNjYWxlWTtcbiAgICAgICAgfSwgMjAwKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYW5pbWF0ZVNwcmluZ1dpdGhQb3Btb3Rpb24oXCIxLjIsMC44XCIsIFwiMSwxXCIsIChsYXRlc3QpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBbc2NhbGVYLCBzY2FsZVldID0gbGF0ZXN0LnNwbGl0KFwiLFwiKS5tYXAoKHZhbCkgPT4gK3ZhbCk7XG4gICAgICAgICAgICAgICAgdmlldy5zY2FsZVggPSBzY2FsZVg7XG4gICAgICAgICAgICAgICAgdmlldy5zY2FsZVkgPSBzY2FsZVk7XG4gICAgICAgICAgICB9LCAxMDAwKTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuSnNBbmltYXRpb25TZXJ2aWNlLsm1ZmFjID0gZnVuY3Rpb24gSnNBbmltYXRpb25TZXJ2aWNlX0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IEpzQW5pbWF0aW9uU2VydmljZSkoaTAuybXJtWluamVjdChpMC5OZ1pvbmUpKTsgfTtcbkpzQW5pbWF0aW9uU2VydmljZS7JtXByb3YgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHsgdG9rZW46IEpzQW5pbWF0aW9uU2VydmljZSwgZmFjdG9yeTogSnNBbmltYXRpb25TZXJ2aWNlLsm1ZmFjLCBwcm92aWRlZEluOiBcInJvb3RcIiB9KTtcbiIsImltcG9ydCB7IENvbXBvbmVudEZhY3RvcnlSZXNvbHZlciwgSW5qZWN0b3IsIE5nWm9uZSwgQXBwbGljYXRpb25SZWYsIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IGdldFJvb3RMYXlvdXQsIENvcmVUeXBlcywgUHJveHlWaWV3Q29udGFpbmVyLCBEaWFsb2dzLCB9IGZyb20gXCJAbmF0aXZlc2NyaXB0L2NvcmVcIjtcbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gXCJyeGpzXCI7XG5pbXBvcnQgeyBGaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudCwgUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnQsIFNlYXJjaEJvdHRvbXNoZWV0Q29tcG9uZW50LCB9IGZyb20gXCJ+L3NoYXJlZFwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmV4cG9ydCBjb25zdCBERUZBVUxUX0FOSU1BVElPTl9DVVJWRSA9IENvcmVUeXBlcy5BbmltYXRpb25DdXJ2ZS5jdWJpY0JlemllcigwLjE3LCAwLjg5LCAwLjI0LCAxLjExKTtcbmV4cG9ydCBjbGFzcyBMYXllcnNTZXJ2aWNlIHtcbiAgICBjb25zdHJ1Y3Rvcih6b25lLCBpbmplY3RvciwgY29tcG9uZW50RmFjdG9yeVJlc29sdmVyLCBhcHBsaWNhdGlvblJlZikge1xuICAgICAgICB0aGlzLnpvbmUgPSB6b25lO1xuICAgICAgICB0aGlzLmluamVjdG9yID0gaW5qZWN0b3I7XG4gICAgICAgIHRoaXMuY29tcG9uZW50RmFjdG9yeVJlc29sdmVyID0gY29tcG9uZW50RmFjdG9yeVJlc29sdmVyO1xuICAgICAgICB0aGlzLmFwcGxpY2F0aW9uUmVmID0gYXBwbGljYXRpb25SZWY7XG4gICAgICAgIHRoaXMuX2xheWVycyQgPSBuZXcgQmVoYXZpb3JTdWJqZWN0KHtcbiAgICAgICAgICAgIG1lbnU6IHtcbiAgICAgICAgICAgICAgICBpc09wZW46IGZhbHNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGFsZXJ0UG9wdXA6IHtcbiAgICAgICAgICAgICAgICBpc09wZW46IGZhbHNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHF1aWNrdmlld0JvdHRvbXNoZWV0OiB7XG4gICAgICAgICAgICAgICAgdmlldzogbnVsbCxcbiAgICAgICAgICAgICAgICBpc0FuaW1hdGluZzogZmFsc2UsXG4gICAgICAgICAgICAgICAgcHJvZHVjdElkOiB1bmRlZmluZWQsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2VhcmNoQm90dG9tc2hlZXQ6IHtcbiAgICAgICAgICAgICAgICB2aWV3OiBudWxsLFxuICAgICAgICAgICAgICAgIGlzQW5pbWF0aW5nOiBmYWxzZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmaWx0ZXJCb3R0b21zaGVldDoge1xuICAgICAgICAgICAgICAgIHZpZXc6IG51bGwsXG4gICAgICAgICAgICAgICAgaXNBbmltYXRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGdldExheWVycyQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9sYXllcnMkLmFzT2JzZXJ2YWJsZSgpO1xuICAgIH1cbiAgICBvcGVuTWVudSgpIHtcbiAgICAgICAgRGlhbG9ncy5jb25maXJtKFwiRG8geW91IHdhbnQgb3BlbiBtZW51P1wiKS50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRGlhbG9nIHJlc3VsdDogXCIgKyByZXN1bHQpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgY2xvc2VNZW51KCkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkNsb3NlIG1lbnUgdGFwcGVkXCIpO1xuICAgIH1cbiAgICBvcGVuQWxlcnRQb3B1cCgpIHtcbiAgICAgICAgdGhpcy5fbGF5ZXJzJC5uZXh0KE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKSksIHsgYWxlcnRQb3B1cDoge1xuICAgICAgICAgICAgICAgIGlzT3BlbjogdHJ1ZSxcbiAgICAgICAgICAgIH0gfSkpO1xuICAgIH1cbiAgICBjbG9zZUFsZXJ0UG9wdXAoKSB7XG4gICAgICAgIHRoaXMuX2xheWVycyQubmV4dChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0TGF5ZXJzQ3VycmVudFZhbHVlKCkpLCB7IGFsZXJ0UG9wdXA6IHtcbiAgICAgICAgICAgICAgICBpc09wZW46IGZhbHNlLFxuICAgICAgICAgICAgfSB9KSk7XG4gICAgfVxuICAgIC8vIFF1aWNrdmlldyBCb3R0b21zaGVldCAtLS0tLS0tLS0tXG4gICAgb3BlblF1aWNrdmlld0JvdHRvbXNoZWV0KHByb2R1Y3RJZCkge1xuICAgICAgICB0aGlzLl9nZXRWaWV3KFF1aWNrdmlld0JvdHRvbXNoZWV0Q29tcG9uZW50KS50aGVuKChxdWlja3ZpZXdCb3R0b21zaGVldCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5fbGF5ZXJzJC5uZXh0KE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKSksIHsgcXVpY2t2aWV3Qm90dG9tc2hlZXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgdmlldzogcXVpY2t2aWV3Qm90dG9tc2hlZXQsXG4gICAgICAgICAgICAgICAgICAgIGlzQW5pbWF0aW5nOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgICAgICAgICB9IH0pKTtcbiAgICAgICAgICAgIGdldFJvb3RMYXlvdXQoKVxuICAgICAgICAgICAgICAgIC5vcGVuKHF1aWNrdmlld0JvdHRvbXNoZWV0LCB7XG4gICAgICAgICAgICAgICAgc2hhZGVDb3Zlcjoge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjMDAwXCIsXG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuNSxcbiAgICAgICAgICAgICAgICAgICAgdGFwVG9DbG9zZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICBlbnRlckZyb206IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zbGF0ZVk6IDUwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAyNTAsXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJ2ZTogREVGQVVMVF9BTklNQVRJT05fQ1VSVkUsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGV4aXRUbzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNsYXRlWTogNTAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IDI1MCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnZlOiBERUZBVUxUX0FOSU1BVElPTl9DVVJWRSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5fbGF5ZXJzJC5uZXh0KE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKSksIHsgcXVpY2t2aWV3Qm90dG9tc2hlZXQ6IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKS5xdWlja3ZpZXdCb3R0b21zaGVldCksIHsgaXNBbmltYXRpbmc6IGZhbHNlIH0pIH0pKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgY2xvc2VRdWlja3ZpZXdCb3R0b21zaGVldCgpIHtcbiAgICAgICAgY29uc3QgcXVpY2tWaWV3Qm90dG9tc2hlZXQgPSB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpXG4gICAgICAgICAgICAucXVpY2t2aWV3Qm90dG9tc2hlZXQudmlldztcbiAgICAgICAgaWYgKHF1aWNrVmlld0JvdHRvbXNoZWV0KSB7XG4gICAgICAgICAgICB0aGlzLl9sYXllcnMkLm5leHQoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpKSwgeyBxdWlja3ZpZXdCb3R0b21zaGVldDogT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpLnF1aWNrdmlld0JvdHRvbXNoZWV0KSwgeyBpc0FuaW1hdGluZzogdHJ1ZSB9KSB9KSk7XG4gICAgICAgICAgICBnZXRSb290TGF5b3V0KClcbiAgICAgICAgICAgICAgICAuY2xvc2UocXVpY2tWaWV3Qm90dG9tc2hlZXQpXG4gICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuX2xheWVycyQubmV4dChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0TGF5ZXJzQ3VycmVudFZhbHVlKCkpLCB7IHF1aWNrdmlld0JvdHRvbXNoZWV0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNBbmltYXRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvZHVjdElkOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgIH0gfSkpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gU2VhcmNoIEJvdHRvbXNoZWV0IC0tLS0tLS0tLS1cbiAgICBvcGVuU2VhcmNoQm90dG9tc2hlZXQoKSB7XG4gICAgICAgIHRoaXMuX2dldFZpZXcoU2VhcmNoQm90dG9tc2hlZXRDb21wb25lbnQpLnRoZW4oKHNlYXJjaEJvdHRvbXNoZWV0KSA9PiB7XG4gICAgICAgICAgICB0aGlzLl9sYXllcnMkLm5leHQoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpKSwgeyBzZWFyY2hCb3R0b21zaGVldDoge1xuICAgICAgICAgICAgICAgICAgICB2aWV3OiBzZWFyY2hCb3R0b21zaGVldCxcbiAgICAgICAgICAgICAgICAgICAgaXNBbmltYXRpbmc6IHRydWUsXG4gICAgICAgICAgICAgICAgfSB9KSk7XG4gICAgICAgICAgICBnZXRSb290TGF5b3V0KClcbiAgICAgICAgICAgICAgICAub3BlbihzZWFyY2hCb3R0b21zaGVldCwge1xuICAgICAgICAgICAgICAgIHNoYWRlQ292ZXI6IHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwiIzAwMFwiLFxuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjUsXG4gICAgICAgICAgICAgICAgICAgIHRhcFRvQ2xvc2U6IHRydWUsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBhbmltYXRpb246IHtcbiAgICAgICAgICAgICAgICAgICAgZW50ZXJGcm9tOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2xhdGVZOiA4MDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBkdXJhdGlvbjogMjUwLFxuICAgICAgICAgICAgICAgICAgICAgICAgY3VydmU6IERFRkFVTFRfQU5JTUFUSU9OX0NVUlZFLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBleGl0VG86IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zbGF0ZVk6IDgwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAyNTAsXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJ2ZTogREVGQVVMVF9BTklNQVRJT05fQ1VSVkUsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuX2xheWVycyQubmV4dChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0TGF5ZXJzQ3VycmVudFZhbHVlKCkpLCB7IHNlYXJjaEJvdHRvbXNoZWV0OiBPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0TGF5ZXJzQ3VycmVudFZhbHVlKCkuc2VhcmNoQm90dG9tc2hlZXQpLCB7IGlzQW5pbWF0aW5nOiBmYWxzZSB9KSB9KSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNsb3NlU2VhcmNoQm90dG9tc2hlZXQoKSB7XG4gICAgICAgIGNvbnN0IHNlYXJjaEJvdHRvbXNoZWV0ID0gdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKS5zZWFyY2hCb3R0b21zaGVldFxuICAgICAgICAgICAgLnZpZXc7XG4gICAgICAgIGlmIChzZWFyY2hCb3R0b21zaGVldCkge1xuICAgICAgICAgICAgdGhpcy5fbGF5ZXJzJC5uZXh0KE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKSksIHsgc2VhcmNoQm90dG9tc2hlZXQ6IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKS5zZWFyY2hCb3R0b21zaGVldCksIHsgaXNBbmltYXRpbmc6IHRydWUgfSkgfSkpO1xuICAgICAgICAgICAgZ2V0Um9vdExheW91dCgpXG4gICAgICAgICAgICAgICAgLmNsb3NlKHNlYXJjaEJvdHRvbXNoZWV0KVxuICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLl9sYXllcnMkLm5leHQoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpKSwgeyBzZWFyY2hCb3R0b21zaGVldDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmlldzogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzQW5pbWF0aW5nOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgfSB9KSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBGaWx0ZXIgQm90dG9tc2hlZXQgLS0tLS0tLS0tLVxuICAgIG9wZW5GaWx0ZXJCb3R0b21zaGVldCgpIHtcbiAgICAgICAgdGhpcy5fZ2V0VmlldyhGaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudCkudGhlbigoZmlsdGVyQm90dG9tc2hlZXQpID0+IHtcbiAgICAgICAgICAgIHRoaXMuX2xheWVycyQubmV4dChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0TGF5ZXJzQ3VycmVudFZhbHVlKCkpLCB7IGZpbHRlckJvdHRvbXNoZWV0OiB7XG4gICAgICAgICAgICAgICAgICAgIHZpZXc6IGZpbHRlckJvdHRvbXNoZWV0LFxuICAgICAgICAgICAgICAgICAgICBpc0FuaW1hdGluZzogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9IH0pKTtcbiAgICAgICAgICAgIGdldFJvb3RMYXlvdXQoKVxuICAgICAgICAgICAgICAgIC5vcGVuKGZpbHRlckJvdHRvbXNoZWV0LCB7XG4gICAgICAgICAgICAgICAgc2hhZGVDb3Zlcjoge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogXCIjMDAwXCIsXG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuNSxcbiAgICAgICAgICAgICAgICAgICAgdGFwVG9DbG9zZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbjoge1xuICAgICAgICAgICAgICAgICAgICBlbnRlckZyb206IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zbGF0ZVk6IDUwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAyNTAsXG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJ2ZTogREVGQVVMVF9BTklNQVRJT05fQ1VSVkUsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIGV4aXRUbzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNsYXRlWTogNTAwLFxuICAgICAgICAgICAgICAgICAgICAgICAgZHVyYXRpb246IDI1MCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnZlOiBERUZBVUxUX0FOSU1BVElPTl9DVVJWRSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5fbGF5ZXJzJC5uZXh0KE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKSksIHsgZmlsdGVyQm90dG9tc2hlZXQ6IE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5nZXRMYXllcnNDdXJyZW50VmFsdWUoKS5maWx0ZXJCb3R0b21zaGVldCksIHsgaXNBbmltYXRpbmc6IGZhbHNlIH0pIH0pKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgY2xvc2VGaWx0ZXJCb3R0b21zaGVldCgpIHtcbiAgICAgICAgY29uc3QgZmlsdGVyQm90dG9tc2hlZXQgPSB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpLmZpbHRlckJvdHRvbXNoZWV0XG4gICAgICAgICAgICAudmlldztcbiAgICAgICAgaWYgKGZpbHRlckJvdHRvbXNoZWV0KSB7XG4gICAgICAgICAgICB0aGlzLl9sYXllcnMkLm5leHQoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpKSwgeyBmaWx0ZXJCb3R0b21zaGVldDogT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCB0aGlzLmdldExheWVyc0N1cnJlbnRWYWx1ZSgpLmZpbHRlckJvdHRvbXNoZWV0KSwgeyBpc0FuaW1hdGluZzogdHJ1ZSB9KSB9KSk7XG4gICAgICAgICAgICBnZXRSb290TGF5b3V0KClcbiAgICAgICAgICAgICAgICAuY2xvc2UoZmlsdGVyQm90dG9tc2hlZXQpXG4gICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuX2xheWVycyQubmV4dChPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHRoaXMuZ2V0TGF5ZXJzQ3VycmVudFZhbHVlKCkpLCB7IGZpbHRlckJvdHRvbXNoZWV0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2aWV3OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXNBbmltYXRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB9IH0pKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGdldExheWVyc0N1cnJlbnRWYWx1ZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2xheWVycyQudmFsdWU7XG4gICAgfVxuICAgIF9nZXRWaWV3KGNvbXBvbmVudCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvbXBvbmVudEZhY3RvcnkgPSB0aGlzLmNvbXBvbmVudEZhY3RvcnlSZXNvbHZlci5yZXNvbHZlQ29tcG9uZW50RmFjdG9yeShjb21wb25lbnQpO1xuICAgICAgICAgICAgdGhpcy56b25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgY29tcG9uZW50UmVmID0gY29tcG9uZW50RmFjdG9yeS5jcmVhdGUodGhpcy5pbmplY3Rvcik7XG4gICAgICAgICAgICAgICAgbGV0IGNvbXBvbmVudFZpZXcgPSBjb21wb25lbnRSZWYubG9jYXRpb24ubmF0aXZlRWxlbWVudDtcbiAgICAgICAgICAgICAgICBpZiAoY29tcG9uZW50VmlldyBpbnN0YW5jZW9mIFByb3h5Vmlld0NvbnRhaW5lcikge1xuICAgICAgICAgICAgICAgICAgICBjb21wb25lbnRWaWV3ID0gY29tcG9uZW50Vmlldy5nZXRDaGlsZEF0KDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoY29tcG9uZW50Vmlldy5wYXJlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50Vmlldy5wYXJlbnQucmVtb3ZlQ2hpbGQoY29tcG9uZW50Vmlldyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbXBvbmVudFZpZXcuX19uZ1JlZiA9IGNvbXBvbmVudFJlZjtcbiAgICAgICAgICAgICAgICB0aGlzLmFwcGxpY2F0aW9uUmVmLmF0dGFjaFZpZXcoY29tcG9uZW50UmVmLmhvc3RWaWV3KTtcbiAgICAgICAgICAgICAgICBjb21wb25lbnRSZWYuY2hhbmdlRGV0ZWN0b3JSZWYuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoY29tcG9uZW50Vmlldyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuTGF5ZXJzU2VydmljZS7JtWZhYyA9IGZ1bmN0aW9uIExheWVyc1NlcnZpY2VfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgTGF5ZXJzU2VydmljZSkoaTAuybXJtWluamVjdChpMC5OZ1pvbmUpLCBpMC7Jtcm1aW5qZWN0KGkwLkluamVjdG9yKSwgaTAuybXJtWluamVjdChpMC5Db21wb25lbnRGYWN0b3J5UmVzb2x2ZXIpLCBpMC7Jtcm1aW5qZWN0KGkwLkFwcGxpY2F0aW9uUmVmKSk7IH07XG5MYXllcnNTZXJ2aWNlLsm1cHJvdiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdGFibGUoeyB0b2tlbjogTGF5ZXJzU2VydmljZSwgZmFjdG9yeTogTGF5ZXJzU2VydmljZS7JtWZhYywgcHJvdmlkZWRJbjogXCJyb290XCIgfSk7XG4iLCJpbXBvcnQgeyBBcHBsaWNhdGlvbiB9IGZyb20gXCJAbmF0aXZlc2NyaXB0L2NvcmVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5leHBvcnQgY2xhc3MgU3R5bGluZ1NlcnZpY2Uge1xuICAgIGNvbnN0cnVjdG9yKCkgeyB9XG4gICAgdXBkYXRlQXBwQ1NTKHN0eWxlcykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc2FuaXRpemVkU3R5bGVzID0gc3R5bGVzLnJlcGxhY2UoLyhcXHJcXG58XFxufFxccikvZ20sIFwiXCIpO1xuICAgICAgICAgICAgQXBwbGljYXRpb24uYWRkQ3NzKHNhbml0aXplZFN0eWxlcyk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciB1cGRhdGluZyBhcHAgY3NzXCIpO1xuICAgICAgICB9XG4gICAgfVxufVxuU3R5bGluZ1NlcnZpY2UuybVmYWMgPSBmdW5jdGlvbiBTdHlsaW5nU2VydmljZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBTdHlsaW5nU2VydmljZSkoKTsgfTtcblN0eWxpbmdTZXJ2aWNlLsm1cHJvdiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdGFibGUoeyB0b2tlbjogU3R5bGluZ1NlcnZpY2UsIGZhY3Rvcnk6IFN0eWxpbmdTZXJ2aWNlLsm1ZmFjLCBwcm92aWRlZEluOiBcInJvb3RcIiB9KTtcbiIsImV4cG9ydCB2YXIgQ29uZmlnO1xuKGZ1bmN0aW9uIChDb25maWcpIHtcbiAgICBjbGFzcyBVcGRhdGVEYXRhVXJsIHtcbiAgICAgICAgY29uc3RydWN0b3IodXJsKSB7XG4gICAgICAgICAgICB0aGlzLnVybCA9IHVybDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBVcGRhdGVEYXRhVXJsLnR5cGUgPSBcIltDb25maWddIFVwZGF0ZSBEYXRhIFVSTFwiO1xuICAgIENvbmZpZy5VcGRhdGVEYXRhVXJsID0gVXBkYXRlRGF0YVVybDtcbiAgICBjbGFzcyBVcGRhdGVTdHlsaW5nVXJsIHtcbiAgICAgICAgY29uc3RydWN0b3IodXJsKSB7XG4gICAgICAgICAgICB0aGlzLnVybCA9IHVybDtcbiAgICAgICAgfVxuICAgIH1cbiAgICBVcGRhdGVTdHlsaW5nVXJsLnR5cGUgPSBcIltDb25maWddIFVwZGF0ZSBTdHlsaW5nIFVSTFwiO1xuICAgIENvbmZpZy5VcGRhdGVTdHlsaW5nVXJsID0gVXBkYXRlU3R5bGluZ1VybDtcbiAgICBjbGFzcyBVcGRhdGVTdHlsZU9wdGlvbnMge1xuICAgIH1cbiAgICBVcGRhdGVTdHlsZU9wdGlvbnMudHlwZSA9IFwiW0NvbmZpZ10gVXBkYXRlIFN0eWxlIE9wdGlvbnNcIjtcbiAgICBDb25maWcuVXBkYXRlU3R5bGVPcHRpb25zID0gVXBkYXRlU3R5bGVPcHRpb25zO1xuICAgIGNsYXNzIFVwZGF0ZVN0YXRpY1RleHQge1xuICAgIH1cbiAgICBVcGRhdGVTdGF0aWNUZXh0LnR5cGUgPSBcIltDb25maWddIFVwZGF0ZSBTdGF0aWMgVGV4dFwiO1xuICAgIENvbmZpZy5VcGRhdGVTdGF0aWNUZXh0ID0gVXBkYXRlU3RhdGljVGV4dDtcbn0pKENvbmZpZyB8fCAoQ29uZmlnID0ge30pKTtcbiIsImV4cG9ydCB7fTtcbiIsImltcG9ydCB7IFN0YXRlLCBBY3Rpb24sIFNlbGVjdG9yLCBTdG9yZSB9IGZyb20gXCJAbmd4cy9zdG9yZVwiO1xuaW1wb3J0IHsgY2F0Y2hFcnJvciwgdGFwIH0gZnJvbSBcInJ4anMvb3BlcmF0b3JzXCI7XG5pbXBvcnQgeyBBcGlTZXJ2aWNlLCBTdHlsaW5nU2VydmljZSB9IGZyb20gXCJAYXBwL2NvcmVcIjtcbmltcG9ydCB7IENvbmZpZyB9IGZyb20gXCIuL2NvbmZpZy5hY3Rpb25zXCI7XG5pbXBvcnQgeyBvZiB9IGZyb20gXCJyeGpzXCI7XG5pbXBvcnQgeyBQcm9kdWN0IH0gZnJvbSBcIi4uL3Byb2R1Y3RcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQGFwcC9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMiBmcm9tIFwiQG5neHMvc3RvcmVcIjtcbmxldCBDb25maWdTdGF0ZSA9IGNsYXNzIENvbmZpZ1N0YXRlIHtcbiAgICBjb25zdHJ1Y3RvcihhcGlTZXJ2aWNlLCBzdHlsaW5nU2VydmljZSwgc3RvcmUpIHtcbiAgICAgICAgdGhpcy5hcGlTZXJ2aWNlID0gYXBpU2VydmljZTtcbiAgICAgICAgdGhpcy5zdHlsaW5nU2VydmljZSA9IHN0eWxpbmdTZXJ2aWNlO1xuICAgICAgICB0aGlzLnN0b3JlID0gc3RvcmU7XG4gICAgfVxuICAgIHVwZGF0ZURhdGFVcmwoY3R4LCBhY3Rpb24pIHtcbiAgICAgICAgY29uc3Qgc3RhdGUgPSBjdHguZ2V0U3RhdGUoKTtcbiAgICAgICAgaWYgKGFjdGlvbi51cmwpIHtcbiAgICAgICAgICAgIGN0eC5zZXRTdGF0ZShPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyBkYXRhVXJsOiBhY3Rpb24udXJsIH0pKTtcbiAgICAgICAgICAgIC8vIFRPRE86IHRoZXJlIGlzIGEgcmFjZSBjb25kaXRpb24gaWYgdGhlIGRpc3BhdGNoIGhhcHBlbnMgYXQgdGhlIHNhbWUgdGltZVxuICAgICAgICAgICAgdGhpcy5zdG9yZVxuICAgICAgICAgICAgICAgIC5kaXNwYXRjaChuZXcgUHJvZHVjdC5Mb2FkQ2F0ZWdvcmllcyhhY3Rpb24udXJsKSlcbiAgICAgICAgICAgICAgICAudG9Qcm9taXNlKClcbiAgICAgICAgICAgICAgICAudGhlbigoKSA9PiB0aGlzLnN0b3JlLmRpc3BhdGNoKG5ldyBQcm9kdWN0LkxvYWRQcm9kdWN0R3JvdXBzKGFjdGlvbi51cmwpKSk7XG4gICAgICAgICAgICByZXR1cm4gY3R4LmRpc3BhdGNoKFtuZXcgQ29uZmlnLlVwZGF0ZVN0YXRpY1RleHQoKV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHVwZGF0ZVN0eWxpbmdVcmwoY3R4LCBhY3Rpb24pIHtcbiAgICAgICAgY29uc3Qgc3RhdGUgPSBjdHguZ2V0U3RhdGUoKTtcbiAgICAgICAgaWYgKGFjdGlvbi51cmwpIHtcbiAgICAgICAgICAgIGN0eC5zZXRTdGF0ZShPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyBzdHlsaW5nVXJsOiBhY3Rpb24udXJsIH0pKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmFwaVNlcnZpY2UuZ2V0UmVtb3RlU3R5bGVzJChhY3Rpb24udXJsKS5waXBlKHRhcCgoc3R5bGUpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnN0eWxpbmdTZXJ2aWNlLnVwZGF0ZUFwcENTUyhzdHlsZSk7XG4gICAgICAgICAgICB9KSwgY2F0Y2hFcnJvcigoZXJyKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBsb2FkaW5nIHJlbW90ZSBzdHlsZVwiLCBlcnIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBvZihlcnIpO1xuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHVwZGF0ZVN0eWxlT3B0aW9ucyhjdHgsIGFjdGlvbikge1xuICAgICAgICBjb25zdCBzdGF0ZSA9IGN0eC5nZXRTdGF0ZSgpO1xuICAgICAgICByZXR1cm4gdGhpcy5hcGlTZXJ2aWNlLmdldFJlbW90ZVN0eWxlc09wdGlvbnMkKCkucGlwZSh0YXAoKHN0eWxlT3B0aW9ucykgPT4ge1xuICAgICAgICAgICAgY3R4LnNldFN0YXRlKE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUpLCB7IHN0eWxlT3B0aW9uczogc3R5bGVPcHRpb25zIH0pKTtcbiAgICAgICAgfSksIGNhdGNoRXJyb3IoKGVycikgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBsb2FkaW5nIHN0eWxlIG9wdGlvbnNcIiwgZXJyKTtcbiAgICAgICAgICAgIHJldHVybiBvZihlcnIpO1xuICAgICAgICB9KSk7XG4gICAgfVxuICAgIHVwZGF0ZVN0YXRpY1RleHQoY3R4KSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gY3R4LmdldFN0YXRlKCk7XG4gICAgICAgIHJldHVybiB0aGlzLmFwaVNlcnZpY2UuZ2V0U3RhdGljVGV4dCQoc3RhdGUuZGF0YVVybCkucGlwZSh0YXAoKHN0YXRpY1RleHQpID0+IHtcbiAgICAgICAgICAgIC8vIFRPRE86IGFkZCBlcnJvciBoYW5kbGluZyBjYXRjaEVycm9yP1xuICAgICAgICAgICAgY3R4LnNldFN0YXRlKE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUpLCB7IHN0YXRpY1RleHQ6IHN0YXRpY1RleHQgfSkpO1xuICAgICAgICB9KSwgY2F0Y2hFcnJvcigoZXJyKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcImVycm9yIGxvYWRpbmcgc3RhdGljIHRleHRcIiwgZXJyKTtcbiAgICAgICAgICAgIHJldHVybiBvZihlcnIpO1xuICAgICAgICB9KSk7XG4gICAgfVxuICAgIHN0YXRpYyBkYXRhVXJsKHN0YXRlKSB7XG4gICAgICAgIHJldHVybiBzdGF0ZS5kYXRhVXJsO1xuICAgIH1cbiAgICBzdGF0aWMgc3R5bGluZ1VybChzdGF0ZSkge1xuICAgICAgICByZXR1cm4gc3RhdGUuc3R5bGluZ1VybDtcbiAgICB9XG4gICAgc3RhdGljIHN0YXRpY1RleHQoc3RhdGUpIHtcbiAgICAgICAgcmV0dXJuIHN0YXRlLnN0YXRpY1RleHQ7XG4gICAgfVxuICAgIHN0YXRpYyBzdHlsZU9wdGlvbnMoc3RhdGUpIHtcbiAgICAgICAgcmV0dXJuIHN0YXRlLnN0eWxlT3B0aW9ucztcbiAgICB9XG59O1xuQ29uZmlnU3RhdGUuybVmYWMgPSBmdW5jdGlvbiBDb25maWdTdGF0ZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBDb25maWdTdGF0ZSkoaTAuybXJtWluamVjdChpMS5BcGlTZXJ2aWNlKSwgaTAuybXJtWluamVjdChpMS5TdHlsaW5nU2VydmljZSksIGkwLsm1ybVpbmplY3QoaTIuU3RvcmUpKTsgfTtcbkNvbmZpZ1N0YXRlLsm1cHJvdiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdGFibGUoeyB0b2tlbjogQ29uZmlnU3RhdGUsIGZhY3Rvcnk6IENvbmZpZ1N0YXRlLsm1ZmFjIH0pO1xuX19kZWNvcmF0ZShbXG4gICAgQWN0aW9uKENvbmZpZy5VcGRhdGVEYXRhVXJsKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgRnVuY3Rpb24pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cGFyYW10eXBlc1wiLCBbT2JqZWN0LCBDb25maWcuVXBkYXRlRGF0YVVybF0pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cmV0dXJudHlwZVwiLCB2b2lkIDApXG5dLCBDb25maWdTdGF0ZS5wcm90b3R5cGUsIFwidXBkYXRlRGF0YVVybFwiLCBudWxsKTtcbl9fZGVjb3JhdGUoW1xuICAgIEFjdGlvbihDb25maWcuVXBkYXRlU3R5bGluZ1VybCksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjp0eXBlXCIsIEZ1bmN0aW9uKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnBhcmFtdHlwZXNcIiwgW09iamVjdCwgQ29uZmlnLlVwZGF0ZVN0eWxpbmdVcmxdKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnJldHVybnR5cGVcIiwgdm9pZCAwKVxuXSwgQ29uZmlnU3RhdGUucHJvdG90eXBlLCBcInVwZGF0ZVN0eWxpbmdVcmxcIiwgbnVsbCk7XG5fX2RlY29yYXRlKFtcbiAgICBBY3Rpb24oQ29uZmlnLlVwZGF0ZVN0eWxlT3B0aW9ucyksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjp0eXBlXCIsIEZ1bmN0aW9uKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnBhcmFtdHlwZXNcIiwgW09iamVjdCwgQ29uZmlnLlVwZGF0ZVN0eWxlT3B0aW9uc10pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cmV0dXJudHlwZVwiLCB2b2lkIDApXG5dLCBDb25maWdTdGF0ZS5wcm90b3R5cGUsIFwidXBkYXRlU3R5bGVPcHRpb25zXCIsIG51bGwpO1xuX19kZWNvcmF0ZShbXG4gICAgQWN0aW9uKENvbmZpZy5VcGRhdGVTdGF0aWNUZXh0KSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgRnVuY3Rpb24pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cGFyYW10eXBlc1wiLCBbT2JqZWN0XSksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpyZXR1cm50eXBlXCIsIHZvaWQgMClcbl0sIENvbmZpZ1N0YXRlLnByb3RvdHlwZSwgXCJ1cGRhdGVTdGF0aWNUZXh0XCIsIG51bGwpO1xuX19kZWNvcmF0ZShbXG4gICAgU2VsZWN0b3IoKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgRnVuY3Rpb24pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cGFyYW10eXBlc1wiLCBbT2JqZWN0XSksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpyZXR1cm50eXBlXCIsIHZvaWQgMClcbl0sIENvbmZpZ1N0YXRlLCBcImRhdGFVcmxcIiwgbnVsbCk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3RvcigpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBGdW5jdGlvbiksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpwYXJhbXR5cGVzXCIsIFtPYmplY3RdKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnJldHVybnR5cGVcIiwgdm9pZCAwKVxuXSwgQ29uZmlnU3RhdGUsIFwic3R5bGluZ1VybFwiLCBudWxsKTtcbl9fZGVjb3JhdGUoW1xuICAgIFNlbGVjdG9yKCksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjp0eXBlXCIsIEZ1bmN0aW9uKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnBhcmFtdHlwZXNcIiwgW09iamVjdF0pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cmV0dXJudHlwZVwiLCB2b2lkIDApXG5dLCBDb25maWdTdGF0ZSwgXCJzdGF0aWNUZXh0XCIsIG51bGwpO1xuX19kZWNvcmF0ZShbXG4gICAgU2VsZWN0b3IoKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgRnVuY3Rpb24pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cGFyYW10eXBlc1wiLCBbT2JqZWN0XSksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpyZXR1cm50eXBlXCIsIHZvaWQgMClcbl0sIENvbmZpZ1N0YXRlLCBcInN0eWxlT3B0aW9uc1wiLCBudWxsKTtcbkNvbmZpZ1N0YXRlID0gX19kZWNvcmF0ZShbXG4gICAgU3RhdGUoe1xuICAgICAgICBuYW1lOiBcImNvbmZpZ1wiLFxuICAgICAgICBkZWZhdWx0czoge1xuICAgICAgICAgICAgLy8gc2FtcGxlIGRhdGEgdXJsczpcbiAgICAgICAgICAgIC8vIGRlZmF1bHQ6IGh0dHBzOi8vcmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbS93aWxsaWFtanVhbjAyNy9tb3ZpZXMtYXBwLWFwaS9tYWluL2RhdGEvZGVmYXVsdC9cbiAgICAgICAgICAgIC8vIHRyYXZlbDogaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3dpbGxpYW1qdWFuMDI3L21vdmllcy1hcHAtYXBpL21haW4vZGF0YS90cmF2ZWwvXG4gICAgICAgICAgICAvLyBpbmRvOiBodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vd2lsbGlhbWp1YW4wMjcvbW92aWVzLWFwcC1hcGkvdHJhbnNsYXRlL2luZG8vZGF0YS9cbiAgICAgICAgICAgIGRhdGFVcmw6IFwiXCIsXG4gICAgICAgICAgICAvLyBzYW1wbGUgc3R5bGluZyB1cmxzOlxuICAgICAgICAgICAgLy8gZGVmYXVsdDogaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3dpbGxpYW1qdWFuMDI3L21vdmllcy1hcHAtYXBpL21haW4vc3R5bGVzL3ByaW1hcnkuY3NzXG4gICAgICAgICAgICAvLyBncmVlbmlzaDogaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3dpbGxpYW1qdWFuMDI3L21vdmllcy1hcHAtYXBpL21haW4vc3R5bGVzL2dyZWVuaXNoLmNzc1xuICAgICAgICAgICAgLy8gc3BvdGlmeTogaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3dpbGxpYW1qdWFuMDI3L21vdmllcy1hcHAtYXBpL21haW4vc3R5bGVzL3Nwb3RpZnkuY3NzXG4gICAgICAgICAgICAvLyBuZXRmbGl4OiBodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vd2lsbGlhbWp1YW4wMjcvbW92aWVzLWFwcC1hcGkvbWFpbi9zdHlsZXMvbmV0ZmxpeC5jc3NcbiAgICAgICAgICAgIC8vIGFpcmJuYjogaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3dpbGxpYW1qdWFuMDI3L21vdmllcy1hcHAtYXBpL21haW4vc3R5bGVzL2FpcmJuYi5jc3NcbiAgICAgICAgICAgIHN0eWxpbmdVcmw6IFwiXCIsXG4gICAgICAgICAgICBzdHlsZU9wdGlvbnM6IFtdLFxuICAgICAgICAgICAgc3RhdGljVGV4dDogdW5kZWZpbmVkLFxuICAgICAgICB9LFxuICAgIH0pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cGFyYW10eXBlc1wiLCBbQXBpU2VydmljZSxcbiAgICAgICAgU3R5bGluZ1NlcnZpY2UsXG4gICAgICAgIFN0b3JlXSlcbl0sIENvbmZpZ1N0YXRlKTtcbmV4cG9ydCB7IENvbmZpZ1N0YXRlIH07XG4iLCJleHBvcnQgKiBmcm9tIFwiLi9jb25maWcuYWN0aW9uc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vY29uZmlnLm1vZGVsXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9jb25maWcuc3RhdGVcIjtcbiIsImV4cG9ydCAqIGZyb20gXCIuL2NvbmZpZ1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vcHJvZHVjdFwiO1xuIiwiZXhwb3J0ICogZnJvbSBcIi4vcHJvZHVjdC5hY3Rpb25zXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9wcm9kdWN0Lm1vZGVsXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9wcm9kdWN0LnN0YXRlXCI7XG4iLCJleHBvcnQgdmFyIFByb2R1Y3Q7XG4oZnVuY3Rpb24gKFByb2R1Y3QpIHtcbiAgICBjbGFzcyBMb2FkQ2F0ZWdvcmllcyB7XG4gICAgICAgIGNvbnN0cnVjdG9yKHVybCkge1xuICAgICAgICAgICAgdGhpcy51cmwgPSB1cmw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgTG9hZENhdGVnb3JpZXMudHlwZSA9IFwiW1Byb2R1Y3RdIExvYWQgQ2F0ZWdvcmllc1wiO1xuICAgIFByb2R1Y3QuTG9hZENhdGVnb3JpZXMgPSBMb2FkQ2F0ZWdvcmllcztcbiAgICBjbGFzcyBMb2FkUHJvZHVjdEdyb3VwcyB7XG4gICAgICAgIGNvbnN0cnVjdG9yKHVybCkge1xuICAgICAgICAgICAgdGhpcy51cmwgPSB1cmw7XG4gICAgICAgIH1cbiAgICB9XG4gICAgTG9hZFByb2R1Y3RHcm91cHMudHlwZSA9IFwiW1Byb2R1Y3RdIExvYWQgUHJvZHVjdHMgR3JvdXBzXCI7XG4gICAgUHJvZHVjdC5Mb2FkUHJvZHVjdEdyb3VwcyA9IExvYWRQcm9kdWN0R3JvdXBzO1xufSkoUHJvZHVjdCB8fCAoUHJvZHVjdCA9IHt9KSk7XG4iLCJleHBvcnQge307XG4iLCJ2YXIgUHJvZHVjdFN0YXRlXzE7XG5pbXBvcnQgeyBvZiB9IGZyb20gXCJyeGpzXCI7XG5pbXBvcnQgeyB0YXAsIGNhdGNoRXJyb3IgfSBmcm9tIFwicnhqcy9vcGVyYXRvcnNcIjtcbmltcG9ydCB7IFN0YXRlLCBBY3Rpb24sIFNlbGVjdG9yLCBjcmVhdGVTZWxlY3RvciwgfSBmcm9tIFwiQG5neHMvc3RvcmVcIjtcbmltcG9ydCB7IEFwaVNlcnZpY2UgfSBmcm9tIFwiQGFwcC9jb3JlXCI7XG5pbXBvcnQgeyBQcm9kdWN0IH0gZnJvbSBcIi4vcHJvZHVjdC5hY3Rpb25zXCI7XG5pbXBvcnQgY2F0ZWdvcmllcyBmcm9tIFwiLi4vLi4vLi4vLi4vYXNzZXRzL2xvY2FsLWRhdGEvY2F0ZWdvcmllcy5qc29uXCI7XG5pbXBvcnQgcHJvZHVjdEdyb3VwcyBmcm9tIFwiLi4vLi4vLi4vLi4vYXNzZXRzL2xvY2FsLWRhdGEvcHJvZHVjdEdyb3Vwcy5qc29uXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0ICogYXMgaTEgZnJvbSBcIkBhcHAvY29yZVwiO1xubGV0IFByb2R1Y3RTdGF0ZSA9IFByb2R1Y3RTdGF0ZV8xID0gY2xhc3MgUHJvZHVjdFN0YXRlIHtcbiAgICBjb25zdHJ1Y3RvcihhcGlTZXJ2aWNlKSB7XG4gICAgICAgIHRoaXMuYXBpU2VydmljZSA9IGFwaVNlcnZpY2U7XG4gICAgfVxuICAgIGxvYWRDYXRlZ29yaWVzKGN0eCwgYWN0aW9uKSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gY3R4LmdldFN0YXRlKCk7XG4gICAgICAgIHJldHVybiB0aGlzLmFwaVNlcnZpY2UuZ2V0Q2F0ZWdvcmllcyQoYWN0aW9uLnVybCkucGlwZSh0YXAoKGNhdGVnb3JpZXMpID0+IHtcbiAgICAgICAgICAgIGN0eC5zZXRTdGF0ZShPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyBjYXRlZ29yaWVzOiBjYXRlZ29yaWVzIH0pKTtcbiAgICAgICAgfSksIGNhdGNoRXJyb3IoKGVycikgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBsb2FkaW5nIGNhdGVnb3JpZXNcIiwgZXJyKTtcbiAgICAgICAgICAgIHJldHVybiBvZihlcnIpO1xuICAgICAgICB9KSk7XG4gICAgfVxuICAgIGxvYWRQcm9kdWN0R3JvdXBzKGN0eCwgYWN0aW9uKSB7XG4gICAgICAgIGNvbnN0IHN0YXRlID0gY3R4LmdldFN0YXRlKCk7XG4gICAgICAgIHJldHVybiB0aGlzLmFwaVNlcnZpY2UuZ2V0UHJvZHVjdEdyb3VwcyQoYWN0aW9uLnVybCkucGlwZSh0YXAoKHByb2R1Y3RHcm91cHMpID0+IHtcbiAgICAgICAgICAgIGN0eC5zZXRTdGF0ZShPYmplY3QuYXNzaWduKE9iamVjdC5hc3NpZ24oe30sIHN0YXRlKSwgeyBwcm9kdWN0R3JvdXBzOiBwcm9kdWN0R3JvdXBzIH0pKTtcbiAgICAgICAgfSksIGNhdGNoRXJyb3IoKGVycikgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnJvciBsb2FkaW5nIHByb2R1Y3QgZ3JvdXBzXCIsIGVycik7XG4gICAgICAgICAgICByZXR1cm4gb2YoZXJyKTtcbiAgICAgICAgfSkpO1xuICAgIH1cbiAgICBzdGF0aWMgY2F0ZWdvcmllcyhzdGF0ZSkge1xuICAgICAgICByZXR1cm4gc3RhdGUuY2F0ZWdvcmllcztcbiAgICB9XG4gICAgc3RhdGljIHByb2R1Y3RHcm91cHMoc3RhdGUpIHtcbiAgICAgICAgdmFyIF9hO1xuICAgICAgICAvLyBmaWx0ZXIgb3V0IGZlYXR1cmVkIHRlbXBvcmFyaWx5XG4gICAgICAgIHJldHVybiAoKChfYSA9IHN0YXRlLnByb2R1Y3RHcm91cHMpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5maWx0ZXIoKGdyb3VwKSA9PiBncm91cC5ncm91cEtleSAhPT0gXCJmZWF0dXJlZFwiKSkgfHxcbiAgICAgICAgICAgIFtdKTtcbiAgICB9XG4gICAgc3RhdGljIGZlYXR1cmVkUHJvZHVjdChzdGF0ZSkge1xuICAgICAgICB2YXIgX2EsIF9iLCBfYztcbiAgICAgICAgcmV0dXJuICgoKF9jID0gKF9iID0gKF9hID0gc3RhdGUucHJvZHVjdEdyb3VwcykgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmZpbmQoKGdyb3VwKSA9PiBncm91cC5ncm91cEtleSA9PT0gXCJmZWF0dXJlZFwiKSkgPT09IG51bGwgfHwgX2IgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9iLnByb2R1Y3RzKSA9PT0gbnVsbCB8fCBfYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2NbMF0pIHx8IHVuZGVmaW5lZCk7XG4gICAgfVxuICAgIHN0YXRpYyBwcm9kdWN0QnlJZChwcm9kdWN0SWQpIHtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZVNlbGVjdG9yKFtQcm9kdWN0U3RhdGVfMV0sIChzdGF0ZSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHN0YXRlLnByb2R1Y3RHcm91cHNcbiAgICAgICAgICAgICAgICAucmVkdWNlKChwcm9kdWN0cywgcHJvZHVjdEdyb3VwcykgPT4ge1xuICAgICAgICAgICAgICAgIHByb2R1Y3RzLnB1c2goLi4ucHJvZHVjdEdyb3Vwcy5wcm9kdWN0cyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHByb2R1Y3RzO1xuICAgICAgICAgICAgfSwgW10pXG4gICAgICAgICAgICAgICAgLmZpbmQoKHByb2R1Y3QpID0+IHByb2R1Y3QuaWQgPT09IHByb2R1Y3RJZCk7XG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5Qcm9kdWN0U3RhdGUuybVmYWMgPSBmdW5jdGlvbiBQcm9kdWN0U3RhdGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgUHJvZHVjdFN0YXRlKShpMC7Jtcm1aW5qZWN0KGkxLkFwaVNlcnZpY2UpKTsgfTtcblByb2R1Y3RTdGF0ZS7JtXByb3YgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVJbmplY3RhYmxlKHsgdG9rZW46IFByb2R1Y3RTdGF0ZSwgZmFjdG9yeTogUHJvZHVjdFN0YXRlLsm1ZmFjIH0pO1xuX19kZWNvcmF0ZShbXG4gICAgQWN0aW9uKFByb2R1Y3QuTG9hZENhdGVnb3JpZXMpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBGdW5jdGlvbiksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpwYXJhbXR5cGVzXCIsIFtPYmplY3QsIFByb2R1Y3QuTG9hZENhdGVnb3JpZXNdKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnJldHVybnR5cGVcIiwgdm9pZCAwKVxuXSwgUHJvZHVjdFN0YXRlLnByb3RvdHlwZSwgXCJsb2FkQ2F0ZWdvcmllc1wiLCBudWxsKTtcbl9fZGVjb3JhdGUoW1xuICAgIEFjdGlvbihQcm9kdWN0LkxvYWRQcm9kdWN0R3JvdXBzKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgRnVuY3Rpb24pLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246cGFyYW10eXBlc1wiLCBbT2JqZWN0LCBQcm9kdWN0LkxvYWRQcm9kdWN0R3JvdXBzXSksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpyZXR1cm50eXBlXCIsIHZvaWQgMClcbl0sIFByb2R1Y3RTdGF0ZS5wcm90b3R5cGUsIFwibG9hZFByb2R1Y3RHcm91cHNcIiwgbnVsbCk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3RvcigpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBGdW5jdGlvbiksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpwYXJhbXR5cGVzXCIsIFtPYmplY3RdKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnJldHVybnR5cGVcIiwgdm9pZCAwKVxuXSwgUHJvZHVjdFN0YXRlLCBcImNhdGVnb3JpZXNcIiwgbnVsbCk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3RvcigpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBGdW5jdGlvbiksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpwYXJhbXR5cGVzXCIsIFtPYmplY3RdKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnJldHVybnR5cGVcIiwgdm9pZCAwKVxuXSwgUHJvZHVjdFN0YXRlLCBcInByb2R1Y3RHcm91cHNcIiwgbnVsbCk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3RvcigpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBGdW5jdGlvbiksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjpwYXJhbXR5cGVzXCIsIFtPYmplY3RdKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnJldHVybnR5cGVcIiwgdm9pZCAwKVxuXSwgUHJvZHVjdFN0YXRlLCBcImZlYXR1cmVkUHJvZHVjdFwiLCBudWxsKTtcblByb2R1Y3RTdGF0ZSA9IFByb2R1Y3RTdGF0ZV8xID0gX19kZWNvcmF0ZShbXG4gICAgU3RhdGUoe1xuICAgICAgICBuYW1lOiBcInByb2R1Y3RcIixcbiAgICAgICAgZGVmYXVsdHM6IHtcbiAgICAgICAgICAgIGNhdGVnb3JpZXM6IGNhdGVnb3JpZXMuY2F0ZWdvcmllcyxcbiAgICAgICAgICAgIHByb2R1Y3RHcm91cHM6IHByb2R1Y3RHcm91cHMucHJvZHVjdEdyb3VwcyxcbiAgICAgICAgfSxcbiAgICB9KSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnBhcmFtdHlwZXNcIiwgW0FwaVNlcnZpY2VdKVxuXSwgUHJvZHVjdFN0YXRlKTtcbmV4cG9ydCB7IFByb2R1Y3RTdGF0ZSB9O1xuIiwiaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmV4cG9ydCBjbGFzcyBMb2FkaW5nQ29tcG9uZW50IHtcbn1cbkxvYWRpbmdDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBMb2FkaW5nQ29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IExvYWRpbmdDb21wb25lbnQpKCk7IH07XG5Mb2FkaW5nQ29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogTG9hZGluZ0NvbXBvbmVudCwgc2VsZWN0b3JzOiBbW1wibnMtbG9hZGluZ1wiXV0sIGRlY2xzOiAyLCB2YXJzOiAzLCBjb25zdHM6IFtbXCJyb3dzXCIsIFwiKlwiLCBcImNvbHVtbnNcIiwgXCIqXCIsIFwiaGVpZ2h0XCIsIFwiMTAwJVwiLCBcIndpZHRoXCIsIFwiMTAwJVwiXSwgW1wid2lkdGhcIiwgXCIzMDBcIiwgXCJoZWlnaHRcIiwgXCIzMDBcIiwgXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCBcImhvcml6b250YWxBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgMywgXCJzcmNcIiwgXCJsb29wXCIsIFwiYXV0b1BsYXlcIl1dLCB0ZW1wbGF0ZTogZnVuY3Rpb24gTG9hZGluZ0NvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiTG90dGllVmlld1wiLCAxKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICB9IGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcInNyY1wiLCBcIn4vYXNzZXRzL2xvdHRpZS9zcGxhc2hzY3JlZW4uanNvblwiKShcImxvb3BcIiwgdHJ1ZSkoXCJhdXRvUGxheVwiLCB0cnVlKTtcbiAgICB9IH0sIGVuY2Fwc3VsYXRpb246IDIgfSk7XG4iLCJpbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgeyByZWdpc3RlckVsZW1lbnQgfSBmcm9tICdAbmF0aXZlc2NyaXB0L2FuZ3VsYXInO1xuaW1wb3J0IHsgTmF0aXZlU2NyaXB0TW9kdWxlLCBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgeyBMb2FkaW5nQ29tcG9uZW50IH0gZnJvbSBcIi4vbG9hZGluZy5jb21wb25lbnRcIjtcbmltcG9ydCB7IExvdHRpZVZpZXcgfSBmcm9tICdAbmF0aXZlc2NyaXB0LWNvbW11bml0eS91aS1sb3R0aWUnO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbnJlZ2lzdGVyRWxlbWVudCgnTG90dGllVmlldycsICgpID0+IExvdHRpZVZpZXcpO1xuZXhwb3J0IGNsYXNzIExvYWRpbmdNb2R1bGUge1xufVxuTG9hZGluZ01vZHVsZS7JtWZhYyA9IGZ1bmN0aW9uIExvYWRpbmdNb2R1bGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgTG9hZGluZ01vZHVsZSkoKTsgfTtcbkxvYWRpbmdNb2R1bGUuybVtb2QgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVOZ01vZHVsZSh7IHR5cGU6IExvYWRpbmdNb2R1bGUsIGJvb3RzdHJhcDogW0xvYWRpbmdDb21wb25lbnRdIH0pO1xuTG9hZGluZ01vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW05hdGl2ZVNjcmlwdE1vZHVsZSxcbiAgICAgICAgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLFxuICAgICAgICBDb21tb25Nb2R1bGVdIH0pO1xuIiwiaW1wb3J0IHsgVGh1bWJuYWlsQ2FyZENvbXBvbmVudCB9IGZyb20gXCIuL3RodW1ibmFpbC1jYXJkL3RodW1ibmFpbC1jYXJkLmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgU2VhcmNoQ2FyZENvbXBvbmVudCB9IGZyb20gXCIuL3NlYXJjaC1jYXJkL3NlYXJjaC1jYXJkLmNvbXBvbmVudFwiO1xuZXhwb3J0IGNvbnN0IENBUkRTX0NPTVBPTkVOVFMgPSBbVGh1bWJuYWlsQ2FyZENvbXBvbmVudCwgU2VhcmNoQ2FyZENvbXBvbmVudF07XG5leHBvcnQgKiBmcm9tIFwiLi90aHVtYm5haWwtY2FyZC90aHVtYm5haWwtY2FyZC5jb21wb25lbnRcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3NlYXJjaC1jYXJkL3NlYXJjaC1jYXJkLmNvbXBvbmVudFwiO1xuIiwiaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmV4cG9ydCBjbGFzcyBTZWFyY2hDYXJkQ29tcG9uZW50IHtcbn1cblNlYXJjaENhcmRDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBTZWFyY2hDYXJkQ29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IFNlYXJjaENhcmRDb21wb25lbnQpKCk7IH07XG5TZWFyY2hDYXJkQ29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogU2VhcmNoQ2FyZENvbXBvbmVudCwgc2VsZWN0b3JzOiBbW1wibnMtc2VhcmNoLWNhcmRcIl1dLCBpbnB1dHM6IHsgaW1hZ2VTcmM6IFwiaW1hZ2VTcmNcIiwgdGl0bGU6IFwidGl0bGVcIiwgZGVzY3JpcHRpb246IFwiZGVzY3JpcHRpb25cIiB9LCBkZWNsczogNSwgdmFyczogMywgY29uc3RzOiBbW1wicm93c1wiLCBcIipcIiwgXCJjb2x1bW5zXCIsIFwiYXV0bywgMTAsICpcIiwgXCJtYXJnaW5SaWdodFwiLCBcIjEwXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiMFwiLCBcImhlaWdodFwiLCBcIjEyMFwiLCBcIndpZHRoXCIsIFwiOTBcIiwgXCJzdHJldGNoXCIsIFwiYXNwZWN0RmlsbFwiLCAxLCBcImdsb3ctc2hhZG93XCIsIDMsIFwic3JjXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiMlwiXSwgW1wiZm9udFNpemVcIiwgXCIyNVwiLCBcInRleHRXcmFwXCIsIFwidHJ1ZVwiLCAxLCBcImJvbGRcIiwgMywgXCJ0ZXh0XCJdLCBbXCJ0ZXh0V3JhcFwiLCBcInRydWVcIiwgXCJmb250U2l6ZVwiLCBcIjE4XCIsIDMsIFwidGV4dFwiXV0sIHRlbXBsYXRlOiBmdW5jdGlvbiBTZWFyY2hDYXJkQ29tcG9uZW50X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDAsIFwiR3JpZExheW91dFwiLCAwKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMSwgXCJJbWFnZVwiLCAxKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgyLCBcIlN0YWNrTGF5b3V0XCIsIDIpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgzLCBcIkxhYmVsXCIsIDMpKDQsIFwiTGFiZWxcIiwgNCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKTtcbiAgICB9IGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcInNyY1wiLCBjdHguaW1hZ2VTcmMpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHgudGl0bGUpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHguZGVzY3JpcHRpb24uc3Vic3RyaW5nKDAsIDYwKSArIFwiLi4uXCIpO1xuICAgIH0gfSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5leHBvcnQgY2xhc3MgVGh1bWJuYWlsQ2FyZENvbXBvbmVudCB7XG59XG5UaHVtYm5haWxDYXJkQ29tcG9uZW50Lsm1ZmFjID0gZnVuY3Rpb24gVGh1bWJuYWlsQ2FyZENvbXBvbmVudF9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBUaHVtYm5haWxDYXJkQ29tcG9uZW50KSgpOyB9O1xuVGh1bWJuYWlsQ2FyZENvbXBvbmVudC7JtWNtcCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUNvbXBvbmVudCh7IHR5cGU6IFRodW1ibmFpbENhcmRDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLXRodW1ibmFpbC1jYXJkXCJdXSwgaW5wdXRzOiB7IGltYWdlU3JjOiBcImltYWdlU3JjXCIgfSwgZGVjbHM6IDQsIHZhcnM6IDEsIGNvbnN0czogW1tcImhlaWdodFwiLCBcIjE2MFwiLCBcIndpZHRoXCIsIFwiMTI1XCIsIFwicm93c1wiLCBcIipcIiwgXCJjb2x1bW5zXCIsIFwiKlwiLCBcIm1hcmdpblJpZ2h0XCIsIFwiMTBcIl0sIFtcImhlaWdodFwiLCBcIjk1JVwiLCBcIndpZHRoXCIsIFwiOTUlXCIsIDEsIFwiZ2xvdy1zaGFkb3dcIl0sIFsxLCBcImJnLWNvbG9yLWRlZmF1bHRcIiwgXCJib3JkZXItcmFkaXVzLW1cIl0sIFtcInN0cmV0Y2hcIiwgXCJhc3BlY3RGaWxsXCIsIDMsIFwic3JjXCJdXSwgdGVtcGxhdGU6IGZ1bmN0aW9uIFRodW1ibmFpbENhcmRDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJHcmlkTGF5b3V0XCIsIDApO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgxLCBcIkNvbnRlbnRWaWV3XCIsIDEpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDIsIFwiR3JpZExheW91dFwiLCAyKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMywgXCJJbWFnZVwiLCAzKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKSgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwic3JjXCIsIGN0eC5pbWFnZVNyYyk7XG4gICAgfSB9LCBlbmNhcHN1bGF0aW9uOiAyIH0pO1xuIiwiaW1wb3J0IHsgSWNvbnMsIExheWVyc1NlcnZpY2UsIE5hdmlnYXRpb25TZXJ2aWNlIH0gZnJvbSBcIkBhcHAvY29yZVwiO1xuaW1wb3J0IHsgaXNJT1MgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0ICogYXMgaTEgZnJvbSBcIkBhcHAvY29yZVwiO1xuaW1wb3J0ICogYXMgaTIgZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuZnVuY3Rpb24gSGVhZGVyQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xX1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGNvbnN0IF9yNCA9IGkwLsm1ybVnZXRDdXJyZW50VmlldygpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyU3RhcnQoMCk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCgxLCBcIkdyaWRMYXlvdXRcIiwgMyk7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwidGFwXCIsIGZ1bmN0aW9uIEhlYWRlckNvbXBvbmVudF9uZ19jb250YWluZXJfMV9UZW1wbGF0ZV9HcmlkTGF5b3V0X3RhcF8xX2xpc3RlbmVyKCkgeyBpMC7Jtcm1cmVzdG9yZVZpZXcoX3I0KTsgY29uc3QgY3R4X3IzID0gaTAuybXJtW5leHRDb250ZXh0KCk7IHJldHVybiBpMC7Jtcm1cmVzZXRWaWV3KGN0eF9yMy5iYWNrKCkpOyB9KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgyLCBcIkxhYmVsXCIsIDQpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yMCA9IGkwLsm1ybVuZXh0Q29udGV4dCgpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IwLmljb25zLmJhY2spO1xufSB9XG5mdW5jdGlvbiBIZWFkZXJDb21wb25lbnRfbmdfY29udGFpbmVyXzJfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgY29uc3QgX3I2ID0gaTAuybXJtWdldEN1cnJlbnRWaWV3KCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiR3JpZExheW91dFwiLCAzKTtcbiAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gSGVhZGVyQ29tcG9uZW50X25nX2NvbnRhaW5lcl8yX1RlbXBsYXRlX0dyaWRMYXlvdXRfdGFwXzFfbGlzdGVuZXIoKSB7IGkwLsm1ybVyZXN0b3JlVmlldyhfcjYpOyBjb25zdCBjdHhfcjUgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTsgcmV0dXJuIGkwLsm1ybVyZXNldFZpZXcoY3R4X3I1Lm9wZW5NZW51KCkpOyB9KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgyLCBcIkxhYmVsXCIsIDUpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yMSA9IGkwLsm1ybVuZXh0Q29udGV4dCgpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IxLmljb25zLm1lbnUpO1xufSB9XG5mdW5jdGlvbiBIZWFkZXJDb21wb25lbnRfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgY29uc3QgX3I4ID0gaTAuybXJtWdldEN1cnJlbnRWaWV3KCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiR3JpZExheW91dFwiLCA2KTtcbiAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gSGVhZGVyQ29tcG9uZW50X25nX2NvbnRhaW5lcl8zX1RlbXBsYXRlX0dyaWRMYXlvdXRfdGFwXzFfbGlzdGVuZXIoKSB7IGkwLsm1ybVyZXN0b3JlVmlldyhfcjgpOyBjb25zdCBjdHhfcjcgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTsgcmV0dXJuIGkwLsm1ybVyZXNldFZpZXcoY3R4X3I3LnJpZ2h0QWN0aW9uQnV0dG9uLm9uVGFwKCkpOyB9KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgyLCBcIkxhYmVsXCIsIDcpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yMiA9IGkwLsm1ybVuZXh0Q29udGV4dCgpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IyLnJpZ2h0QWN0aW9uQnV0dG9uLmljb24pO1xufSB9XG5leHBvcnQgY2xhc3MgSGVhZGVyQ29tcG9uZW50IHtcbiAgICBjb25zdHJ1Y3RvcihuYXZpZ2F0aW9uU2VydmljZSwgbGF5ZXJzU2VydmljZSkge1xuICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlID0gbmF2aWdhdGlvblNlcnZpY2U7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZSA9IGxheWVyc1NlcnZpY2U7XG4gICAgICAgIHRoaXMuaWNvbnMgPSBJY29ucztcbiAgICAgICAgdGhpcy5pb3MgPSBpc0lPUztcbiAgICB9XG4gICAgYmFjaygpIHtcbiAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5iYWNrKCk7XG4gICAgfVxuICAgIG9wZW5NZW51KCkge1xuICAgICAgICB0aGlzLmxheWVyc1NlcnZpY2Uub3Blbk1lbnUoKTtcbiAgICB9XG59XG5IZWFkZXJDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBIZWFkZXJDb21wb25lbnRfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgSGVhZGVyQ29tcG9uZW50KShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkxLk5hdmlnYXRpb25TZXJ2aWNlKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMS5MYXllcnNTZXJ2aWNlKSk7IH07XG5IZWFkZXJDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBIZWFkZXJDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLWhlYWRlclwiXV0sIGlucHV0czogeyBoZWFkZXJUaXRsZTogXCJoZWFkZXJUaXRsZVwiLCBoYXNCYWNrQnV0dG9uOiBcImhhc0JhY2tCdXR0b25cIiwgaGFzTWVudUJ1dHRvbjogXCJoYXNNZW51QnV0dG9uXCIsIHJpZ2h0QWN0aW9uQnV0dG9uOiBcInJpZ2h0QWN0aW9uQnV0dG9uXCIgfSwgZGVjbHM6IDYsIHZhcnM6IDgsIGNvbnN0czogW1tcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwidG9wXCIsIFwicm93XCIsIFwiMFwiLCBcInJvd3NcIiwgXCIqXCIsIFwiY29sdW1uc1wiLCBcIjYwLCAqLCBhdXRvLCAqLCA2MFwiLCAzLCBcImhlaWdodFwiLCBcInBhZGRpbmdcIl0sIFs0LCBcIm5nSWZcIl0sIFtcInJvd1wiLCBcIjBcIiwgXCJjb2xcIiwgXCIyXCIsIFwidmVydGljYWxBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIDEsIFwiYm9sZFwiLCBcInRleHQtY29sb3ItcHJpbWFyeVwiLCBcImZvbnQtc2l6ZS1oMlwiLCBcInRpdGxlXCIsIDMsIFwidGV4dFwiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjBcIiwgXCJwYWRkaW5nXCIsIFwiMTBcIiwgMywgXCJ0YXBcIl0sIFtcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwiY29sb3JcIiwgXCIjZmZmXCIsIFwiZm9udFNpemVcIiwgXCIyNVwiLCAxLCBcImlvbmljb25zXCIsIFwidGl0bGVcIiwgMywgXCJ0ZXh0XCJdLCBbXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCBcInRlc3RJRFwiLCBcIm5hdkJhckxlZnRCdXR0b25cIiwgMSwgXCJpb25pY29uc1wiLCBcImZvbnQtc2l6ZS1oMVwiLCBcInRleHQtY29sb3ItZ3JheVwiLCAzLCBcInRleHRcIl0sIFtcInJvd1wiLCBcIjBcIiwgXCJjb2xcIiwgXCI0XCIsIFwicGFkZGluZ1wiLCBcIjEwXCIsIDMsIFwidGFwXCJdLCBbXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCBcInRleHRBbGlnbm1lbnRcIiwgXCJyaWdodFwiLCBcInRlc3RJRFwiLCBcIm5hdkJhclJpZ2h0QnV0dG9uXCIsIDEsIFwiaW9uaWNvbnNcIiwgXCJmb250LXNpemUtaDFcIiwgXCJ0ZXh0LWNvbG9yLWdyYXlcIiwgMywgXCJ0ZXh0XCJdXSwgdGVtcGxhdGU6IGZ1bmN0aW9uIEhlYWRlckNvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCk7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSgxLCBIZWFkZXJDb21wb25lbnRfbmdfY29udGFpbmVyXzFfVGVtcGxhdGUsIDMsIDEsIFwibmctY29udGFpbmVyXCIsIDEpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoMiwgSGVhZGVyQ29tcG9uZW50X25nX2NvbnRhaW5lcl8yX1RlbXBsYXRlLCAzLCAxLCBcIm5nLWNvbnRhaW5lclwiLCAxKTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDMsIEhlYWRlckNvbXBvbmVudF9uZ19jb250YWluZXJfM19UZW1wbGF0ZSwgMywgMSwgXCJuZy1jb250YWluZXJcIiwgMSk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDQsIFwiTGFiZWxcIiwgMik7XG4gICAgICAgIGkwLsm1ybVwaXBlKDUsIFwidXBwZXJjYXNlXCIpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJoZWlnaHRcIiwgY3R4LmlvcyA/IDYwIDogODIpKFwicGFkZGluZ1wiLCBjdHguaW9zID8gXCIwXCIgOiBcIjIyIDAgMFwiKTtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgY3R4Lmhhc0JhY2tCdXR0b24pO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBjdHguaGFzTWVudUJ1dHRvbik7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ0lmXCIsIGN0eC5yaWdodEFjdGlvbkJ1dHRvbik7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGkwLsm1ybVwaXBlQmluZDEoNSwgNiwgY3R4LmhlYWRlclRpdGxlKSk7XG4gICAgfSB9LCBkZXBlbmRlbmNpZXM6IFtpMi5OZ0lmLCBpMi5VcHBlckNhc2VQaXBlXSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCB7IENBUkRTX0NPTVBPTkVOVFMgfSBmcm9tIFwiLi9jYXJkc1wiO1xuaW1wb3J0IHsgTEFZRVJTIH0gZnJvbSBcIi4vbGF5ZXJzXCI7XG5pbXBvcnQgeyBIZWFkZXJDb21wb25lbnQgfSBmcm9tIFwiLi9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudFwiO1xuaW1wb3J0IHsgTWVudUNvbXBvbmVudCB9IGZyb20gXCIuL21lbnUvbWVudS5jb21wb25lbnRcIjtcbmltcG9ydCB7IFRhZ0NvbXBvbmVudCB9IGZyb20gXCIuL3RhZy90YWcuY29tcG9uZW50XCI7XG5leHBvcnQgY29uc3QgQ09NUE9ORU5UUyA9IFtcbiAgICAuLi5DQVJEU19DT01QT05FTlRTLFxuICAgIC4uLkxBWUVSUyxcbiAgICBIZWFkZXJDb21wb25lbnQsXG4gICAgTWVudUNvbXBvbmVudCxcbiAgICBUYWdDb21wb25lbnQsXG5dO1xuZXhwb3J0ICogZnJvbSBcIi4vY2FyZHNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2xheWVyc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vaGVhZGVyL2hlYWRlci5jb21wb25lbnRcIjtcbmV4cG9ydCAqIGZyb20gXCIuL21lbnUvbWVudS5jb21wb25lbnRcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3RhZy90YWcuY29tcG9uZW50XCI7XG4iLCJpbXBvcnQgeyBKc0FuaW1hdGlvblNlcnZpY2UsIExheWVyc1NlcnZpY2UgfSBmcm9tIFwiQGFwcC9jb3JlXCI7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSBcInJ4anNcIjtcbmltcG9ydCB7IGRpc3RpbmN0VW50aWxDaGFuZ2VkLCBtYXAsIHNraXBXaGlsZSwgdGFrZVVudGlsLCB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAYXBwL2NvcmVcIjtcbmV4cG9ydCBjbGFzcyBBbGVydFBvcHVwQ29tcG9uZW50IHtcbiAgICBjb25zdHJ1Y3RvcihsYXllcnNTZXJ2aWNlLCBqc0FuaW1hdGlvblNlcnZpY2UpIHtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlID0gbGF5ZXJzU2VydmljZTtcbiAgICAgICAgdGhpcy5qc0FuaW1hdGlvblNlcnZpY2UgPSBqc0FuaW1hdGlvblNlcnZpY2U7XG4gICAgICAgIHRoaXMuX2lzQW5pbWF0aW5nID0gZmFsc2U7XG4gICAgICAgIHRoaXMuX2FsZXJ0SXNPcGVuID0gZmFsc2U7XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3kkID0gbmV3IFN1YmplY3QoKTtcbiAgICB9XG4gICAgbmdPbkluaXQoKSB7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZVxuICAgICAgICAgICAgLmdldExheWVycyQoKVxuICAgICAgICAgICAgLnBpcGUobWFwKChsYXllcnMpID0+IGxheWVycy5hbGVydFBvcHVwLmlzT3BlbiksIHNraXBXaGlsZSgoaXNPcGVuKSA9PiBpc09wZW4gPT09IHRoaXMuX2FsZXJ0SXNPcGVuKSwgZGlzdGluY3RVbnRpbENoYW5nZWQoKSwgdGFrZVVudGlsKHRoaXMuX2Rlc3Ryb3kkKSlcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKGlzT3BlbikgPT4ge1xuICAgICAgICAgICAgaWYgKGlzT3Blbikge1xuICAgICAgICAgICAgICAgIHRoaXMuX2FuaW1hdGVPcGVuKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLl9hbmltYXRlQ2xvc2UoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIG5nRG9DaGVjaygpIHtcbiAgICAgICAgLy8gd2l0aG91dCBjYWxsaW5nIHBvcG1vdGlvbiBvdXRzaWRlIG9mIEFuZ3VsYXIgWm9uZSwgdGhpcyB3aWxsIGJlIHRyaWdnZXJlZCBtdWx0aXBsZSB0aW1lc1xuICAgICAgICAvLyB1bmNvbW1lbnQgbmV4dCBsaW5lIHRvIHNlZSB0aGF0IGluIGVmZmVjdFxuICAgICAgICAvLyBjb25zb2xlLmxvZyhcIm5nRG9DaGVja1wiKTtcbiAgICB9XG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3kkLm5leHQodHJ1ZSk7XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3kkLmNvbXBsZXRlKCk7XG4gICAgfVxuICAgIHBvcHVwQ29udGFpbmVyTG9hZGVkKGFyZ3MpIHtcbiAgICAgICAgdGhpcy5fcG9wdXBDb250YWluZXIgPSBhcmdzLm9iamVjdDtcbiAgICAgICAgdGhpcy5fcG9wdXBDb250YWluZXIudmlzaWJpbGl0eSA9IFwiY29sbGFwc2VkXCI7XG4gICAgfVxuICAgIGNsb3NlKCkge1xuICAgICAgICBpZiAodGhpcy5faXNBbmltYXRpbmcpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxheWVyc1NlcnZpY2UuY2xvc2VBbGVydFBvcHVwKCk7XG4gICAgfVxuICAgIGFuaW1hdGVTdHJldGNoKCkge1xuICAgICAgICBpZiAodGhpcy5fcG9wdXBDb250YWluZXIpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLl9pc0FuaW1hdGluZykge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuX2lzQW5pbWF0aW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMuanNBbmltYXRpb25TZXJ2aWNlXG4gICAgICAgICAgICAgICAgLmFuaW1hdGVTdHJldGNoKHRoaXMuX3BvcHVwQ29udGFpbmVyKVxuICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLl9pc0FuaW1hdGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuX2lzQW5pbWF0aW5nID0gZmFsc2U7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBfYW5pbWF0ZU9wZW4oKSB7XG4gICAgICAgIHRoaXMuX3BvcHVwQ29udGFpbmVyLnNjYWxlWCA9IDA7XG4gICAgICAgIHRoaXMuX3BvcHVwQ29udGFpbmVyLnNjYWxlWSA9IDA7XG4gICAgICAgIHRoaXMuX3BvcHVwQ29udGFpbmVyLm9wYWNpdHkgPSAwO1xuICAgICAgICB0aGlzLl9wb3B1cENvbnRhaW5lci52aXNpYmlsaXR5ID0gXCJ2aXNpYmxlXCI7XG4gICAgICAgIHRoaXMuanNBbmltYXRpb25TZXJ2aWNlXG4gICAgICAgICAgICAuYW5pbWF0ZVdpdGhQb3Btb3Rpb24oXCIwLDAsMFwiLCBcIjEuMSwxLjEsMVwiLCAobGF0ZXN0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBbc2NhbGVYLCBzY2FsZVksIG9wYWNpdHldID0gbGF0ZXN0XG4gICAgICAgICAgICAgICAgLnNwbGl0KFwiLFwiKVxuICAgICAgICAgICAgICAgIC5tYXAoKHZhbCkgPT4gK3ZhbCk7XG4gICAgICAgICAgICB0aGlzLl9wb3B1cENvbnRhaW5lci5zY2FsZVggPSBzY2FsZVg7XG4gICAgICAgICAgICB0aGlzLl9wb3B1cENvbnRhaW5lci5zY2FsZVkgPSBzY2FsZVk7XG4gICAgICAgICAgICB0aGlzLl9wb3B1cENvbnRhaW5lci5vcGFjaXR5ID0gb3BhY2l0eTtcbiAgICAgICAgfSwgMjAwKVxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5qc0FuaW1hdGlvblNlcnZpY2VcbiAgICAgICAgICAgICAgICAuYW5pbWF0ZVNwcmluZ1dpdGhQb3Btb3Rpb24oXCIxLjEsMS4xXCIsIFwiMSwxXCIsIChsYXRlc3QpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBbc2NhbGVYLCBzY2FsZVldID0gbGF0ZXN0LnNwbGl0KFwiLFwiKS5tYXAoKHZhbCkgPT4gK3ZhbCk7XG4gICAgICAgICAgICAgICAgdGhpcy5fcG9wdXBDb250YWluZXIuc2NhbGVYID0gc2NhbGVYO1xuICAgICAgICAgICAgICAgIHRoaXMuX3BvcHVwQ29udGFpbmVyLnNjYWxlWSA9IHNjYWxlWTtcbiAgICAgICAgICAgIH0sIDEwMDApXG4gICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuX2FsZXJ0SXNPcGVuID0gdHJ1ZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgX2FuaW1hdGVDbG9zZSgpIHtcbiAgICAgICAgdGhpcy5qc0FuaW1hdGlvblNlcnZpY2VcbiAgICAgICAgICAgIC5hbmltYXRlV2l0aFBvcG1vdGlvbihcIjEsMSwxXCIsIFwiMCwwLDBcIiwgKGxhdGVzdCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgW3NjYWxlWCwgc2NhbGVZLCBvcGFjaXR5XSA9IGxhdGVzdFxuICAgICAgICAgICAgICAgIC5zcGxpdChcIixcIilcbiAgICAgICAgICAgICAgICAubWFwKCh2YWwpID0+ICt2YWwpO1xuICAgICAgICAgICAgdGhpcy5fcG9wdXBDb250YWluZXIuc2NhbGVYID0gc2NhbGVYO1xuICAgICAgICAgICAgdGhpcy5fcG9wdXBDb250YWluZXIuc2NhbGVZID0gc2NhbGVZO1xuICAgICAgICAgICAgdGhpcy5fcG9wdXBDb250YWluZXIub3BhY2l0eSA9IG9wYWNpdHk7XG4gICAgICAgIH0sIDIwMClcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuX3BvcHVwQ29udGFpbmVyLnZpc2liaWxpdHkgPSBcImNvbGxhcHNlZFwiO1xuICAgICAgICAgICAgdGhpcy5fYWxlcnRJc09wZW4gPSBmYWxzZTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuQWxlcnRQb3B1cENvbXBvbmVudC7JtWZhYyA9IGZ1bmN0aW9uIEFsZXJ0UG9wdXBDb21wb25lbnRfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgQWxlcnRQb3B1cENvbXBvbmVudCkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMS5MYXllcnNTZXJ2aWNlKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMS5Kc0FuaW1hdGlvblNlcnZpY2UpKTsgfTtcbkFsZXJ0UG9wdXBDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBBbGVydFBvcHVwQ29tcG9uZW50LCBzZWxlY3RvcnM6IFtbXCJucy1hbGVydC1wb3B1cFwiXV0sIGRlY2xzOiAxMiwgdmFyczogMCwgY29uc3RzOiBbW1wib3BhY2l0eVwiLCBcIjBcIiwgMSwgXCJ2LWNlbnRlclwiLCBcImgtY2VudGVyXCIsIDMsIFwibG9hZGVkXCJdLCBbXCJyb3dzXCIsIFwiYXV0bywgYXV0bywgYXV0bywgYXV0b1wiLCBcImFuZHJvaWRFbGV2YXRpb25cIiwgXCIxNVwiLCAxLCBcInAteGxcIiwgXCJiZy1jb2xvci1kZWZhdWx0XCIsIFwiYm9yZGVyLXJhZGl1cy1tXCIsIFwibS1sXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwidGV4dFwiLCBcIkFMRVJUISEhXCIsIDEsIFwiYm9sZFwiLCBcImZvbnQtc2l6ZS1oMVwiLCBcInRleHQtY29sb3ItcHJpbWFyeVwiLCBcInRleHQtY2VudGVyXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwidGV4dFdyYXBcIiwgXCJ0cnVlXCIsIDEsIFwiZm9udC1zaXplLWgzXCIsIFwidGV4dC1jb2xvci1ncmF5XCIsIFwidGV4dC1jZW50ZXJcIiwgXCJtLXQteGxcIl0sIFtcInRleHRcIiwgXCJZb3UganVzdCBnb3QgYSBib3VuY3kgcG9wdXAgcG93ZXJlZCBieSBcIl0sIFtcInRleHRcIiwgXCJQb3Btb3Rpb24gXCIsIDEsIFwibWVkaXVtXCIsIFwidGV4dC1jb2xvci1wcmltYXJ5XCJdLCBbXCJ0ZXh0XCIsIFwiaW4gXCJdLCBbXCJ0ZXh0XCIsIFwiTmF0aXZlc2NyaXB0XCIsIDEsIFwibWVkaXVtXCIsIFwidGV4dC1jb2xvci1wcmltYXJ5XCJdLCBbXCJ0ZXh0XCIsIFwiXFx1RDgzRVxcdURENzNcXHVEODNDXFx1REY4OVwiXSwgW1wicm93XCIsIFwiMlwiLCBcInRleHRcIiwgXCJhbmltYXRlXCIsIFwidGVzdElEXCIsIFwiYW5pbWF0ZUJ1dHRvblwiLCAxLCBcImJ1dHRvbi1wcmltYXJ5XCIsIFwibS10LXhsXCIsIFwibS14LWxcIiwgMywgXCJ0YXBcIl0sIFtcInJvd1wiLCBcIjNcIiwgXCJ0ZXh0XCIsIFwiY2xvc2VcIiwgXCJ0ZXN0SURcIiwgXCJjbG9zZUJ1dHRvblwiLCAxLCBcImJ1dHRvbi10ZXh0XCIsIFwibS10LXNcIiwgXCJtLXgtbFwiLCAzLCBcInRhcFwiXV0sIHRlbXBsYXRlOiBmdW5jdGlvbiBBbGVydFBvcHVwQ29tcG9uZW50X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDAsIFwiR3JpZExheW91dFwiLCAwKTtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwibG9hZGVkXCIsIGZ1bmN0aW9uIEFsZXJ0UG9wdXBDb21wb25lbnRfVGVtcGxhdGVfR3JpZExheW91dF9sb2FkZWRfMF9saXN0ZW5lcigkZXZlbnQpIHsgcmV0dXJuIGN0eC5wb3B1cENvbnRhaW5lckxvYWRlZCgkZXZlbnQpOyB9KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgxLCBcIkdyaWRMYXlvdXRcIiwgMSk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDIsIFwiTGFiZWxcIiwgMik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMywgXCJMYWJlbFwiLCAzKSg0LCBcIkZvcm1hdHRlZFN0cmluZ1wiKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoNSwgXCJTcGFuXCIsIDQpKDYsIFwiU3BhblwiLCA1KSg3LCBcIlNwYW5cIiwgNikoOCwgXCJTcGFuXCIsIDcpKDksIFwiU3BhblwiLCA4KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKSgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEwLCBcIkJ1dHRvblwiLCA5KTtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwidGFwXCIsIGZ1bmN0aW9uIEFsZXJ0UG9wdXBDb21wb25lbnRfVGVtcGxhdGVfQnV0dG9uX3RhcF8xMF9saXN0ZW5lcigpIHsgcmV0dXJuIGN0eC5hbmltYXRlU3RyZXRjaCgpOyB9KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgxMSwgXCJCdXR0b25cIiwgMTApO1xuICAgICAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gQWxlcnRQb3B1cENvbXBvbmVudF9UZW1wbGF0ZV9CdXR0b25fdGFwXzExX2xpc3RlbmVyKCkgeyByZXR1cm4gY3R4LmNsb3NlKCk7IH0pO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpKCkoKTtcbiAgICB9IH0sIGVuY2Fwc3VsYXRpb246IDIgfSk7XG4iLCJpbXBvcnQgeyBMYXllcnNTZXJ2aWNlLCBJY29ucywgRmFkZSB9IGZyb20gXCJAYXBwL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQGFwcC9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMiBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5pbXBvcnQgKiBhcyBpMyBmcm9tIFwiLi4vLi4vdGFnL3RhZy5jb21wb25lbnRcIjtcbmZ1bmN0aW9uIEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50X25nX2NvbnRhaW5lcl83X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyU3RhcnQoMCk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCgxLCBcIkNvbnRlbnRWaWV3XCIsIDEwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudCgyLCBcIm5zLXRhZ1wiLCAxMSk7XG4gICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgdGFnX3IyID0gY3R4LiRpbXBsaWNpdDtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0YWdUZXh0XCIsIHRhZ19yMi50ZXh0KShcInNlbGVjdGVkXCIsIHRhZ19yMi5zZWxlY3RlZCk7XG59IH1cbmZ1bmN0aW9uIEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50X25nX2NvbnRhaW5lcl8xMF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMSwgXCJDb250ZW50Vmlld1wiLCAxMCk7XG4gICAgaTAuybXJtWVsZW1lbnQoMiwgXCJucy10YWdcIiwgMTEpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IHRhZ19yMyA9IGN0eC4kaW1wbGljaXQ7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwidGFnVGV4dFwiLCB0YWdfcjMudGV4dCkoXCJzZWxlY3RlZFwiLCB0YWdfcjMuc2VsZWN0ZWQpO1xufSB9XG5leHBvcnQgY2xhc3MgRmlsdGVyQm90dG9tc2hlZXRDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKGxheWVyc1NlcnZpY2UpIHtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlID0gbGF5ZXJzU2VydmljZTtcbiAgICAgICAgdGhpcy5pY29ucyA9IEljb25zO1xuICAgICAgICB0aGlzLmxhbmd1YWdlVGFncyA9IFtcbiAgICAgICAgICAgIHsgdGV4dDogXCJFbmdsaXNoXCIsIHNlbGVjdGVkOiB0cnVlIH0sXG4gICAgICAgICAgICB7IHRleHQ6IFwiU3BhbmlzaFwiLCBzZWxlY3RlZDogZmFsc2UgfSxcbiAgICAgICAgICAgIHsgdGV4dDogXCJGcmVuY2hcIiwgc2VsZWN0ZWQ6IGZhbHNlIH0sXG4gICAgICAgIF07XG4gICAgICAgIHRoaXMuZHVyYXRpb25UYWdzID0gW1xuICAgICAgICAgICAgeyB0ZXh0OiBcIlNob3J0XCIsIHNlbGVjdGVkOiB0cnVlIH0sXG4gICAgICAgICAgICB7IHRleHQ6IFwiTWVkaXVtXCIsIHNlbGVjdGVkOiBmYWxzZSB9LFxuICAgICAgICAgICAgeyB0ZXh0OiBcIkxvbmdcIiwgc2VsZWN0ZWQ6IGZhbHNlIH0sXG4gICAgICAgIF07XG4gICAgfVxuICAgIHNoYWRlTG9hZGVkKGFyZ3MpIHtcbiAgICAgICAgdGhpcy5fc2hhZGUgPSBhcmdzLm9iamVjdDtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLl9zaGFkZS5hbmltYXRlKHtcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAxLFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAxNTAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSwgMTAwKTtcbiAgICB9XG4gICAgYXBwbHkoKSB7XG4gICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICB9XG4gICAgY2xvc2UoKSB7XG4gICAgICAgIHRoaXMuX3NoYWRlLmFuaW1hdGUoe1xuICAgICAgICAgICAgb3BhY2l0eTogMCxcbiAgICAgICAgICAgIGR1cmF0aW9uOiAxMDAsXG4gICAgICAgIH0pO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMubGF5ZXJzU2VydmljZS5jbG9zZUZpbHRlckJvdHRvbXNoZWV0KCk7XG4gICAgICAgIH0sIDUwKTtcbiAgICB9XG59XG5GaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudC7JtWZhYyA9IGZ1bmN0aW9uIEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50KShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkxLkxheWVyc1NlcnZpY2UpKTsgfTtcbkZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogRmlsdGVyQm90dG9tc2hlZXRDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLWZpbHRlci1ib3R0b21zaGVldFwiXV0sIGRlY2xzOiAxMywgdmFyczogMiwgY29uc3RzOiBbW1widmVydGljYWxBbGlnbm1lbnRcIiwgXCJib3R0b21cIiwgXCJyb3dzXCIsIFwiKlwiLCBcImhlaWdodFwiLCBcIjEwMCVcIl0sIFtcIm9wYWNpdHlcIiwgXCIwXCIsIFwicm93XCIsIFwiMFwiLCBcImJhY2tncm91bmRDb2xvclwiLCBcInJnYmEoMCwwLDAsMC4zKVwiLCAzLCBcImxvYWRlZFwiLCBcInRhcFwiXSwgW1wicm93XCIsIFwiMFwiLCBcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiYm90dG9tXCIsIFwicm93c1wiLCBcImF1dG8sIGF1dG8sIGF1dG9cIiwgXCJjb2x1bW5zXCIsIFwiKlwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjE1IDE1IDAgMFwiLCAxLCBcImJnLWNvbG9yLWRlZmF1bHRcIl0sIFtcInJvd1wiLCBcIjBcIiwgXCJjb2xcIiwgXCIwXCIsIFwidGV4dFwiLCBcIkZJTFRFUlwiLCBcIm1hcmdpblwiLCBcIjI1XCIsIFwiZm9udFNpemVcIiwgXCIzMFwiLCAxLCBcImJvbGRcIiwgXCJ0ZXh0LWNvbG9yLXByaW1hcnlcIl0sIFtcInJvd1wiLCBcIjFcIiwgXCJjb2xcIiwgXCIwXCIsIFwicGFkZGluZ1wiLCBcIjAgMjUgMjAgMjVcIl0sIFtcInRleHRcIiwgXCJMYW5ndWFnZVwiLCBcIm1hcmdpbkJvdHRvbVwiLCBcIjEwXCIsIFwiZm9udFNpemVcIiwgXCIyMFwiLCAxLCBcIm1lZGl1bVwiXSwgWzQsIFwibmdGb3JcIiwgXCJuZ0Zvck9mXCJdLCBbXCJ0ZXh0XCIsIFwiRHVyYXRpb25cIiwgXCJtYXJnaW5cIiwgXCIxNSAwIDEwIDBcIiwgXCJmb250U2l6ZVwiLCBcIjIwXCIsIDEsIFwibWVkaXVtXCJdLCBbXCJyb3dcIiwgXCIyXCIsIFwiY29sXCIsIFwiMFwiLCBcInBhZGRpbmdcIiwgXCIxNVwiLCAxLCBcImJnLWNvbG9yLXByaW1hcnlcIiwgMywgXCJ0YXBcIl0sIFtcInRleHRcIiwgXCJBUFBMWVwiLCBcInRleHRBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgXCJmb250U2l6ZVwiLCBcIjIwXCIsIFwiY29sb3JcIiwgXCIjZmZmXCIsIFwidGVzdElEXCIsIFwiYXBwbHlCdXR0b25cIiwgMSwgXCJtZWRpdW1cIl0sIFtcIm1hcmdpblJpZ2h0XCIsIFwiMTBcIl0sIFszLCBcInRhZ1RleHRcIiwgXCJzZWxlY3RlZFwiXV0sIHRlbXBsYXRlOiBmdW5jdGlvbiBGaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCkoMSwgXCJDb250ZW50Vmlld1wiLCAxKTtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwibG9hZGVkXCIsIGZ1bmN0aW9uIEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50X1RlbXBsYXRlX0NvbnRlbnRWaWV3X2xvYWRlZF8xX2xpc3RlbmVyKCRldmVudCkgeyByZXR1cm4gY3R4LnNoYWRlTG9hZGVkKCRldmVudCk7IH0pKFwidGFwXCIsIGZ1bmN0aW9uIEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50X1RlbXBsYXRlX0NvbnRlbnRWaWV3X3RhcF8xX2xpc3RlbmVyKCkgeyByZXR1cm4gY3R4LmNsb3NlKCk7IH0pO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDIsIFwiR3JpZExheW91dFwiLCAyKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMywgXCJMYWJlbFwiLCAzKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCg0LCBcIlN0YWNrTGF5b3V0XCIsIDQpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCg1LCBcIkxhYmVsXCIsIDUpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDYsIFwiRmxleGJveExheW91dFwiKTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDcsIEZpbHRlckJvdHRvbXNoZWV0Q29tcG9uZW50X25nX2NvbnRhaW5lcl83X1RlbXBsYXRlLCAzLCAyLCBcIm5nLWNvbnRhaW5lclwiLCA2KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoOCwgXCJMYWJlbFwiLCA3KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCg5LCBcIkZsZXhib3hMYXlvdXRcIik7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSgxMCwgRmlsdGVyQm90dG9tc2hlZXRDb21wb25lbnRfbmdfY29udGFpbmVyXzEwX1RlbXBsYXRlLCAzLCAyLCBcIm5nLWNvbnRhaW5lclwiLCA2KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKSgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDExLCBcIkdyaWRMYXlvdXRcIiwgOCk7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcInRhcFwiLCBmdW5jdGlvbiBGaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudF9UZW1wbGF0ZV9HcmlkTGF5b3V0X3RhcF8xMV9saXN0ZW5lcigpIHsgcmV0dXJuIGN0eC5hcHBseSgpOyB9KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoMTIsIFwiTGFiZWxcIiwgOSk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKSgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSg3KTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdGb3JPZlwiLCBjdHgubGFuZ3VhZ2VUYWdzKTtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMyk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nRm9yT2ZcIiwgY3R4LmR1cmF0aW9uVGFncyk7XG4gICAgfSB9LCBkZXBlbmRlbmNpZXM6IFtpMi5OZ0Zvck9mLCBpMy5UYWdDb21wb25lbnRdLCBlbmNhcHN1bGF0aW9uOiAyLCBkYXRhOiB7IGFuaW1hdGlvbjogW0ZhZGVdIH0gfSk7XG4iLCJpbXBvcnQgeyBRdWlja3ZpZXdCb3R0b21zaGVldENvbXBvbmVudCB9IGZyb20gXCIuL3F1aWNrdmlldy1ib3R0b21zaGVldC9xdWlja3ZpZXctYm90dG9tc2hlZXQuY29tcG9uZW50XCI7XG5pbXBvcnQgeyBTZWFyY2hCb3R0b21zaGVldENvbXBvbmVudCB9IGZyb20gXCIuL3NlYXJjaC1ib3R0b21zaGVldC9zZWFyY2gtYm90dG9tc2hlZXQuY29tcG9uZW50XCI7XG5pbXBvcnQgeyBGaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudCB9IGZyb20gXCIuL2ZpbHRlci1ib3R0b21zaGVldC9maWx0ZXItYm90dG9tc2hlZXQuY29tcG9uZW50XCI7XG5pbXBvcnQgeyBBbGVydFBvcHVwQ29tcG9uZW50IH0gZnJvbSAnLi9hbGVydC1wb3B1cC9hbGVydC1wb3B1cC5jb21wb25lbnQnO1xuZXhwb3J0IGNvbnN0IExBWUVSUyA9IFtcbiAgICBRdWlja3ZpZXdCb3R0b21zaGVldENvbXBvbmVudCxcbiAgICBTZWFyY2hCb3R0b21zaGVldENvbXBvbmVudCxcbiAgICBGaWx0ZXJCb3R0b21zaGVldENvbXBvbmVudCxcbiAgICBBbGVydFBvcHVwQ29tcG9uZW50XG5dO1xuZXhwb3J0ICogZnJvbSBcIi4vcXVpY2t2aWV3LWJvdHRvbXNoZWV0L3F1aWNrdmlldy1ib3R0b21zaGVldC5jb21wb25lbnRcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3NlYXJjaC1ib3R0b21zaGVldC9zZWFyY2gtYm90dG9tc2hlZXQuY29tcG9uZW50XCI7XG5leHBvcnQgKiBmcm9tIFwiLi9maWx0ZXItYm90dG9tc2hlZXQvZmlsdGVyLWJvdHRvbXNoZWV0LmNvbXBvbmVudFwiO1xuZXhwb3J0ICogZnJvbSAnLi9hbGVydC1wb3B1cC9hbGVydC1wb3B1cC5jb21wb25lbnQnO1xuIiwiaW1wb3J0IHsgdGFwLCBtYXAsIHN3aXRjaE1hcCB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuaW1wb3J0IHsgU3RvcmUgfSBmcm9tIFwiQG5neHMvc3RvcmVcIjtcbmltcG9ydCB7IExheWVyc1NlcnZpY2UsIEljb25zLCBOYXZpZ2F0aW9uU2VydmljZSwgUm91dGVzLCBQcm9kdWN0U3RhdGUsIH0gZnJvbSBcIkBhcHAvY29yZVwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAbmd4cy9zdG9yZVwiO1xuaW1wb3J0ICogYXMgaTIgZnJvbSBcIkBhcHAvY29yZVwiO1xuaW1wb3J0ICogYXMgaTMgZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0ICogYXMgaTQgZnJvbSBcIi4uLy4uL2NhcmRzL3RodW1ibmFpbC1jYXJkL3RodW1ibmFpbC1jYXJkLmNvbXBvbmVudFwiO1xuZnVuY3Rpb24gUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnRfbmdfY29udGFpbmVyXzFfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiQ29udGVudFZpZXdcIiwgNSk7XG4gICAgaTAuybXJtWVsZW1lbnQoMiwgXCJucy10aHVtYm5haWwtY2FyZFwiLCA2KTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMywgXCJTdGFja0xheW91dFwiLCA3KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCg0LCBcIkxhYmVsXCIsIDgpKDUsIFwiTGFiZWxcIiwgOSk7XG4gICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lckVuZCgpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgcHJvZHVjdERldGFpbHNfcjEgPSBjdHgubmdJZjtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJpbWFnZVNyY1wiLCBwcm9kdWN0RGV0YWlsc19yMS5pbWFnZS50aHVtYm5haWwpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgcHJvZHVjdERldGFpbHNfcjEudGl0bGUpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgcHJvZHVjdERldGFpbHNfcjEuZGVzY3JpcHRpb24uc3Vic3RyaW5nKDAsIDkwKSArIFwiLi4uXCIpO1xufSB9XG5leHBvcnQgY2xhc3MgUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHN0b3JlLCBsYXllcnNTZXJ2aWNlLCBuYXZpZ2F0aW9uU2VydmljZSkge1xuICAgICAgICB0aGlzLnN0b3JlID0gc3RvcmU7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZSA9IGxheWVyc1NlcnZpY2U7XG4gICAgICAgIHRoaXMubmF2aWdhdGlvblNlcnZpY2UgPSBuYXZpZ2F0aW9uU2VydmljZTtcbiAgICAgICAgdGhpcy5zdGF0ZSQgPSB0aGlzLmxheWVyc1NlcnZpY2VcbiAgICAgICAgICAgIC5nZXRMYXllcnMkKClcbiAgICAgICAgICAgIC5waXBlKG1hcCgobGF5ZXJzKSA9PiBsYXllcnMucXVpY2t2aWV3Qm90dG9tc2hlZXQpKTtcbiAgICAgICAgdGhpcy5wcm9kdWN0RGV0YWlscyQgPSB0aGlzLnN0YXRlJC5waXBlKG1hcCgoc3RhdGUpID0+IHN0YXRlLnByb2R1Y3RJZCksIHRhcCgocHJvZHVjdElkKSA9PiAodGhpcy5fcHJvZHVjdElkID0gcHJvZHVjdElkKSksIHN3aXRjaE1hcCgocHJvZHVjdElkKSA9PiB0aGlzLnN0b3JlLnNlbGVjdChQcm9kdWN0U3RhdGUucHJvZHVjdEJ5SWQocHJvZHVjdElkKSkpKTtcbiAgICAgICAgdGhpcy5pY29ucyA9IEljb25zO1xuICAgIH1cbiAgICBjbG9zZSgpIHtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlLmNsb3NlUXVpY2t2aWV3Qm90dG9tc2hlZXQoKTtcbiAgICB9XG4gICAgbmF2aWdhdGVUb1Byb2R1Y3REZXRhaWxzKCkge1xuICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlLm5hdmlnYXRlKFJvdXRlcy5kZXRhaWxzLCB7IGlkOiB0aGlzLl9wcm9kdWN0SWQgfSk7XG4gICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICB9XG59XG5RdWlja3ZpZXdCb3R0b21zaGVldENvbXBvbmVudC7JtWZhYyA9IGZ1bmN0aW9uIFF1aWNrdmlld0JvdHRvbXNoZWV0Q29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IFF1aWNrdmlld0JvdHRvbXNoZWV0Q29tcG9uZW50KShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkxLlN0b3JlKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMi5MYXllcnNTZXJ2aWNlKSwgaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMi5OYXZpZ2F0aW9uU2VydmljZSkpOyB9O1xuUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBRdWlja3ZpZXdCb3R0b21zaGVldENvbXBvbmVudCwgc2VsZWN0b3JzOiBbW1wibnMtcXVpY2t2aWV3LWJvdHRvbXNoZWV0XCJdXSwgZGVjbHM6IDYsIHZhcnM6IDQsIGNvbnN0czogW1tcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiYm90dG9tXCIsIFwicGFkZGluZ1wiLCBcIjIwXCIsIFwicm93c1wiLCBcImF1dG8sIGF1dG9cIiwgXCJjb2x1bW5zXCIsIFwiYXV0bywgKlwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjE1IDE1IDAgMFwiLCAxLCBcImJnLWNvbG9yLWRlZmF1bHRcIiwgMywgXCJ0YXBcIl0sIFs0LCBcIm5nSWZcIl0sIFtcInJvd1wiLCBcIjFcIiwgXCJjb2xcIiwgXCIwXCIsIFwiY29sU3BhblwiLCBcIjJcIiwgXCJyb3dzXCIsIFwiYXV0b1wiLCBcImNvbHVtbnNcIiwgXCJhdXRvLCAqXCIsIFwicGFkZGluZ1wiLCBcIjEwIDUgMCA1XCIsIDEsIFwibS10LWxcIiwgXCJib3JkZXItdC1ncmF5XCJdLCBbXCJjb2xcIiwgXCIwXCIsIFwiZm9udFNpemVcIiwgXCIyMFwiLCBcIm1hcmdpblJpZ2h0XCIsIFwiNVwiLCAxLCBcImlvbmljb25zXCIsIFwidGV4dC1jb2xvci1ncmF5XCIsIDMsIFwidGV4dFwiXSwgW1wiY29sXCIsIFwiMVwiLCBcInRleHRcIiwgXCJEZXRhaWxzIGFuZCBNb3JlXCIsIFwiZm9udFNpemVcIiwgXCIxOFwiLCAxLCBcInRleHQtY29sb3ItZ3JheVwiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjBcIl0sIFszLCBcImltYWdlU3JjXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiMVwiLCBcInBhZGRpbmdcIiwgXCIxMCAxMCAxNSAxMFwiXSwgW1wiZm9udFNpemVcIiwgXCIzMFwiLCBcInRleHRXcmFwXCIsIFwidHJ1ZVwiLCAxLCBcImJvbGRcIiwgMywgXCJ0ZXh0XCJdLCBbXCJ0ZXh0V3JhcFwiLCBcInRydWVcIiwgXCJmb250U2l6ZVwiLCBcIjE4XCIsIDEsIFwidGV4dC1jb2xvci1ncmF5XCIsIDMsIFwidGV4dFwiXV0sIHRlbXBsYXRlOiBmdW5jdGlvbiBRdWlja3ZpZXdCb3R0b21zaGVldENvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCk7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcInRhcFwiLCBmdW5jdGlvbiBRdWlja3ZpZXdCb3R0b21zaGVldENvbXBvbmVudF9UZW1wbGF0ZV9HcmlkTGF5b3V0X3RhcF8wX2xpc3RlbmVyKCkgeyByZXR1cm4gY3R4Lm5hdmlnYXRlVG9Qcm9kdWN0RGV0YWlscygpOyB9KTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDEsIFF1aWNrdmlld0JvdHRvbXNoZWV0Q29tcG9uZW50X25nX2NvbnRhaW5lcl8xX1RlbXBsYXRlLCA2LCAzLCBcIm5nLWNvbnRhaW5lclwiLCAxKTtcbiAgICAgICAgaTAuybXJtXBpcGUoMiwgXCJhc3luY1wiKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgzLCBcIkdyaWRMYXlvdXRcIiwgMik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDQsIFwiTGFiZWxcIiwgMykoNSwgXCJMYWJlbFwiLCA0KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKSgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBpMC7Jtcm1cGlwZUJpbmQxKDIsIDIsIGN0eC5wcm9kdWN0RGV0YWlscyQpKTtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMyk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4Lmljb25zLmluZm8pO1xuICAgIH0gfSwgZGVwZW5kZW5jaWVzOiBbaTMuTmdJZiwgaTQuVGh1bWJuYWlsQ2FyZENvbXBvbmVudCwgaTMuQXN5bmNQaXBlXSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCB7IERhdGFTZXJ2aWNlLCBMYXllcnNTZXJ2aWNlLCBJY29ucywgTmF2aWdhdGlvblNlcnZpY2UsIFJvdXRlcywgfSBmcm9tIFwiQGFwcC9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0ICogYXMgaTEgZnJvbSBcIkBhcHAvY29yZVwiO1xuZXhwb3J0IGNsYXNzIFNlYXJjaEJvdHRvbXNoZWV0Q29tcG9uZW50IHtcbiAgICAvLyBjYXRlZ29yaWVzJCA9IHRoaXMuZGF0YVNlcnZpY2UuZ2V0Q2F0ZWdvcmllcygpO1xuICAgIC8vIHNlYXJjaFJlc3VsdCQgPSB0aGlzLmRhdGFTZXJ2aWNlLmdldFJlY29tbWVuZGVkTW92aWVzKCk7XG4gICAgY29uc3RydWN0b3IoZGF0YVNlcnZpY2UsIGxheWVyc1NlcnZpY2UsIG5hdmlnYXRpb25TZXJ2aWNlKSB7XG4gICAgICAgIHRoaXMuZGF0YVNlcnZpY2UgPSBkYXRhU2VydmljZTtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlID0gbGF5ZXJzU2VydmljZTtcbiAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZSA9IG5hdmlnYXRpb25TZXJ2aWNlO1xuICAgICAgICAvLyBAU2VsZWN0KFByb2R1Y3RTdGF0ZS5jYXRlZ29yaWVzKSBjYXRlZ29yaWVzJDtcbiAgICAgICAgdGhpcy5pY29ucyA9IEljb25zO1xuICAgIH1cbiAgICBvcGVuRmlsdGVyQm90dG9tc2hlZXQoKSB7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZS5vcGVuRmlsdGVyQm90dG9tc2hlZXQoKTtcbiAgICB9XG4gICAgY2xvc2UoKSB7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZS5jbG9zZVNlYXJjaEJvdHRvbXNoZWV0KCk7XG4gICAgfVxuICAgIG5hdmlnYXRlVG9Nb3ZpZURldGFpbHMobW92aWVJZCkge1xuICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlLm5hdmlnYXRlKFJvdXRlcy5kZXRhaWxzLCB7IGlkOiBtb3ZpZUlkIH0pO1xuICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgfVxufVxuU2VhcmNoQm90dG9tc2hlZXRDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBTZWFyY2hCb3R0b21zaGVldENvbXBvbmVudF9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBTZWFyY2hCb3R0b21zaGVldENvbXBvbmVudCkoaTAuybXJtWRpcmVjdGl2ZUluamVjdChpMS5EYXRhU2VydmljZSksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTEuTGF5ZXJzU2VydmljZSksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTEuTmF2aWdhdGlvblNlcnZpY2UpKTsgfTtcblNlYXJjaEJvdHRvbXNoZWV0Q29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogU2VhcmNoQm90dG9tc2hlZXRDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLXNlYXJjaC1ib3R0b21zaGVldFwiXV0sIGRlY2xzOiAxMSwgdmFyczogMiwgY29uc3RzOiBbW1widmVydGljYWxBbGlnbm1lbnRcIiwgXCJib3R0b21cIiwgXCJwYWRkaW5nVG9wXCIsIFwiMjVcIiwgXCJyb3dzXCIsIFwiYXV0bywgYXV0bywgYXV0bywgYXV0b1wiLCBcImNvbHVtbnNcIiwgXCIqLCBhdXRvXCIsIFwiYm9yZGVyUmFkaXVzXCIsIFwiMTUgMTUgMCAwXCIsIDEsIFwiYmctY29sb3ItZGVmYXVsdFwiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjBcIiwgXCJtYXJnaW5cIiwgXCIwIDI1XCIsIFwidGV4dFwiLCBcIlNFQVJDSFwiLCBcImZvbnRTaXplXCIsIFwiMzBcIiwgXCJ0ZXN0SURcIiwgXCJzZWFyY2hUaXRsZVwiLCAxLCBcImJvbGRcIiwgXCJ0ZXh0LWNvbG9yLXByaW1hcnlcIl0sIFtcInJvd1wiLCBcIjBcIiwgXCJjb2xcIiwgXCIxXCIsIFwicGFkZGluZ1wiLCBcIjEwXCIsIFwibWFyZ2luXCIsIFwiMCAyNVwiLCAzLCBcInRhcFwiXSwgW1widmVydGljYWxBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgXCJ0ZXh0QWxpZ25tZW50XCIsIFwicmlnaHRcIiwgXCJjb2xvclwiLCBcIiM0NDRcIiwgXCJmb250U2l6ZVwiLCBcIjI1XCIsIFwidGVzdElEXCIsIFwic2VhcmNoSWNvblwiLCAxLCBcImlvbmljb25zXCIsIDMsIFwidGV4dFwiXSwgW1wicm93XCIsIFwiMVwiLCBcImNvbFwiLCBcIjBcIiwgXCJjb2xTcGFuXCIsIFwiMlwiLCBcImNvbHVtbnNcIiwgXCJhdXRvLCAqXCIsIFwibWFyZ2luXCIsIFwiMTUgMjUgMCAyNVwiLCBcInBhZGRpbmdcIiwgXCIxMFwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjEwXCIsIFwiYmFja2dyb3VuZENvbG9yXCIsIFwiI2VlZVwiXSwgW1wiY29sXCIsIFwiMFwiLCBcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwiY29sb3JcIiwgXCIjNzc3XCIsIFwiZm9udFNpemVcIiwgXCIyNVwiLCAxLCBcImlvbmljb25zXCIsIDMsIFwidGV4dFwiXSwgW1wiY29sXCIsIFwiMVwiLCBcIm1hcmdpbkxlZnRcIiwgXCIxMFwiLCBcImZvbnRTaXplXCIsIFwiMjBcIiwgXCJoaW50XCIsIFwiQmF0bWFuXCIsIFwidGVzdElEXCIsIFwiaW5wdXRcIl0sIFtcInJvd1wiLCBcIjJcIiwgXCJjb2xcIiwgXCIwXCIsIFwiY29sU3BhblwiLCBcIjJcIiwgXCJvcmllbnRhdGlvblwiLCBcImhvcml6b250YWxcIiwgXCJ3aWR0aFwiLCBcIjEwMCVcIl0sIFtcIm9yaWVudGF0aW9uXCIsIFwiaG9yaXpvbnRhbFwiLCBcInBhZGRpbmdcIiwgXCIxMCAyNVwiXSwgW1wicm93XCIsIFwiM1wiLCBcImNvbFwiLCBcIjBcIiwgXCJjb2xTcGFuXCIsIFwiMlwiLCBcImhlaWdodFwiLCBcIjQwMFwiXSwgW1wibWFyZ2luXCIsIFwiMTAgMjUgMjUgMjVcIl1dLCB0ZW1wbGF0ZTogZnVuY3Rpb24gU2VhcmNoQm90dG9tc2hlZXRDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJHcmlkTGF5b3V0XCIsIDApO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgxLCBcIkxhYmVsXCIsIDEpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDIsIFwiR3JpZExheW91dFwiLCAyKTtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwidGFwXCIsIGZ1bmN0aW9uIFNlYXJjaEJvdHRvbXNoZWV0Q29tcG9uZW50X1RlbXBsYXRlX0dyaWRMYXlvdXRfdGFwXzJfbGlzdGVuZXIoKSB7IHJldHVybiBjdHgub3BlbkZpbHRlckJvdHRvbXNoZWV0KCk7IH0pO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgzLCBcIkxhYmVsXCIsIDMpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDQsIFwiR3JpZExheW91dFwiLCA0KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoNSwgXCJMYWJlbFwiLCA1KSg2LCBcIlRleHRGaWVsZFwiLCA2KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCg3LCBcIlNjcm9sbFZpZXdcIiwgNyk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDgsIFwiU3RhY2tMYXlvdXRcIiwgOCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoOSwgXCJTY3JvbGxWaWV3XCIsIDkpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgxMCwgXCJTdGFja0xheW91dFwiLCAxMCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKTtcbiAgICB9IGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMyk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4Lmljb25zLmZpbHRlcik7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGN0eC5pY29ucy5zZWFyY2gpO1xuICAgIH0gfSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCB7IExheWVyc1NlcnZpY2UsIFNsaWRlVXBGYWRlU3RhZ2dlciwgSWNvbnMsIE5hdmlnYXRpb25TZXJ2aWNlLCBSb3V0ZXMsIH0gZnJvbSBcIkBhcHAvY29yZVwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAYXBwL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkyIGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmZ1bmN0aW9uIE1lbnVDb21wb25lbnRfbmdfY29udGFpbmVyXzRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgY29uc3QgX3IzID0gaTAuybXJtWdldEN1cnJlbnRWaWV3KCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiR3JpZExheW91dFwiLCA1KTtcbiAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gTWVudUNvbXBvbmVudF9uZ19jb250YWluZXJfNF9UZW1wbGF0ZV9HcmlkTGF5b3V0X3RhcF8xX2xpc3RlbmVyKCkgeyBjb25zdCByZXN0b3JlZEN0eCA9IGkwLsm1ybVyZXN0b3JlVmlldyhfcjMpOyBjb25zdCBvcHRpb25fcjEgPSByZXN0b3JlZEN0eC4kaW1wbGljaXQ7IHJldHVybiBpMC7Jtcm1cmVzZXRWaWV3KG9wdGlvbl9yMS5vblRhcCAmJiBvcHRpb25fcjEub25UYXAoKSk7IH0pO1xuICAgIGkwLsm1ybVlbGVtZW50KDIsIFwiTGFiZWxcIiwgNikoMywgXCJMYWJlbFwiLCA3KTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBvcHRpb25fcjEgPSBjdHguJGltcGxpY2l0O1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgb3B0aW9uX3IxLmljb24pO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgb3B0aW9uX3IxLmRpc3BsYXlOYW1lKTtcbn0gfVxuZXhwb3J0IGNsYXNzIE1lbnVDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKGxheWVyc1NlcnZpY2UsIG5hdmlnYXRpb25TZXJ2aWNlKSB7XG4gICAgICAgIHRoaXMubGF5ZXJzU2VydmljZSA9IGxheWVyc1NlcnZpY2U7XG4gICAgICAgIHRoaXMubmF2aWdhdGlvblNlcnZpY2UgPSBuYXZpZ2F0aW9uU2VydmljZTtcbiAgICAgICAgdGhpcy5pY29ucyA9IEljb25zO1xuICAgICAgICB0aGlzLm1lbnVPcHRpb25zID0gW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGRpc3BsYXlOYW1lOiBcIkhvbWVcIixcbiAgICAgICAgICAgICAgICBpY29uOiB0aGlzLmljb25zLmhvbWUsXG4gICAgICAgICAgICAgICAgb25UYXA6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5uYXZpZ2F0ZShSb3V0ZXMuaG9tZSwgbnVsbCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VNZW51KCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZGlzcGxheU5hbWU6IFwiUHJvZmlsZVwiLFxuICAgICAgICAgICAgICAgIGljb246IHRoaXMuaWNvbnMuYWNjb3VudCxcbiAgICAgICAgICAgICAgICBvblRhcDogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlLm5hdmlnYXRlKFJvdXRlcy5wcm9maWxlLCBudWxsLCB0cnVlKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZU1lbnUoKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHsgZGlzcGxheU5hbWU6IFwiRG93bmxvYWRzXCIsIGljb246IHRoaXMuaWNvbnMuZG93bmxvYWRzIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZGlzcGxheU5hbWU6IFwiU2V0dGluZ3NcIixcbiAgICAgICAgICAgICAgICBpY29uOiB0aGlzLmljb25zLnNldHRpbmdzLFxuICAgICAgICAgICAgICAgIG9uVGFwOiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvblNlcnZpY2UubmF2aWdhdGUoUm91dGVzLmNvbmZpZywgbnVsbCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VNZW51KCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7IGRpc3BsYXlOYW1lOiBcIkhlbHBcIiwgaWNvbjogdGhpcy5pY29ucy5oZWxwIH0sXG4gICAgICAgIF07XG4gICAgfVxuICAgIGNsb3NlTWVudSgpIHtcbiAgICAgICAgdGhpcy5sYXllcnNTZXJ2aWNlLmNsb3NlTWVudSgpO1xuICAgIH1cbn1cbk1lbnVDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBNZW51Q29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IE1lbnVDb21wb25lbnQpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTEuTGF5ZXJzU2VydmljZSksIGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTEuTmF2aWdhdGlvblNlcnZpY2UpKTsgfTtcbk1lbnVDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBNZW51Q29tcG9uZW50LCBzZWxlY3RvcnM6IFtbXCJucy1tZW51XCJdXSwgZGVjbHM6IDUsIHZhcnM6IDIsIGNvbnN0czogW1tcInBhZGRpbmdUb3BcIiwgXCIzMFwiXSwgW1wiY29sb3JcIiwgXCIjNDQ0XCIsIFwiZm9udFNpemVcIiwgXCI0MFwiLCBcInBhZGRpbmdcIiwgXCIyMFwiLCAxLCBcImlvbmljb25zXCIsIDMsIFwidGV4dFwiLCBcInRhcFwiXSwgW1wibWFyZ2luXCIsIFwiMTUgMjAgMCAyNVwiLCBcInRleHRcIiwgXCJIZWxsb1wiLCBcImZvbnRTaXplXCIsIFwiMjVcIiwgMSwgXCJib2xkXCIsIFwidGV4dC1jb2xvci1ncmF5XCJdLCBbXCJtYXJnaW5cIiwgXCItNSAyMCAyMCAyNVwiLCBcInRleHRcIiwgXCJMdWNhXCIsIFwiZm9udFNpemVcIiwgXCI0MFwiLCAxLCBcImJvbGRcIiwgXCJ0ZXh0LWNvbG9yLWdyYXlcIl0sIFs0LCBcIm5nRm9yXCIsIFwibmdGb3JPZlwiXSwgW1wiY29sdW1uc1wiLCBcIjQwLCAxMCwgKlwiLCBcInJvd3NcIiwgXCJhdXRvXCIsIFwicGFkZGluZ1wiLCBcIjEwIDE1IDEwIDI1XCIsIDMsIFwidGFwXCJdLCBbXCJjb2xcIiwgXCIwXCIsIFwiZm9udFNpemVcIiwgXCIyNVwiLCAxLCBcImlvbmljb25zXCIsIFwidGV4dC1jb2xvci1ncmF5XCIsIDMsIFwidGV4dFwiXSwgW1wiY29sXCIsIFwiMlwiLCBcImZvbnRTaXplXCIsIFwiMjBcIiwgMSwgXCJ0ZXh0LWNvbG9yLWdyYXlcIiwgMywgXCJ0ZXh0XCJdXSwgdGVtcGxhdGU6IGZ1bmN0aW9uIE1lbnVDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJTdGFja0xheW91dFwiLCAwKSgxLCBcIkxhYmVsXCIsIDEpO1xuICAgICAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gTWVudUNvbXBvbmVudF9UZW1wbGF0ZV9MYWJlbF90YXBfMV9saXN0ZW5lcigpIHsgcmV0dXJuIGN0eC5jbG9zZU1lbnUoKTsgfSk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDIsIFwiTGFiZWxcIiwgMikoMywgXCJMYWJlbFwiLCAzKTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDQsIE1lbnVDb21wb25lbnRfbmdfY29udGFpbmVyXzRfVGVtcGxhdGUsIDQsIDIsIFwibmctY29udGFpbmVyXCIsIDQpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHguaWNvbnMuY2xvc2UpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdGb3JPZlwiLCBjdHgubWVudU9wdGlvbnMpO1xuICAgIH0gfSwgZGVwZW5kZW5jaWVzOiBbaTIuTmdGb3JPZl0sIGVuY2Fwc3VsYXRpb246IDIsIGRhdGE6IHsgYW5pbWF0aW9uOiBbU2xpZGVVcEZhZGVTdGFnZ2VyXSB9IH0pO1xuIiwiaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmV4cG9ydCBjbGFzcyBUYWdDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnNlbGVjdGVkID0gZmFsc2U7XG4gICAgfVxufVxuVGFnQ29tcG9uZW50Lsm1ZmFjID0gZnVuY3Rpb24gVGFnQ29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IFRhZ0NvbXBvbmVudCkoKTsgfTtcblRhZ0NvbXBvbmVudC7JtWNtcCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUNvbXBvbmVudCh7IHR5cGU6IFRhZ0NvbXBvbmVudCwgc2VsZWN0b3JzOiBbW1wibnMtdGFnXCJdXSwgaW5wdXRzOiB7IHRhZ1RleHQ6IFwidGFnVGV4dFwiLCBzZWxlY3RlZDogXCJzZWxlY3RlZFwiIH0sIGRlY2xzOiAyLCB2YXJzOiA5LCBjb25zdHM6IFtbXCJyb3dzXCIsIFwiYXV0b1wiLCBcImNvbHVtbnNcIiwgXCJhdXRvXCIsIFwicGFkZGluZ1wiLCBcIjggMTVcIiwgXCJib3JkZXJSYWRpdXNcIiwgXCIyMFwiLCAxLCBcImJvcmRlci1wcmltYXJ5XCJdLCBbXCJmb250U2l6ZVwiLCBcIjE4XCIsIDEsIFwibWVkaXVtXCIsIDMsIFwidGV4dFwiXV0sIHRlbXBsYXRlOiBmdW5jdGlvbiBUYWdDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJHcmlkTGF5b3V0XCIsIDApO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgxLCBcIkxhYmVsXCIsIDEpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1Y2xhc3NQcm9wKFwiYmctY29sb3ItcHJpbWFyeVwiLCBjdHguc2VsZWN0ZWQpKFwiYmctY29sb3ItZGVmYXVsdFwiLCAhY3R4LnNlbGVjdGVkKTtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgICAgIGkwLsm1ybVjbGFzc1Byb3AoXCJ0ZXh0LWNvbG9yLWxpZ2h0XCIsIGN0eC5zZWxlY3RlZCkoXCJ0ZXh0LWNvbG9yLXByaW1hcnlcIiwgIWN0eC5zZWxlY3RlZCk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4LnRhZ1RleHQpO1xuICAgIH0gfSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImV4cG9ydCAqIGZyb20gXCIuL2NvbXBvbmVudHNcIjtcbmV4cG9ydCB7IFNoYXJlZE1vZHVsZSB9IGZyb20gXCIuL3NoYXJlZC5tb2R1bGVcIjtcbiIsImltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSB9IGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiLi9jb21wb25lbnRzL2NhcmRzL3RodW1ibmFpbC1jYXJkL3RodW1ibmFpbC1jYXJkLmNvbXBvbmVudFwiO1xuaW1wb3J0ICogYXMgaTIgZnJvbSBcIi4vY29tcG9uZW50cy9jYXJkcy9zZWFyY2gtY2FyZC9zZWFyY2gtY2FyZC5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGkzIGZyb20gXCIuL2NvbXBvbmVudHMvbGF5ZXJzL3F1aWNrdmlldy1ib3R0b21zaGVldC9xdWlja3ZpZXctYm90dG9tc2hlZXQuY29tcG9uZW50XCI7XG5pbXBvcnQgKiBhcyBpNCBmcm9tIFwiLi9jb21wb25lbnRzL2xheWVycy9zZWFyY2gtYm90dG9tc2hlZXQvc2VhcmNoLWJvdHRvbXNoZWV0LmNvbXBvbmVudFwiO1xuaW1wb3J0ICogYXMgaTUgZnJvbSBcIi4vY29tcG9uZW50cy9sYXllcnMvZmlsdGVyLWJvdHRvbXNoZWV0L2ZpbHRlci1ib3R0b21zaGVldC5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGk2IGZyb20gXCIuL2NvbXBvbmVudHMvbGF5ZXJzL2FsZXJ0LXBvcHVwL2FsZXJ0LXBvcHVwLmNvbXBvbmVudFwiO1xuaW1wb3J0ICogYXMgaTcgZnJvbSBcIi4vY29tcG9uZW50cy9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudFwiO1xuaW1wb3J0ICogYXMgaTggZnJvbSBcIi4vY29tcG9uZW50cy9tZW51L21lbnUuY29tcG9uZW50XCI7XG5pbXBvcnQgKiBhcyBpOSBmcm9tIFwiLi9jb21wb25lbnRzL3RhZy90YWcuY29tcG9uZW50XCI7XG5leHBvcnQgY2xhc3MgU2hhcmVkTW9kdWxlIHtcbn1cblNoYXJlZE1vZHVsZS7JtWZhYyA9IGZ1bmN0aW9uIFNoYXJlZE1vZHVsZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBTaGFyZWRNb2R1bGUpKCk7IH07XG5TaGFyZWRNb2R1bGUuybVtb2QgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVOZ01vZHVsZSh7IHR5cGU6IFNoYXJlZE1vZHVsZSB9KTtcblNoYXJlZE1vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW0NvbW1vbk1vZHVsZSwgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlXSB9KTtcbiIsIi8qKlxuICogTmF0aXZlU2NyaXB0IFBvbHlmaWxsc1xuICovXG4vLyBJbnN0YWxsIEBuYXRpdmVzY3JpcHQvY29yZSBwb2x5ZmlsbHMgKFhIUiwgc2V0VGltZW91dCwgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKVxuaW1wb3J0ICdAbmF0aXZlc2NyaXB0L2NvcmUvZ2xvYmFscyc7XG4vLyBJbnN0YWxsIEBuYXRpdmVzY3JpcHQvYW5ndWxhciBzcGVjaWZpYyBwb2x5ZmlsbHNcbmltcG9ydCAnQG5hdGl2ZXNjcmlwdC9hbmd1bGFyL3BvbHlmaWxscyc7XG4vKipcbiAqIFpvbmUuanMgYW5kIHBhdGNoZXNcbiAqL1xuLy8gQWRkIHByZS16b25lLmpzIHBhdGNoZXMgbmVlZGVkIGZvciB0aGUgTmF0aXZlU2NyaXB0IHBsYXRmb3JtXG5pbXBvcnQgJ0BuYXRpdmVzY3JpcHQvem9uZS1qcy9kaXN0L3ByZS16b25lLXBvbHlmaWxscyc7XG4vLyBab25lIEpTIGlzIHJlcXVpcmVkIGJ5IGRlZmF1bHQgZm9yIEFuZ3VsYXIgaXRzZWxmXG5pbXBvcnQgJ3pvbmUuanMnO1xuLy8gQWRkIE5hdGl2ZVNjcmlwdCBzcGVjaWZpYyBab25lIEpTIHBhdGNoZXNcbmltcG9ydCAnQG5hdGl2ZXNjcmlwdC96b25lLWpzJztcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIn4vcGFja2FnZS5qc29uXCIpOyJdLCJuYW1lcyI6WyJ0cmFuc2l0aW9uIiwic3R5bGUiLCJzdGF0ZSIsImFuaW1hdGUiLCJ0cmlnZ2VyIiwibWFwIiwiTGF5ZXJzU2VydmljZSIsImkwIiwiaTEiLCJpMiIsImkzIiwiaTQiLCJpNSIsIkFwcENvbXBvbmVudCIsImNvbnN0cnVjdG9yIiwibGF5ZXJzU2VydmljZSIsIm1lbnVJc09wZW4kIiwiZ2V0TGF5ZXJzJCIsInBpcGUiLCJtZW51IiwiaXNPcGVuIiwiY2xvc2VNZW51IiwiybVmYWMiLCJBcHBDb21wb25lbnRfRmFjdG9yeSIsInQiLCLJtcm1ZGlyZWN0aXZlSW5qZWN0IiwiybVjbXAiLCLJtcm1ZGVmaW5lQ29tcG9uZW50IiwidHlwZSIsInNlbGVjdG9ycyIsImRlY2xzIiwidmFycyIsImNvbnN0cyIsInRlbXBsYXRlIiwiQXBwQ29tcG9uZW50X1RlbXBsYXRlIiwicmYiLCJjdHgiLCLJtcm1ZWxlbWVudFN0YXJ0IiwiybXJtWVsZW1lbnQiLCLJtcm1ZWxlbWVudEVuZCIsIsm1ybVwaXBlIiwiybXJtWFkdmFuY2UiLCLJtcm1Y2xhc3NQcm9wIiwiybXJtXBpcGVCaW5kMSIsIsm1ybVwcm9wZXJ0eSIsImRlcGVuZGVuY2llcyIsIlBhZ2VSb3V0ZXJPdXRsZXQiLCJBbGVydFBvcHVwQ29tcG9uZW50IiwiTWVudUNvbXBvbmVudCIsIkFzeW5jUGlwZSIsImVuY2Fwc3VsYXRpb24iLCJkYXRhIiwiYW5pbWF0aW9uIiwidHJhbnNmb3JtIiwiQ29tbW9uTW9kdWxlIiwiSHR0cENsaWVudE1vZHVsZSIsIkFQUF9JTklUSUFMSVpFUiIsIk5hdGl2ZVNjcmlwdE1vZHVsZSIsIk5hdGl2ZVNjcmlwdEFuaW1hdGlvbnNNb2R1bGUiLCJOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUiLCJOYXRpdmVTY3JpcHRIdHRwQ2xpZW50TW9kdWxlIiwiTmd4c01vZHVsZSIsIkFwcFJvdXRpbmdNb2R1bGUiLCJDb25maWdTdGF0ZSIsIlByb2R1Y3RTdGF0ZSIsIlNoYXJlZE1vZHVsZSIsImFzeW5jQm9vdCIsIlByb21pc2UiLCJyZXNvbHZlIiwic2V0VGltZW91dCIsIkFwcE1vZHVsZSIsIkFwcE1vZHVsZV9GYWN0b3J5IiwiybVtb2QiLCLJtcm1ZGVmaW5lTmdNb2R1bGUiLCJib290c3RyYXAiLCLJtWluaiIsIsm1ybVkZWZpbmVJbmplY3RvciIsInByb3ZpZGVycyIsInByb3ZpZGUiLCJ1c2VGYWN0b3J5IiwibXVsdGkiLCJpbXBvcnRzIiwiZm9yUm9vdCIsImRldmVsb3BtZW50TW9kZSIsInRhcCIsInN3aXRjaE1hcCIsIlN0b3JlIiwiSWNvbnMiLCJOYXZpZ2F0aW9uU2VydmljZSIsIlJvdXRlcyIsIlF1aWNrdmlld0JvdHRvbXNoZWV0Q29tcG9uZW50X25nX2NvbnRhaW5lcl8xX1RlbXBsYXRlIiwiybXJtWVsZW1lbnRDb250YWluZXJTdGFydCIsIsm1ybVlbGVtZW50Q29udGFpbmVyRW5kIiwicHJvZHVjdERldGFpbHNfcjEiLCJuZ0lmIiwiaW1hZ2UiLCJ0aHVtYm5haWwiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic3Vic3RyaW5nIiwiUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnQiLCJzdG9yZSIsIm5hdmlnYXRpb25TZXJ2aWNlIiwic3RhdGUkIiwibGF5ZXJzIiwicXVpY2t2aWV3Qm90dG9tc2hlZXQiLCJwcm9kdWN0RGV0YWlscyQiLCJwcm9kdWN0SWQiLCJfcHJvZHVjdElkIiwic2VsZWN0IiwicHJvZHVjdEJ5SWQiLCJpY29ucyIsImNsb3NlIiwiY2xvc2VRdWlja3ZpZXdCb3R0b21zaGVldCIsIm5hdmlnYXRlVG9Qcm9kdWN0RGV0YWlscyIsIm5hdmlnYXRlIiwiZGV0YWlscyIsImlkIiwiUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnRfRmFjdG9yeSIsIlF1aWNrdmlld0JvdHRvbXNoZWV0Q29tcG9uZW50X1RlbXBsYXRlIiwiybXJtWxpc3RlbmVyIiwiUXVpY2t2aWV3Qm90dG9tc2hlZXRDb21wb25lbnRfVGVtcGxhdGVfR3JpZExheW91dF90YXBfMF9saXN0ZW5lciIsIsm1ybV0ZW1wbGF0ZSIsImluZm8iLCJOZ0lmIiwiVGh1bWJuYWlsQ2FyZENvbXBvbmVudCJdLCJzb3VyY2VSb290IjoiIn0=