"use strict";
exports.id = "src_app_features_config_config_module_ts";
exports.ids = ["src_app_features_config_config_module_ts"];
exports.modules = {

/***/ "./src/app/features/config/config-routing.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfigRoutingModule": () => (/* binding */ ConfigRoutingModule),
/* harmony export */   "routes": () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _config_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/config/config.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");




const routes = [
    {
        path: "",
        component: _config_component__WEBPACK_IMPORTED_MODULE_0__.ConfigComponent,
    },
];
class ConfigRoutingModule {
}
ConfigRoutingModule.ɵfac = function ConfigRoutingModule_Factory(t) { return new (t || ConfigRoutingModule)(); };
ConfigRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: ConfigRoutingModule });
ConfigRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptRouterModule.forChild(routes)] });


/***/ }),

/***/ "./src/app/features/config/config.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfigComponent": () => (/* binding */ ConfigComponent)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/rxjs/dist/cjs/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/rxjs/dist/cjs/operators/index.js");
/* harmony import */ var _ngxs_store__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@ngxs/store/__ivy_ngcc__/fesm5/ngxs-store.js");
/* harmony import */ var _app_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./node_modules/@nativescript/core/ui/page/index.ios.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./node_modules/@angular/forms/fesm2015/forms.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _shared_components_header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./src/app/shared/components/header/header.component.ts");













function ConfigComponent_ng_container_7_ng_container_1_Label_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "Label", 10);
  }

  if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", ctx_r6.icon.check);
  }
}

function ConfigComponent_ng_container_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r8 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "GridLayout", 6)(2, "Label", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("tap", function ConfigComponent_ng_container_7_ng_container_1_Template_Label_tap_2_listener() {
      const restoredCtx = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r8);
      const styleOption_r5 = restoredCtx.$implicit;
      const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r7.updateStylingUrl(styleOption_r5 == null ? null : styleOption_r5.styleUrl));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](3, ConfigComponent_ng_container_7_ng_container_1_Label_3_Template, 1, 1, "Label", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const styleOption_r5 = ctx.$implicit;
    const styles_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]().ngIf;
    const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("bold", !ctx_r3.displayCustomStyleTextfield && styles_r2.selected === (styleOption_r5 == null ? null : styleOption_r5.styleUrl));
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", styleOption_r5 == null ? null : styleOption_r5.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", !ctx_r3.displayCustomStyleTextfield && styles_r2.selected === (styleOption_r5 == null ? null : styleOption_r5.styleUrl));
  }
}

function ConfigComponent_ng_container_7_Label_4_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](0, "Label", 10);
  }

  if (rf & 2) {
    const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", ctx_r4.icon.check);
  }
}

function ConfigComponent_ng_container_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r11 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](1, ConfigComponent_ng_container_7_ng_container_1_Template, 4, 4, "ng-container", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "GridLayout", 6)(3, "Label", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("tap", function ConfigComponent_ng_container_7_Template_Label_tap_3_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r11);
      const ctx_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r10.toggleCustomStyle());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](4, ConfigComponent_ng_container_7_Label_4_Template, 1, 1, "Label", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const styles_r2 = ctx.ngIf;
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngForOf", styles_r2.options);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵclassProp"]("bold", ctx_r0.displayCustomStyleTextfield);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx_r0.displayCustomStyleTextfield);
  }
}

function ConfigComponent_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵgetCurrentView"]();

    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](1, "TextField", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("ngModelChange", function ConfigComponent_ng_container_10_Template_TextField_ngModelChange_1_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r13);
      const ctx_r12 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r12.stylingUrl = $event);
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](2, "Button", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵlistener"]("tap", function ConfigComponent_ng_container_10_Template_Button_tap_2_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r13);
      const ctx_r14 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r14.updateUrls());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementContainerEnd"]();
  }

  if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵnextContext"]();
    let tmp_1_0;
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngModel", ctx_r1.stylingUrl);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 2, ctx_r1.staticText$)) == null ? null : tmp_1_0.config == null ? null : tmp_1_0.config.buttons == null ? null : tmp_1_0.config.buttons.update) || "UPDATE");
  }
}

const _c0 = function (a0, a1) {
  return {
    selected: a0,
    options: a1
  };
};

class ConfigComponent {
  constructor(page, store) {
    this.page = page;
    this.store = store;
    this.displayCustomStyleTextfield = false;
    this.icon = _app_core__WEBPACK_IMPORTED_MODULE_1__.Icons;
    this._destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_4__.Subject();
    this.page.actionBarHidden = true;
    this.store.select(_app_core__WEBPACK_IMPORTED_MODULE_1__.ConfigState.dataUrl).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this._destroy$)).subscribe(stateDataUrl => {
      this.dataUrl = stateDataUrl;
    });
    this.store.select(_app_core__WEBPACK_IMPORTED_MODULE_1__.ConfigState.stylingUrl).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.takeUntil)(this._destroy$)).subscribe(stateStylingUrl => {
      this.stylingUrl = stateStylingUrl;
    });
    this.store.dispatch(new _app_core__WEBPACK_IMPORTED_MODULE_1__.Config.UpdateStyleOptions());
  }

  ngOnDestroy() {
    this._destroy$.next(true);

    this._destroy$.complete();
  }

  toggleCustomStyle() {
    this.displayCustomStyleTextfield = !this.displayCustomStyleTextfield;
  }

  updateStylingUrl(url) {
    this.store.dispatch(new _app_core__WEBPACK_IMPORTED_MODULE_1__.Config.UpdateStylingUrl(url)); // hide custom textfield

    this.displayCustomStyleTextfield = false;
  }

  updateUrls() {
    this.store.dispatch(new _app_core__WEBPACK_IMPORTED_MODULE_1__.Config.UpdateDataUrl(this.dataUrl)).toPromise().then(() => {
      this.store.dispatch(new _app_core__WEBPACK_IMPORTED_MODULE_1__.Config.UpdateStylingUrl(this.stylingUrl));
    });
  }

}

ConfigComponent.ɵfac = function ConfigComponent_Factory(t) {
  return new (t || ConfigComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_nativescript_core__WEBPACK_IMPORTED_MODULE_6__.Page), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdirectiveInject"](_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Store));
};

ConfigComponent.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineComponent"]({
  type: ConfigComponent,
  selectors: [["ns-config"]],
  decls: 11,
  vars: 15,
  consts: [["height", "100%"], ["hasMenuButton", "true", 3, "headerTitle"], [1, "p-xl"], [1, "font-size-h1", "m-b-l", 3, "text"], [4, "ngIf"], [4, "ngFor", "ngForOf"], ["columns", "*, 50"], ["text", "Custom", 1, "font-size-h3", "p-s", "m-t-s", 3, "tap"], ["col", "1", "class", "ionicons font-size-h1 text-color-primary", 3, "text", 4, "ngIf"], [1, "font-size-h3", "p-s", "m-t-s", 3, "text", "tap"], ["col", "1", 1, "ionicons", "font-size-h1", "text-color-primary", 3, "text"], ["hint", "https://raw.githubusercontent.com/...", 1, "font-size-h3", "p-s", "m-t-s", "border-b-primary", 3, "ngModel", "ngModelChange"], [1, "button-primary", "medium", "m-t-xl", 3, "text", "tap"]],
  template: function ConfigComponent_Template(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](0, "ScrollView", 0)(1, "StackLayout");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](2, "ns-header", 1);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](3, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementStart"](4, "StackLayout", 2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelement"](5, "Label", 3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](6, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](7, ConfigComponent_ng_container_7_Template, 5, 4, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](8, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipe"](9, "async");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵtemplate"](10, ConfigComponent_ng_container_10_Template, 4, 4, "ng-container", 4);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵelementEnd"]()()();
    }

    if (rf & 2) {
      let tmp_0_0;
      let tmp_1_0;
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("headerTitle", ((tmp_0_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](3, 4, ctx.staticText$)) == null ? null : tmp_0_0.config == null ? null : tmp_0_0.config.title) || "SETTINGS");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("text", ((tmp_1_0 = _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](6, 6, ctx.staticText$)) == null ? null : tmp_1_0.config == null ? null : tmp_1_0.config.stylingUrlTitle) || "Styling");
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](2);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpureFunction2"](12, _c0, _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](8, 8, ctx.stylingUrl$), _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵpipeBind1"](9, 10, ctx.styleOptions$)));
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵadvance"](3);
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵproperty"]("ngIf", ctx.displayCustomStyleTextfield);
    }
  },
  dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_7__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_7__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_8__.NgModel, _nativescript_angular__WEBPACK_IMPORTED_MODULE_9__.TextValueAccessor, _shared_components_header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent, _angular_common__WEBPACK_IMPORTED_MODULE_7__.AsyncPipe],
  encapsulation: 2,
  data: {
    animation: [_app_core__WEBPACK_IMPORTED_MODULE_1__.SlideUpFadeStagger]
  }
});

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ConfigState.staticText), __metadata("design:type", Object)], ConfigComponent.prototype, "staticText$", void 0);

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ConfigState.styleOptions), __metadata("design:type", Object)], ConfigComponent.prototype, "styleOptions$", void 0);

__decorate([(0,_ngxs_store__WEBPACK_IMPORTED_MODULE_0__.Select)(_app_core__WEBPACK_IMPORTED_MODULE_1__.ConfigState.stylingUrl), __metadata("design:type", Object)], ConfigComponent.prototype, "stylingUrl$", void 0);

/***/ }),

/***/ "./src/app/features/config/config.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ConfigModule": () => (/* binding */ ConfigModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _app_shared__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/shared/index.ts");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _config_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/features/config/config-routing.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");





class ConfigModule {
}
ConfigModule.ɵfac = function ConfigModule_Factory(t) { return new (t || ConfigModule)(); };
ConfigModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineNgModule"]({ type: ConfigModule });
ConfigModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_3__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_3__.NativeScriptFormsModule,
        _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
        _config_routing_module__WEBPACK_IMPORTED_MODULE_1__.ConfigRoutingModule,
        _app_shared__WEBPACK_IMPORTED_MODULE_0__.SharedModule] });


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2FwcF9mZWF0dXJlc19jb25maWdfY29uZmlnX21vZHVsZV90cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQTRGO0FBQ3ZDO0FBQ2pCO0FBQ1E7QUFDckM7QUFDUDtBQUNBO0FBQ0EsbUJBQW1CLDhEQUFlO0FBQ2xDLEtBQUs7QUFDTDtBQUNPO0FBQ1A7QUFDQSxxRUFBcUU7QUFDckUseUNBQXlDLDhEQUFtQixHQUFHLDJCQUEyQjtBQUMxRix5Q0FBeUMsOERBQW1CLEdBQUcsVUFBVSwyRUFBd0I7QUFDakcsUUFBUSxvRkFBaUMsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFNBQVNnQiw4REFBVCxDQUF3RUMsRUFBeEUsRUFBNEVDLEdBQTVFLEVBQWlGO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUMzRlIsdURBQUEsQ0FBYSxDQUFiLEVBQWdCLE9BQWhCLEVBQXlCLEVBQXpCO0VBQ0g7O0VBQUMsSUFBSVEsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNWLE1BQU1HLE1BQU0sR0FBR1gsMkRBQUEsQ0FBaUIsQ0FBakIsQ0FBZjtJQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0JXLE1BQU0sQ0FBQ0csSUFBUCxDQUFZQyxLQUFsQztFQUNIO0FBQUU7O0FBQ0gsU0FBU0Msc0RBQVQsQ0FBZ0VSLEVBQWhFLEVBQW9FQyxHQUFwRSxFQUF5RTtFQUFFLElBQUlELEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDbkYsTUFBTVMsR0FBRyxHQUFHakIsOERBQUEsRUFBWjs7SUFDQUEscUVBQUEsQ0FBMkIsQ0FBM0I7SUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsWUFBckIsRUFBbUMsQ0FBbkMsRUFBc0MsQ0FBdEMsRUFBeUMsT0FBekMsRUFBa0QsQ0FBbEQ7SUFDQUEsd0RBQUEsQ0FBYyxLQUFkLEVBQXFCLFNBQVNzQiwyRUFBVCxHQUF1RjtNQUFFLE1BQU1DLFdBQVcsR0FBR3ZCLDJEQUFBLENBQWlCaUIsR0FBakIsQ0FBcEI7TUFBMkMsTUFBTVEsY0FBYyxHQUFHRixXQUFXLENBQUNHLFNBQW5DO01BQThDLE1BQU1DLE1BQU0sR0FBRzNCLDJEQUFBLENBQWlCLENBQWpCLENBQWY7TUFBb0MsT0FBT0EseURBQUEsQ0FBZTJCLE1BQU0sQ0FBQ0UsZ0JBQVAsQ0FBd0JKLGNBQWMsSUFBSSxJQUFsQixHQUF5QixJQUF6QixHQUFnQ0EsY0FBYyxDQUFDSyxRQUF2RSxDQUFmLENBQVA7SUFBMEcsQ0FBclY7SUFDQTlCLDBEQUFBO0lBQ0FBLHdEQUFBLENBQWMsQ0FBZCxFQUFpQk8sOERBQWpCLEVBQWlGLENBQWpGLEVBQW9GLENBQXBGLEVBQXVGLE9BQXZGLEVBQWdHLENBQWhHO0lBQ0FQLDBEQUFBO0lBQ0FBLG1FQUFBO0VBQ0g7O0VBQUMsSUFBSVEsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNWLE1BQU1pQixjQUFjLEdBQUdoQixHQUFHLENBQUNpQixTQUEzQjtJQUNBLE1BQU1RLFNBQVMsR0FBR2xDLDJEQUFBLEdBQW1CbUMsSUFBckM7SUFDQSxNQUFNQyxNQUFNLEdBQUdwQywyREFBQSxFQUFmO0lBQ0FBLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx5REFBQSxDQUFlLE1BQWYsRUFBdUIsQ0FBQ29DLE1BQU0sQ0FBQ0csMkJBQVIsSUFBdUNMLFNBQVMsQ0FBQ00sUUFBVixNQUF3QmYsY0FBYyxJQUFJLElBQWxCLEdBQXlCLElBQXpCLEdBQWdDQSxjQUFjLENBQUNLLFFBQXZFLENBQTlEO0lBQ0E5Qix3REFBQSxDQUFjLE1BQWQsRUFBc0J5QixjQUFjLElBQUksSUFBbEIsR0FBeUIsSUFBekIsR0FBZ0NBLGNBQWMsQ0FBQ2dCLFdBQXJFO0lBQ0F6Qyx1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCLENBQUNvQyxNQUFNLENBQUNHLDJCQUFSLElBQXVDTCxTQUFTLENBQUNNLFFBQVYsTUFBd0JmLGNBQWMsSUFBSSxJQUFsQixHQUF5QixJQUF6QixHQUFnQ0EsY0FBYyxDQUFDSyxRQUF2RSxDQUE3RDtFQUNIO0FBQUU7O0FBQ0gsU0FBU1ksK0NBQVQsQ0FBeURsQyxFQUF6RCxFQUE2REMsR0FBN0QsRUFBa0U7RUFBRSxJQUFJRCxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQzVFUix1REFBQSxDQUFhLENBQWIsRUFBZ0IsT0FBaEIsRUFBeUIsRUFBekI7RUFDSDs7RUFBQyxJQUFJUSxFQUFFLEdBQUcsQ0FBVCxFQUFZO0lBQ1YsTUFBTW1DLE1BQU0sR0FBRzNDLDJEQUFBLENBQWlCLENBQWpCLENBQWY7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCMkMsTUFBTSxDQUFDN0IsSUFBUCxDQUFZQyxLQUFsQztFQUNIO0FBQUU7O0FBQ0gsU0FBUzZCLHVDQUFULENBQWlEcEMsRUFBakQsRUFBcURDLEdBQXJELEVBQTBEO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNwRSxNQUFNcUMsSUFBSSxHQUFHN0MsOERBQUEsRUFBYjs7SUFDQUEscUVBQUEsQ0FBMkIsQ0FBM0I7SUFDQUEsd0RBQUEsQ0FBYyxDQUFkLEVBQWlCZ0Isc0RBQWpCLEVBQXlFLENBQXpFLEVBQTRFLENBQTVFLEVBQStFLGNBQS9FLEVBQStGLENBQS9GO0lBQ0FoQiw0REFBQSxDQUFrQixDQUFsQixFQUFxQixZQUFyQixFQUFtQyxDQUFuQyxFQUFzQyxDQUF0QyxFQUF5QyxPQUF6QyxFQUFrRCxDQUFsRDtJQUNBQSx3REFBQSxDQUFjLEtBQWQsRUFBcUIsU0FBUzhDLDREQUFULEdBQXdFO01BQUU5QywyREFBQSxDQUFpQjZDLElBQWpCO01BQXdCLE1BQU1FLE9BQU8sR0FBRy9DLDJEQUFBLEVBQWhCO01BQW9DLE9BQU9BLHlEQUFBLENBQWUrQyxPQUFPLENBQUNDLGlCQUFSLEVBQWYsQ0FBUDtJQUFxRCxDQUFoTjtJQUNBaEQsMERBQUE7SUFDQUEsd0RBQUEsQ0FBYyxDQUFkLEVBQWlCMEMsK0NBQWpCLEVBQWtFLENBQWxFLEVBQXFFLENBQXJFLEVBQXdFLE9BQXhFLEVBQWlGLENBQWpGO0lBQ0ExQywwREFBQTtJQUNBQSxtRUFBQTtFQUNIOztFQUFDLElBQUlRLEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDVixNQUFNMEIsU0FBUyxHQUFHekIsR0FBRyxDQUFDMEIsSUFBdEI7SUFDQSxNQUFNYyxNQUFNLEdBQUdqRCwyREFBQSxFQUFmO0lBQ0FBLHVEQUFBLENBQWEsQ0FBYjtJQUNBQSx3REFBQSxDQUFjLFNBQWQsRUFBeUJrQyxTQUFTLENBQUNnQixPQUFuQztJQUNBbEQsdURBQUEsQ0FBYSxDQUFiO0lBQ0FBLHlEQUFBLENBQWUsTUFBZixFQUF1QmlELE1BQU0sQ0FBQ1YsMkJBQTlCO0lBQ0F2Qyx1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxNQUFkLEVBQXNCaUQsTUFBTSxDQUFDViwyQkFBN0I7RUFDSDtBQUFFOztBQUNILFNBQVNZLHdDQUFULENBQWtEM0MsRUFBbEQsRUFBc0RDLEdBQXRELEVBQTJEO0VBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtJQUNyRSxNQUFNNEMsSUFBSSxHQUFHcEQsOERBQUEsRUFBYjs7SUFDQUEscUVBQUEsQ0FBMkIsQ0FBM0I7SUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsV0FBckIsRUFBa0MsRUFBbEM7SUFDQUEsd0RBQUEsQ0FBYyxlQUFkLEVBQStCLFNBQVNxRCwyRUFBVCxDQUFxRkMsTUFBckYsRUFBNkY7TUFBRXRELDJEQUFBLENBQWlCb0QsSUFBakI7TUFBd0IsTUFBTUcsT0FBTyxHQUFHdkQsMkRBQUEsRUFBaEI7TUFBb0MsT0FBT0EseURBQUEsQ0FBZXVELE9BQU8sQ0FBQ0MsVUFBUixHQUFxQkYsTUFBcEMsQ0FBUDtJQUFxRCxDQUEvTztJQUNBdEQsMERBQUE7SUFDQUEsNERBQUEsQ0FBa0IsQ0FBbEIsRUFBcUIsUUFBckIsRUFBK0IsRUFBL0I7SUFDQUEsd0RBQUEsQ0FBYyxLQUFkLEVBQXFCLFNBQVN5RCw4REFBVCxHQUEwRTtNQUFFekQsMkRBQUEsQ0FBaUJvRCxJQUFqQjtNQUF3QixNQUFNTSxPQUFPLEdBQUcxRCwyREFBQSxFQUFoQjtNQUFvQyxPQUFPQSx5REFBQSxDQUFlMEQsT0FBTyxDQUFDQyxVQUFSLEVBQWYsQ0FBUDtJQUE4QyxDQUEzTTtJQUNBM0Qsb0RBQUEsQ0FBVSxDQUFWLEVBQWEsT0FBYjtJQUNBQSwwREFBQTtJQUNBQSxtRUFBQTtFQUNIOztFQUFDLElBQUlRLEVBQUUsR0FBRyxDQUFULEVBQVk7SUFDVixNQUFNcUQsTUFBTSxHQUFHN0QsMkRBQUEsRUFBZjtJQUNBLElBQUk4RCxPQUFKO0lBQ0E5RCx1REFBQSxDQUFhLENBQWI7SUFDQUEsd0RBQUEsQ0FBYyxTQUFkLEVBQXlCNkQsTUFBTSxDQUFDTCxVQUFoQztJQUNBeEQsdURBQUEsQ0FBYSxDQUFiO0lBQ0FBLHdEQUFBLENBQWMsTUFBZCxFQUFzQixDQUFDLENBQUM4RCxPQUFPLEdBQUc5RCx5REFBQSxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUI2RCxNQUFNLENBQUNHLFdBQTVCLENBQVgsS0FBd0QsSUFBeEQsR0FBK0QsSUFBL0QsR0FBc0VGLE9BQU8sQ0FBQ0csTUFBUixJQUFrQixJQUFsQixHQUF5QixJQUF6QixHQUFnQ0gsT0FBTyxDQUFDRyxNQUFSLENBQWVDLE9BQWYsSUFBMEIsSUFBMUIsR0FBaUMsSUFBakMsR0FBd0NKLE9BQU8sQ0FBQ0csTUFBUixDQUFlQyxPQUFmLENBQXVCQyxNQUF0SyxLQUFpTCxRQUF2TTtFQUNIO0FBQUU7O0FBQ0gsTUFBTUMsR0FBRyxHQUFHLFVBQVVDLEVBQVYsRUFBY0MsRUFBZCxFQUFrQjtFQUFFLE9BQU87SUFBRTlCLFFBQVEsRUFBRTZCLEVBQVo7SUFBZ0JuQixPQUFPLEVBQUVvQjtFQUF6QixDQUFQO0FBQXVDLENBQXZFOztBQUNPLE1BQU1DLGVBQU4sQ0FBc0I7RUFDekJDLFdBQVcsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEVBQWM7SUFDckIsS0FBS0QsSUFBTCxHQUFZQSxJQUFaO0lBQ0EsS0FBS0MsS0FBTCxHQUFhQSxLQUFiO0lBQ0EsS0FBS25DLDJCQUFMLEdBQW1DLEtBQW5DO0lBQ0EsS0FBS3pCLElBQUwsR0FBWWYsNENBQVo7SUFDQSxLQUFLNEUsU0FBTCxHQUFpQixJQUFJbkYseUNBQUosRUFBakI7SUFDQSxLQUFLaUYsSUFBTCxDQUFVRyxlQUFWLEdBQTRCLElBQTVCO0lBQ0EsS0FBS0YsS0FBTCxDQUNLRyxNQURMLENBQ1kvRSwwREFEWixFQUVLaUYsSUFGTCxDQUVVdEYseURBQVMsQ0FBQyxLQUFLa0YsU0FBTixDQUZuQixFQUdLSyxTQUhMLENBR2dCQyxZQUFELElBQWtCO01BQzdCLEtBQUtILE9BQUwsR0FBZUcsWUFBZjtJQUNILENBTEQ7SUFNQSxLQUFLUCxLQUFMLENBQ0tHLE1BREwsQ0FDWS9FLDZEQURaLEVBRUtpRixJQUZMLENBRVV0Rix5REFBUyxDQUFDLEtBQUtrRixTQUFOLENBRm5CLEVBR0tLLFNBSEwsQ0FHZ0JFLGVBQUQsSUFBcUI7TUFDaEMsS0FBSzFCLFVBQUwsR0FBa0IwQixlQUFsQjtJQUNILENBTEQ7SUFNQSxLQUFLUixLQUFMLENBQVdTLFFBQVgsQ0FBb0IsSUFBSXZGLGdFQUFKLEVBQXBCO0VBQ0g7O0VBQ0R5RixXQUFXLEdBQUc7SUFDVixLQUFLVixTQUFMLENBQWVXLElBQWYsQ0FBb0IsSUFBcEI7O0lBQ0EsS0FBS1gsU0FBTCxDQUFlWSxRQUFmO0VBQ0g7O0VBQ0R2QyxpQkFBaUIsR0FBRztJQUNoQixLQUFLVCwyQkFBTCxHQUFtQyxDQUFDLEtBQUtBLDJCQUF6QztFQUNIOztFQUNEVixnQkFBZ0IsQ0FBQzJELEdBQUQsRUFBTTtJQUNsQixLQUFLZCxLQUFMLENBQVdTLFFBQVgsQ0FBb0IsSUFBSXZGLDhEQUFKLENBQTRCNEYsR0FBNUIsQ0FBcEIsRUFEa0IsQ0FFbEI7O0lBQ0EsS0FBS2pELDJCQUFMLEdBQW1DLEtBQW5DO0VBQ0g7O0VBQ0RvQixVQUFVLEdBQUc7SUFDVCxLQUFLZSxLQUFMLENBQ0tTLFFBREwsQ0FDYyxJQUFJdkYsMkRBQUosQ0FBeUIsS0FBS2tGLE9BQTlCLENBRGQsRUFFS2EsU0FGTCxHQUdLQyxJQUhMLENBR1UsTUFBTTtNQUNaLEtBQUtsQixLQUFMLENBQVdTLFFBQVgsQ0FBb0IsSUFBSXZGLDhEQUFKLENBQTRCLEtBQUs0RCxVQUFqQyxDQUFwQjtJQUNILENBTEQ7RUFNSDs7QUF6Q3dCOztBQTJDN0JlLGVBQWUsQ0FBQ3NCLElBQWhCLEdBQXVCLFNBQVNDLHVCQUFULENBQWlDQyxDQUFqQyxFQUFvQztFQUFFLE9BQU8sS0FBS0EsQ0FBQyxJQUFJeEIsZUFBVixFQUEyQnZFLCtEQUFBLENBQXFCQyxvREFBckIsQ0FBM0IsRUFBMERELCtEQUFBLENBQXFCRSw4Q0FBckIsQ0FBMUQsQ0FBUDtBQUFtRyxDQUFoSzs7QUFDQXFFLGVBQWUsQ0FBQzBCLElBQWhCLEdBQXVCLGFBQWNqRywrREFBQSxDQUFxQjtFQUFFbUcsSUFBSSxFQUFFNUIsZUFBUjtFQUF5QjZCLFNBQVMsRUFBRSxDQUFDLENBQUMsV0FBRCxDQUFELENBQXBDO0VBQXFEQyxLQUFLLEVBQUUsRUFBNUQ7RUFBZ0VDLElBQUksRUFBRSxFQUF0RTtFQUEwRUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxRQUFELEVBQVcsTUFBWCxDQUFELEVBQXFCLENBQUMsZUFBRCxFQUFrQixNQUFsQixFQUEwQixDQUExQixFQUE2QixhQUE3QixDQUFyQixFQUFrRSxDQUFDLENBQUQsRUFBSSxNQUFKLENBQWxFLEVBQStFLENBQUMsQ0FBRCxFQUFJLGNBQUosRUFBb0IsT0FBcEIsRUFBNkIsQ0FBN0IsRUFBZ0MsTUFBaEMsQ0FBL0UsRUFBd0gsQ0FBQyxDQUFELEVBQUksTUFBSixDQUF4SCxFQUFxSSxDQUFDLENBQUQsRUFBSSxPQUFKLEVBQWEsU0FBYixDQUFySSxFQUE4SixDQUFDLFNBQUQsRUFBWSxPQUFaLENBQTlKLEVBQW9MLENBQUMsTUFBRCxFQUFTLFFBQVQsRUFBbUIsQ0FBbkIsRUFBc0IsY0FBdEIsRUFBc0MsS0FBdEMsRUFBNkMsT0FBN0MsRUFBc0QsQ0FBdEQsRUFBeUQsS0FBekQsQ0FBcEwsRUFBcVAsQ0FBQyxLQUFELEVBQVEsR0FBUixFQUFhLE9BQWIsRUFBc0IsMENBQXRCLEVBQWtFLENBQWxFLEVBQXFFLE1BQXJFLEVBQTZFLENBQTdFLEVBQWdGLE1BQWhGLENBQXJQLEVBQThVLENBQUMsQ0FBRCxFQUFJLGNBQUosRUFBb0IsS0FBcEIsRUFBMkIsT0FBM0IsRUFBb0MsQ0FBcEMsRUFBdUMsTUFBdkMsRUFBK0MsS0FBL0MsQ0FBOVUsRUFBcVksQ0FBQyxLQUFELEVBQVEsR0FBUixFQUFhLENBQWIsRUFBZ0IsVUFBaEIsRUFBNEIsY0FBNUIsRUFBNEMsb0JBQTVDLEVBQWtFLENBQWxFLEVBQXFFLE1BQXJFLENBQXJZLEVBQW1kLENBQUMsTUFBRCxFQUFTLHVDQUFULEVBQWtELENBQWxELEVBQXFELGNBQXJELEVBQXFFLEtBQXJFLEVBQTRFLE9BQTVFLEVBQXFGLGtCQUFyRixFQUF5RyxDQUF6RyxFQUE0RyxTQUE1RyxFQUF1SCxlQUF2SCxDQUFuZCxFQUE0bEIsQ0FBQyxDQUFELEVBQUksZ0JBQUosRUFBc0IsUUFBdEIsRUFBZ0MsUUFBaEMsRUFBMEMsQ0FBMUMsRUFBNkMsTUFBN0MsRUFBcUQsS0FBckQsQ0FBNWxCLENBQWxGO0VBQTR1QkMsUUFBUSxFQUFFLFNBQVNDLHdCQUFULENBQWtDakcsRUFBbEMsRUFBc0NDLEdBQXRDLEVBQTJDO0lBQUUsSUFBSUQsRUFBRSxHQUFHLENBQVQsRUFBWTtNQUNqMkJSLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLFlBQXJCLEVBQW1DLENBQW5DLEVBQXNDLENBQXRDLEVBQXlDLGFBQXpDO01BQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixXQUFoQixFQUE2QixDQUE3QjtNQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO01BQ0FBLDREQUFBLENBQWtCLENBQWxCLEVBQXFCLGFBQXJCLEVBQW9DLENBQXBDO01BQ0FBLHVEQUFBLENBQWEsQ0FBYixFQUFnQixPQUFoQixFQUF5QixDQUF6QjtNQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO01BQ0FBLHdEQUFBLENBQWMsQ0FBZCxFQUFpQjRDLHVDQUFqQixFQUEwRCxDQUExRCxFQUE2RCxDQUE3RCxFQUFnRSxjQUFoRSxFQUFnRixDQUFoRjtNQUNBNUMsb0RBQUEsQ0FBVSxDQUFWLEVBQWEsT0FBYjtNQUNBQSxvREFBQSxDQUFVLENBQVYsRUFBYSxPQUFiO01BQ0FBLHdEQUFBLENBQWMsRUFBZCxFQUFrQm1ELHdDQUFsQixFQUE0RCxDQUE1RCxFQUErRCxDQUEvRCxFQUFrRSxjQUFsRSxFQUFrRixDQUFsRjtNQUNBbkQsMERBQUE7SUFDSDs7SUFBQyxJQUFJUSxFQUFFLEdBQUcsQ0FBVCxFQUFZO01BQ1YsSUFBSWtHLE9BQUo7TUFDQSxJQUFJNUMsT0FBSjtNQUNBOUQsdURBQUEsQ0FBYSxDQUFiO01BQ0FBLHdEQUFBLENBQWMsYUFBZCxFQUE2QixDQUFDLENBQUMwRyxPQUFPLEdBQUcxRyx5REFBQSxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUJTLEdBQUcsQ0FBQ3VELFdBQXpCLENBQVgsS0FBcUQsSUFBckQsR0FBNEQsSUFBNUQsR0FBbUUwQyxPQUFPLENBQUN6QyxNQUFSLElBQWtCLElBQWxCLEdBQXlCLElBQXpCLEdBQWdDeUMsT0FBTyxDQUFDekMsTUFBUixDQUFlMEMsS0FBbkgsS0FBNkgsVUFBMUo7TUFDQTNHLHVEQUFBLENBQWEsQ0FBYjtNQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0IsQ0FBQyxDQUFDOEQsT0FBTyxHQUFHOUQseURBQUEsQ0FBZSxDQUFmLEVBQWtCLENBQWxCLEVBQXFCUyxHQUFHLENBQUN1RCxXQUF6QixDQUFYLEtBQXFELElBQXJELEdBQTRELElBQTVELEdBQW1FRixPQUFPLENBQUNHLE1BQVIsSUFBa0IsSUFBbEIsR0FBeUIsSUFBekIsR0FBZ0NILE9BQU8sQ0FBQ0csTUFBUixDQUFlMkMsZUFBbkgsS0FBdUksU0FBN0o7TUFDQTVHLHVEQUFBLENBQWEsQ0FBYjtNQUNBQSx3REFBQSxDQUFjLE1BQWQsRUFBc0JBLDZEQUFBLENBQW1CLEVBQW5CLEVBQXVCb0UsR0FBdkIsRUFBNEJwRSx5REFBQSxDQUFlLENBQWYsRUFBa0IsQ0FBbEIsRUFBcUJTLEdBQUcsQ0FBQ3FHLFdBQXpCLENBQTVCLEVBQW1FOUcseURBQUEsQ0FBZSxDQUFmLEVBQWtCLEVBQWxCLEVBQXNCUyxHQUFHLENBQUNzRyxhQUExQixDQUFuRSxDQUF0QjtNQUNBL0csdURBQUEsQ0FBYSxDQUFiO01BQ0FBLHdEQUFBLENBQWMsTUFBZCxFQUFzQlMsR0FBRyxDQUFDOEIsMkJBQTFCO0lBQ0g7RUFBRSxDQXZCbUQ7RUF1QmpEeUUsWUFBWSxFQUFFLENBQUM3RyxvREFBRCxFQUFhQSxpREFBYixFQUFzQkMsMkRBQXRCLEVBQTBDQSxtREFBMUMsRUFBc0RDLG9FQUF0RCxFQUE0RUMsdUZBQTVFLEVBQWdHSCxzREFBaEcsQ0F2Qm1DO0VBdUI0RXFILGFBQWEsRUFBRSxDQXZCM0Y7RUF1QjhGQyxJQUFJLEVBQUU7SUFBRUMsU0FBUyxFQUFFLENBQUM3SCx5REFBRDtFQUFiO0FBdkJwRyxDQUFyQixDQUFyQzs7QUF3QkE4SCxVQUFVLENBQUMsQ0FDUGpJLG1EQUFNLENBQUNJLDZEQUFELENBREMsRUFFUCtILFVBQVUsQ0FBQyxhQUFELEVBQWdCQyxNQUFoQixDQUZILENBQUQsRUFHUHZELGVBQWUsQ0FBQ3dELFNBSFQsRUFHb0IsYUFIcEIsRUFHbUMsS0FBSyxDQUh4QyxDQUFWOztBQUlBSixVQUFVLENBQUMsQ0FDUGpJLG1EQUFNLENBQUNJLCtEQUFELENBREMsRUFFUCtILFVBQVUsQ0FBQyxhQUFELEVBQWdCQyxNQUFoQixDQUZILENBQUQsRUFHUHZELGVBQWUsQ0FBQ3dELFNBSFQsRUFHb0IsZUFIcEIsRUFHcUMsS0FBSyxDQUgxQyxDQUFWOztBQUlBSixVQUFVLENBQUMsQ0FDUGpJLG1EQUFNLENBQUNJLDZEQUFELENBREMsRUFFUCtILFVBQVUsQ0FBQyxhQUFELEVBQWdCQyxNQUFoQixDQUZILENBQUQsRUFHUHZELGVBQWUsQ0FBQ3dELFNBSFQsRUFHb0IsYUFIcEIsRUFHbUMsS0FBSyxDQUh4QyxDQUFWOzs7Ozs7Ozs7Ozs7Ozs7O0FDL0orQztBQUNKO0FBQ2dEO0FBQzdCO0FBQzFCO0FBQzdCO0FBQ1A7QUFDQSx1REFBdUQ7QUFDdkQsa0NBQWtDLDhEQUFtQixHQUFHLG9CQUFvQjtBQUM1RSxrQ0FBa0MsOERBQW1CLEdBQUcsVUFBVSwyRUFBd0I7QUFDMUYsUUFBUSwwRUFBdUI7QUFDL0IsUUFBUSx5REFBWTtBQUNwQixRQUFRLHVFQUFtQjtBQUMzQixRQUFRLHFEQUFZLEdBQUciLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AbmF0aXZlc2NyaXB0L3RlbXBsYXRlLWhlbGxvLXdvcmxkLW5nLy4vc3JjL2FwcC9mZWF0dXJlcy9jb25maWcvY29uZmlnLXJvdXRpbmcubW9kdWxlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL2NvbmZpZy9jb25maWcuY29tcG9uZW50LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL2NvbmZpZy9jb25maWcubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSwgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLCB9IGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmltcG9ydCB7IENvbmZpZ0NvbXBvbmVudCB9IGZyb20gXCIuL2NvbmZpZy5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5leHBvcnQgY29uc3Qgcm91dGVzID0gW1xuICAgIHtcbiAgICAgICAgcGF0aDogXCJcIixcbiAgICAgICAgY29tcG9uZW50OiBDb25maWdDb21wb25lbnQsXG4gICAgfSxcbl07XG5leHBvcnQgY2xhc3MgQ29uZmlnUm91dGluZ01vZHVsZSB7XG59XG5Db25maWdSb3V0aW5nTW9kdWxlLsm1ZmFjID0gZnVuY3Rpb24gQ29uZmlnUm91dGluZ01vZHVsZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBDb25maWdSb3V0aW5nTW9kdWxlKSgpOyB9O1xuQ29uZmlnUm91dGluZ01vZHVsZS7JtW1vZCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZU5nTW9kdWxlKHsgdHlwZTogQ29uZmlnUm91dGluZ01vZHVsZSB9KTtcbkNvbmZpZ1JvdXRpbmdNb2R1bGUuybVpbmogPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVJbmplY3Rvcih7IGltcG9ydHM6IFtOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXG4gICAgICAgIE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZS5mb3JDaGlsZChyb3V0ZXMpXSB9KTtcbiIsImltcG9ydCB7IFBhZ2UgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9jb3JlXCI7XG5pbXBvcnQgeyBTdWJqZWN0IH0gZnJvbSBcInJ4anNcIjtcbmltcG9ydCB7IHRha2VVbnRpbCB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuaW1wb3J0IHsgU2VsZWN0LCBTdG9yZSB9IGZyb20gXCJAbmd4cy9zdG9yZVwiO1xuaW1wb3J0IHsgQ29uZmlnLCBTbGlkZVVwRmFkZVN0YWdnZXIsIENvbmZpZ1N0YXRlLCBJY29ucyB9IGZyb20gXCJAYXBwL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMiBmcm9tIFwiQG5neHMvc3RvcmVcIjtcbmltcG9ydCAqIGFzIGkzIGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCAqIGFzIGk0IGZyb20gXCJAYW5ndWxhci9mb3Jtc1wiO1xuaW1wb3J0ICogYXMgaTUgZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0ICogYXMgaTYgZnJvbSBcIi4uLy4uL3NoYXJlZC9jb21wb25lbnRzL2hlYWRlci9oZWFkZXIuY29tcG9uZW50XCI7XG5mdW5jdGlvbiBDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzdfbmdfY29udGFpbmVyXzFfTGFiZWxfM19UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudCgwLCBcIkxhYmVsXCIsIDEwKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yNiA9IGkwLsm1ybVuZXh0Q29udGV4dCgzKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGN0eF9yNi5pY29uLmNoZWNrKTtcbn0gfVxuZnVuY3Rpb24gQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl83X25nX2NvbnRhaW5lcl8xX1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGNvbnN0IF9yOCA9IGkwLsm1ybVnZXRDdXJyZW50VmlldygpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyU3RhcnQoMCk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCgxLCBcIkdyaWRMYXlvdXRcIiwgNikoMiwgXCJMYWJlbFwiLCA5KTtcbiAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl83X25nX2NvbnRhaW5lcl8xX1RlbXBsYXRlX0xhYmVsX3RhcF8yX2xpc3RlbmVyKCkgeyBjb25zdCByZXN0b3JlZEN0eCA9IGkwLsm1ybVyZXN0b3JlVmlldyhfcjgpOyBjb25zdCBzdHlsZU9wdGlvbl9yNSA9IHJlc3RvcmVkQ3R4LiRpbXBsaWNpdDsgY29uc3QgY3R4X3I3ID0gaTAuybXJtW5leHRDb250ZXh0KDIpOyByZXR1cm4gaTAuybXJtXJlc2V0VmlldyhjdHhfcjcudXBkYXRlU3R5bGluZ1VybChzdHlsZU9wdGlvbl9yNSA9PSBudWxsID8gbnVsbCA6IHN0eWxlT3B0aW9uX3I1LnN0eWxlVXJsKSk7IH0pO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtXRlbXBsYXRlKDMsIENvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfN19uZ19jb250YWluZXJfMV9MYWJlbF8zX1RlbXBsYXRlLCAxLCAxLCBcIkxhYmVsXCIsIDgpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IHN0eWxlT3B0aW9uX3I1ID0gY3R4LiRpbXBsaWNpdDtcbiAgICBjb25zdCBzdHlsZXNfcjIgPSBpMC7Jtcm1bmV4dENvbnRleHQoKS5uZ0lmO1xuICAgIGNvbnN0IGN0eF9yMyA9IGkwLsm1ybVuZXh0Q29udGV4dCgpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVjbGFzc1Byb3AoXCJib2xkXCIsICFjdHhfcjMuZGlzcGxheUN1c3RvbVN0eWxlVGV4dGZpZWxkICYmIHN0eWxlc19yMi5zZWxlY3RlZCA9PT0gKHN0eWxlT3B0aW9uX3I1ID09IG51bGwgPyBudWxsIDogc3R5bGVPcHRpb25fcjUuc3R5bGVVcmwpKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIHN0eWxlT3B0aW9uX3I1ID09IG51bGwgPyBudWxsIDogc3R5bGVPcHRpb25fcjUuZGlzcGxheU5hbWUpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgIWN0eF9yMy5kaXNwbGF5Q3VzdG9tU3R5bGVUZXh0ZmllbGQgJiYgc3R5bGVzX3IyLnNlbGVjdGVkID09PSAoc3R5bGVPcHRpb25fcjUgPT0gbnVsbCA/IG51bGwgOiBzdHlsZU9wdGlvbl9yNS5zdHlsZVVybCkpO1xufSB9XG5mdW5jdGlvbiBDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzdfTGFiZWxfNF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudCgwLCBcIkxhYmVsXCIsIDEwKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yNCA9IGkwLsm1ybVuZXh0Q29udGV4dCgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGN0eF9yNC5pY29uLmNoZWNrKTtcbn0gfVxuZnVuY3Rpb24gQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl83X1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGNvbnN0IF9yMTEgPSBpMC7Jtcm1Z2V0Q3VycmVudFZpZXcoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybV0ZW1wbGF0ZSgxLCBDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzdfbmdfY29udGFpbmVyXzFfVGVtcGxhdGUsIDQsIDQsIFwibmctY29udGFpbmVyXCIsIDUpO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMiwgXCJHcmlkTGF5b3V0XCIsIDYpKDMsIFwiTGFiZWxcIiwgNyk7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwidGFwXCIsIGZ1bmN0aW9uIENvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfN19UZW1wbGF0ZV9MYWJlbF90YXBfM19saXN0ZW5lcigpIHsgaTAuybXJtXJlc3RvcmVWaWV3KF9yMTEpOyBjb25zdCBjdHhfcjEwID0gaTAuybXJtW5leHRDb250ZXh0KCk7IHJldHVybiBpMC7Jtcm1cmVzZXRWaWV3KGN0eF9yMTAudG9nZ2xlQ3VzdG9tU3R5bGUoKSk7IH0pO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtXRlbXBsYXRlKDQsIENvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfN19MYWJlbF80X1RlbXBsYXRlLCAxLCAxLCBcIkxhYmVsXCIsIDgpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IHN0eWxlc19yMiA9IGN0eC5uZ0lmO1xuICAgIGNvbnN0IGN0eF9yMCA9IGkwLsm1ybVuZXh0Q29udGV4dCgpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nRm9yT2ZcIiwgc3R5bGVzX3IyLm9wdGlvbnMpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVjbGFzc1Byb3AoXCJib2xkXCIsIGN0eF9yMC5kaXNwbGF5Q3VzdG9tU3R5bGVUZXh0ZmllbGQpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgY3R4X3IwLmRpc3BsYXlDdXN0b21TdHlsZVRleHRmaWVsZCk7XG59IH1cbmZ1bmN0aW9uIENvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfMTBfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgY29uc3QgX3IxMyA9IGkwLsm1ybVnZXRDdXJyZW50VmlldygpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyU3RhcnQoMCk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCgxLCBcIlRleHRGaWVsZFwiLCAxMSk7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwibmdNb2RlbENoYW5nZVwiLCBmdW5jdGlvbiBDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzEwX1RlbXBsYXRlX1RleHRGaWVsZF9uZ01vZGVsQ2hhbmdlXzFfbGlzdGVuZXIoJGV2ZW50KSB7IGkwLsm1ybVyZXN0b3JlVmlldyhfcjEzKTsgY29uc3QgY3R4X3IxMiA9IGkwLsm1ybVuZXh0Q29udGV4dCgpOyByZXR1cm4gaTAuybXJtXJlc2V0VmlldyhjdHhfcjEyLnN0eWxpbmdVcmwgPSAkZXZlbnQpOyB9KTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMiwgXCJCdXR0b25cIiwgMTIpO1xuICAgIGkwLsm1ybVsaXN0ZW5lcihcInRhcFwiLCBmdW5jdGlvbiBDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzEwX1RlbXBsYXRlX0J1dHRvbl90YXBfMl9saXN0ZW5lcigpIHsgaTAuybXJtXJlc3RvcmVWaWV3KF9yMTMpOyBjb25zdCBjdHhfcjE0ID0gaTAuybXJtW5leHRDb250ZXh0KCk7IHJldHVybiBpMC7Jtcm1cmVzZXRWaWV3KGN0eF9yMTQudXBkYXRlVXJscygpKTsgfSk7XG4gICAgaTAuybXJtXBpcGUoMywgXCJhc3luY1wiKTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBjdHhfcjEgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTtcbiAgICBsZXQgdG1wXzFfMDtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ01vZGVsXCIsIGN0eF9yMS5zdHlsaW5nVXJsKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsICgodG1wXzFfMCA9IGkwLsm1ybVwaXBlQmluZDEoMywgMiwgY3R4X3IxLnN0YXRpY1RleHQkKSkgPT0gbnVsbCA/IG51bGwgOiB0bXBfMV8wLmNvbmZpZyA9PSBudWxsID8gbnVsbCA6IHRtcF8xXzAuY29uZmlnLmJ1dHRvbnMgPT0gbnVsbCA/IG51bGwgOiB0bXBfMV8wLmNvbmZpZy5idXR0b25zLnVwZGF0ZSkgfHwgXCJVUERBVEVcIik7XG59IH1cbmNvbnN0IF9jMCA9IGZ1bmN0aW9uIChhMCwgYTEpIHsgcmV0dXJuIHsgc2VsZWN0ZWQ6IGEwLCBvcHRpb25zOiBhMSB9OyB9O1xuZXhwb3J0IGNsYXNzIENvbmZpZ0NvbXBvbmVudCB7XG4gICAgY29uc3RydWN0b3IocGFnZSwgc3RvcmUpIHtcbiAgICAgICAgdGhpcy5wYWdlID0gcGFnZTtcbiAgICAgICAgdGhpcy5zdG9yZSA9IHN0b3JlO1xuICAgICAgICB0aGlzLmRpc3BsYXlDdXN0b21TdHlsZVRleHRmaWVsZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmljb24gPSBJY29ucztcbiAgICAgICAgdGhpcy5fZGVzdHJveSQgPSBuZXcgU3ViamVjdCgpO1xuICAgICAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5zdG9yZVxuICAgICAgICAgICAgLnNlbGVjdChDb25maWdTdGF0ZS5kYXRhVXJsKVxuICAgICAgICAgICAgLnBpcGUodGFrZVVudGlsKHRoaXMuX2Rlc3Ryb3kkKSlcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKHN0YXRlRGF0YVVybCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5kYXRhVXJsID0gc3RhdGVEYXRhVXJsO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zdG9yZVxuICAgICAgICAgICAgLnNlbGVjdChDb25maWdTdGF0ZS5zdHlsaW5nVXJsKVxuICAgICAgICAgICAgLnBpcGUodGFrZVVudGlsKHRoaXMuX2Rlc3Ryb3kkKSlcbiAgICAgICAgICAgIC5zdWJzY3JpYmUoKHN0YXRlU3R5bGluZ1VybCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zdHlsaW5nVXJsID0gc3RhdGVTdHlsaW5nVXJsO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5zdG9yZS5kaXNwYXRjaChuZXcgQ29uZmlnLlVwZGF0ZVN0eWxlT3B0aW9ucygpKTtcbiAgICB9XG4gICAgbmdPbkRlc3Ryb3koKSB7XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3kkLm5leHQodHJ1ZSk7XG4gICAgICAgIHRoaXMuX2Rlc3Ryb3kkLmNvbXBsZXRlKCk7XG4gICAgfVxuICAgIHRvZ2dsZUN1c3RvbVN0eWxlKCkge1xuICAgICAgICB0aGlzLmRpc3BsYXlDdXN0b21TdHlsZVRleHRmaWVsZCA9ICF0aGlzLmRpc3BsYXlDdXN0b21TdHlsZVRleHRmaWVsZDtcbiAgICB9XG4gICAgdXBkYXRlU3R5bGluZ1VybCh1cmwpIHtcbiAgICAgICAgdGhpcy5zdG9yZS5kaXNwYXRjaChuZXcgQ29uZmlnLlVwZGF0ZVN0eWxpbmdVcmwodXJsKSk7XG4gICAgICAgIC8vIGhpZGUgY3VzdG9tIHRleHRmaWVsZFxuICAgICAgICB0aGlzLmRpc3BsYXlDdXN0b21TdHlsZVRleHRmaWVsZCA9IGZhbHNlO1xuICAgIH1cbiAgICB1cGRhdGVVcmxzKCkge1xuICAgICAgICB0aGlzLnN0b3JlXG4gICAgICAgICAgICAuZGlzcGF0Y2gobmV3IENvbmZpZy5VcGRhdGVEYXRhVXJsKHRoaXMuZGF0YVVybCkpXG4gICAgICAgICAgICAudG9Qcm9taXNlKClcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc3RvcmUuZGlzcGF0Y2gobmV3IENvbmZpZy5VcGRhdGVTdHlsaW5nVXJsKHRoaXMuc3R5bGluZ1VybCkpO1xuICAgICAgICB9KTtcbiAgICB9XG59XG5Db25maWdDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBDb25maWdDb21wb25lbnRfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgQ29uZmlnQ29tcG9uZW50KShpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkxLlBhZ2UpLCBpMC7Jtcm1ZGlyZWN0aXZlSW5qZWN0KGkyLlN0b3JlKSk7IH07XG5Db25maWdDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBDb25maWdDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLWNvbmZpZ1wiXV0sIGRlY2xzOiAxMSwgdmFyczogMTUsIGNvbnN0czogW1tcImhlaWdodFwiLCBcIjEwMCVcIl0sIFtcImhhc01lbnVCdXR0b25cIiwgXCJ0cnVlXCIsIDMsIFwiaGVhZGVyVGl0bGVcIl0sIFsxLCBcInAteGxcIl0sIFsxLCBcImZvbnQtc2l6ZS1oMVwiLCBcIm0tYi1sXCIsIDMsIFwidGV4dFwiXSwgWzQsIFwibmdJZlwiXSwgWzQsIFwibmdGb3JcIiwgXCJuZ0Zvck9mXCJdLCBbXCJjb2x1bW5zXCIsIFwiKiwgNTBcIl0sIFtcInRleHRcIiwgXCJDdXN0b21cIiwgMSwgXCJmb250LXNpemUtaDNcIiwgXCJwLXNcIiwgXCJtLXQtc1wiLCAzLCBcInRhcFwiXSwgW1wiY29sXCIsIFwiMVwiLCBcImNsYXNzXCIsIFwiaW9uaWNvbnMgZm9udC1zaXplLWgxIHRleHQtY29sb3ItcHJpbWFyeVwiLCAzLCBcInRleHRcIiwgNCwgXCJuZ0lmXCJdLCBbMSwgXCJmb250LXNpemUtaDNcIiwgXCJwLXNcIiwgXCJtLXQtc1wiLCAzLCBcInRleHRcIiwgXCJ0YXBcIl0sIFtcImNvbFwiLCBcIjFcIiwgMSwgXCJpb25pY29uc1wiLCBcImZvbnQtc2l6ZS1oMVwiLCBcInRleHQtY29sb3ItcHJpbWFyeVwiLCAzLCBcInRleHRcIl0sIFtcImhpbnRcIiwgXCJodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vLi4uXCIsIDEsIFwiZm9udC1zaXplLWgzXCIsIFwicC1zXCIsIFwibS10LXNcIiwgXCJib3JkZXItYi1wcmltYXJ5XCIsIDMsIFwibmdNb2RlbFwiLCBcIm5nTW9kZWxDaGFuZ2VcIl0sIFsxLCBcImJ1dHRvbi1wcmltYXJ5XCIsIFwibWVkaXVtXCIsIFwibS10LXhsXCIsIDMsIFwidGV4dFwiLCBcInRhcFwiXV0sIHRlbXBsYXRlOiBmdW5jdGlvbiBDb25maWdDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJTY3JvbGxWaWV3XCIsIDApKDEsIFwiU3RhY2tMYXlvdXRcIik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDIsIFwibnMtaGVhZGVyXCIsIDEpO1xuICAgICAgICBpMC7Jtcm1cGlwZSgzLCBcImFzeW5jXCIpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDQsIFwiU3RhY2tMYXlvdXRcIiwgMik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDUsIFwiTGFiZWxcIiwgMyk7XG4gICAgICAgIGkwLsm1ybVwaXBlKDYsIFwiYXN5bmNcIik7XG4gICAgICAgIGkwLsm1ybV0ZW1wbGF0ZSg3LCBDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzdfVGVtcGxhdGUsIDUsIDQsIFwibmctY29udGFpbmVyXCIsIDQpO1xuICAgICAgICBpMC7Jtcm1cGlwZSg4LCBcImFzeW5jXCIpO1xuICAgICAgICBpMC7Jtcm1cGlwZSg5LCBcImFzeW5jXCIpO1xuICAgICAgICBpMC7Jtcm1dGVtcGxhdGUoMTAsIENvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfMTBfVGVtcGxhdGUsIDQsIDQsIFwibmctY29udGFpbmVyXCIsIDQpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpKCkoKTtcbiAgICB9IGlmIChyZiAmIDIpIHtcbiAgICAgICAgbGV0IHRtcF8wXzA7XG4gICAgICAgIGxldCB0bXBfMV8wO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwiaGVhZGVyVGl0bGVcIiwgKCh0bXBfMF8wID0gaTAuybXJtXBpcGVCaW5kMSgzLCA0LCBjdHguc3RhdGljVGV4dCQpKSA9PSBudWxsID8gbnVsbCA6IHRtcF8wXzAuY29uZmlnID09IG51bGwgPyBudWxsIDogdG1wXzBfMC5jb25maWcudGl0bGUpIHx8IFwiU0VUVElOR1NcIik7XG4gICAgICAgIGkwLsm1ybVhZHZhbmNlKDMpO1xuICAgICAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsICgodG1wXzFfMCA9IGkwLsm1ybVwaXBlQmluZDEoNiwgNiwgY3R4LnN0YXRpY1RleHQkKSkgPT0gbnVsbCA/IG51bGwgOiB0bXBfMV8wLmNvbmZpZyA9PSBudWxsID8gbnVsbCA6IHRtcF8xXzAuY29uZmlnLnN0eWxpbmdVcmxUaXRsZSkgfHwgXCJTdHlsaW5nXCIpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBpMC7Jtcm1cHVyZUZ1bmN0aW9uMigxMiwgX2MwLCBpMC7Jtcm1cGlwZUJpbmQxKDgsIDgsIGN0eC5zdHlsaW5nVXJsJCksIGkwLsm1ybVwaXBlQmluZDEoOSwgMTAsIGN0eC5zdHlsZU9wdGlvbnMkKSkpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBjdHguZGlzcGxheUN1c3RvbVN0eWxlVGV4dGZpZWxkKTtcbiAgICB9IH0sIGRlcGVuZGVuY2llczogW2kzLk5nRm9yT2YsIGkzLk5nSWYsIGk0Lk5nQ29udHJvbFN0YXR1cywgaTQuTmdNb2RlbCwgaTUuVGV4dFZhbHVlQWNjZXNzb3IsIGk2LkhlYWRlckNvbXBvbmVudCwgaTMuQXN5bmNQaXBlXSwgZW5jYXBzdWxhdGlvbjogMiwgZGF0YTogeyBhbmltYXRpb246IFtTbGlkZVVwRmFkZVN0YWdnZXJdIH0gfSk7XG5fX2RlY29yYXRlKFtcbiAgICBTZWxlY3QoQ29uZmlnU3RhdGUuc3RhdGljVGV4dCksXG4gICAgX19tZXRhZGF0YShcImRlc2lnbjp0eXBlXCIsIE9iamVjdClcbl0sIENvbmZpZ0NvbXBvbmVudC5wcm90b3R5cGUsIFwic3RhdGljVGV4dCRcIiwgdm9pZCAwKTtcbl9fZGVjb3JhdGUoW1xuICAgIFNlbGVjdChDb25maWdTdGF0ZS5zdHlsZU9wdGlvbnMpLFxuICAgIF9fbWV0YWRhdGEoXCJkZXNpZ246dHlwZVwiLCBPYmplY3QpXG5dLCBDb25maWdDb21wb25lbnQucHJvdG90eXBlLCBcInN0eWxlT3B0aW9ucyRcIiwgdm9pZCAwKTtcbl9fZGVjb3JhdGUoW1xuICAgIFNlbGVjdChDb25maWdTdGF0ZS5zdHlsaW5nVXJsKSxcbiAgICBfX21ldGFkYXRhKFwiZGVzaWduOnR5cGVcIiwgT2JqZWN0KVxuXSwgQ29uZmlnQ29tcG9uZW50LnByb3RvdHlwZSwgXCJzdHlsaW5nVXJsJFwiLCB2b2lkIDApO1xuIiwiaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0IHsgU2hhcmVkTW9kdWxlIH0gZnJvbSBcIkBhcHAvc2hhcmVkXCI7XG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLCB9IGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmltcG9ydCB7IENvbmZpZ1JvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9jb25maWctcm91dGluZy5tb2R1bGVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5leHBvcnQgY2xhc3MgQ29uZmlnTW9kdWxlIHtcbn1cbkNvbmZpZ01vZHVsZS7JtWZhYyA9IGZ1bmN0aW9uIENvbmZpZ01vZHVsZV9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBDb25maWdNb2R1bGUpKCk7IH07XG5Db25maWdNb2R1bGUuybVtb2QgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVOZ01vZHVsZSh7IHR5cGU6IENvbmZpZ01vZHVsZSB9KTtcbkNvbmZpZ01vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW05hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcbiAgICAgICAgTmF0aXZlU2NyaXB0Rm9ybXNNb2R1bGUsXG4gICAgICAgIENvbW1vbk1vZHVsZSxcbiAgICAgICAgQ29uZmlnUm91dGluZ01vZHVsZSxcbiAgICAgICAgU2hhcmVkTW9kdWxlXSB9KTtcbiJdLCJuYW1lcyI6WyJQYWdlIiwiU3ViamVjdCIsInRha2VVbnRpbCIsIlNlbGVjdCIsIlN0b3JlIiwiQ29uZmlnIiwiU2xpZGVVcEZhZGVTdGFnZ2VyIiwiQ29uZmlnU3RhdGUiLCJJY29ucyIsImkwIiwiaTEiLCJpMiIsImkzIiwiaTQiLCJpNSIsImk2IiwiQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl83X25nX2NvbnRhaW5lcl8xX0xhYmVsXzNfVGVtcGxhdGUiLCJyZiIsImN0eCIsIsm1ybVlbGVtZW50IiwiY3R4X3I2IiwiybXJtW5leHRDb250ZXh0IiwiybXJtXByb3BlcnR5IiwiaWNvbiIsImNoZWNrIiwiQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl83X25nX2NvbnRhaW5lcl8xX1RlbXBsYXRlIiwiX3I4IiwiybXJtWdldEN1cnJlbnRWaWV3IiwiybXJtWVsZW1lbnRDb250YWluZXJTdGFydCIsIsm1ybVlbGVtZW50U3RhcnQiLCLJtcm1bGlzdGVuZXIiLCJDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzdfbmdfY29udGFpbmVyXzFfVGVtcGxhdGVfTGFiZWxfdGFwXzJfbGlzdGVuZXIiLCJyZXN0b3JlZEN0eCIsIsm1ybVyZXN0b3JlVmlldyIsInN0eWxlT3B0aW9uX3I1IiwiJGltcGxpY2l0IiwiY3R4X3I3IiwiybXJtXJlc2V0VmlldyIsInVwZGF0ZVN0eWxpbmdVcmwiLCJzdHlsZVVybCIsIsm1ybVlbGVtZW50RW5kIiwiybXJtXRlbXBsYXRlIiwiybXJtWVsZW1lbnRDb250YWluZXJFbmQiLCJzdHlsZXNfcjIiLCJuZ0lmIiwiY3R4X3IzIiwiybXJtWFkdmFuY2UiLCLJtcm1Y2xhc3NQcm9wIiwiZGlzcGxheUN1c3RvbVN0eWxlVGV4dGZpZWxkIiwic2VsZWN0ZWQiLCJkaXNwbGF5TmFtZSIsIkNvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfN19MYWJlbF80X1RlbXBsYXRlIiwiY3R4X3I0IiwiQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl83X1RlbXBsYXRlIiwiX3IxMSIsIkNvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfN19UZW1wbGF0ZV9MYWJlbF90YXBfM19saXN0ZW5lciIsImN0eF9yMTAiLCJ0b2dnbGVDdXN0b21TdHlsZSIsImN0eF9yMCIsIm9wdGlvbnMiLCJDb25maWdDb21wb25lbnRfbmdfY29udGFpbmVyXzEwX1RlbXBsYXRlIiwiX3IxMyIsIkNvbmZpZ0NvbXBvbmVudF9uZ19jb250YWluZXJfMTBfVGVtcGxhdGVfVGV4dEZpZWxkX25nTW9kZWxDaGFuZ2VfMV9saXN0ZW5lciIsIiRldmVudCIsImN0eF9yMTIiLCJzdHlsaW5nVXJsIiwiQ29uZmlnQ29tcG9uZW50X25nX2NvbnRhaW5lcl8xMF9UZW1wbGF0ZV9CdXR0b25fdGFwXzJfbGlzdGVuZXIiLCJjdHhfcjE0IiwidXBkYXRlVXJscyIsIsm1ybVwaXBlIiwiY3R4X3IxIiwidG1wXzFfMCIsIsm1ybVwaXBlQmluZDEiLCJzdGF0aWNUZXh0JCIsImNvbmZpZyIsImJ1dHRvbnMiLCJ1cGRhdGUiLCJfYzAiLCJhMCIsImExIiwiQ29uZmlnQ29tcG9uZW50IiwiY29uc3RydWN0b3IiLCJwYWdlIiwic3RvcmUiLCJfZGVzdHJveSQiLCJhY3Rpb25CYXJIaWRkZW4iLCJzZWxlY3QiLCJkYXRhVXJsIiwicGlwZSIsInN1YnNjcmliZSIsInN0YXRlRGF0YVVybCIsInN0YXRlU3R5bGluZ1VybCIsImRpc3BhdGNoIiwiVXBkYXRlU3R5bGVPcHRpb25zIiwibmdPbkRlc3Ryb3kiLCJuZXh0IiwiY29tcGxldGUiLCJ1cmwiLCJVcGRhdGVTdHlsaW5nVXJsIiwiVXBkYXRlRGF0YVVybCIsInRvUHJvbWlzZSIsInRoZW4iLCLJtWZhYyIsIkNvbmZpZ0NvbXBvbmVudF9GYWN0b3J5IiwidCIsIsm1ybVkaXJlY3RpdmVJbmplY3QiLCLJtWNtcCIsIsm1ybVkZWZpbmVDb21wb25lbnQiLCJ0eXBlIiwic2VsZWN0b3JzIiwiZGVjbHMiLCJ2YXJzIiwiY29uc3RzIiwidGVtcGxhdGUiLCJDb25maWdDb21wb25lbnRfVGVtcGxhdGUiLCJ0bXBfMF8wIiwidGl0bGUiLCJzdHlsaW5nVXJsVGl0bGUiLCLJtcm1cHVyZUZ1bmN0aW9uMiIsInN0eWxpbmdVcmwkIiwic3R5bGVPcHRpb25zJCIsImRlcGVuZGVuY2llcyIsIk5nRm9yT2YiLCJOZ0lmIiwiTmdDb250cm9sU3RhdHVzIiwiTmdNb2RlbCIsIlRleHRWYWx1ZUFjY2Vzc29yIiwiSGVhZGVyQ29tcG9uZW50IiwiQXN5bmNQaXBlIiwiZW5jYXBzdWxhdGlvbiIsImRhdGEiLCJhbmltYXRpb24iLCJfX2RlY29yYXRlIiwic3RhdGljVGV4dCIsIl9fbWV0YWRhdGEiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJzdHlsZU9wdGlvbnMiXSwic291cmNlUm9vdCI6IiJ9