"use strict";
exports.id = "src_app_features_other-apps_other-apps_module_ts";
exports.ids = ["src_app_features_other-apps_other-apps_module_ts"];
exports.modules = {

/***/ "./src/app/features/other-apps/other-apps-routing.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OtherAppsRoutingModule": () => (/* binding */ OtherAppsRoutingModule),
/* harmony export */   "routes": () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



const routes = [
    {
        path: "furniture",
        loadChildren: () => __webpack_require__.e(/* import() */ "src_app_features_other-apps_furniture_furniture_module_ts").then(__webpack_require__.bind(__webpack_require__, "./src/app/features/other-apps/furniture/furniture.module.ts")).then((m) => m.FurnitureModule),
    },
];
class OtherAppsRoutingModule {
}
OtherAppsRoutingModule.ɵfac = function OtherAppsRoutingModule_Factory(t) { return new (t || OtherAppsRoutingModule)(); };
OtherAppsRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({ type: OtherAppsRoutingModule });
OtherAppsRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_1__.NativeScriptRouterModule.forChild(routes)] });


/***/ }),

/***/ "./src/app/features/other-apps/other-apps.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OtherAppsModule": () => (/* binding */ OtherAppsModule)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _other_apps_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/other-apps/other-apps-routing.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



class OtherAppsModule {
}
OtherAppsModule.ɵfac = function OtherAppsModule_Factory(t) { return new (t || OtherAppsModule)(); };
OtherAppsModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: OtherAppsModule });
OtherAppsModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptFormsModule,
        _other_apps_routing_module__WEBPACK_IMPORTED_MODULE_0__.OtherAppsRoutingModule] });


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2FwcF9mZWF0dXJlc19vdGhlci1hcHBzX290aGVyLWFwcHNfbW9kdWxlX3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUE0RjtBQUN4RDtBQUNRO0FBQ3JDO0FBQ1A7QUFDQTtBQUNBLDRCQUE0QixvTkFBc0M7QUFDbEUsS0FBSztBQUNMO0FBQ087QUFDUDtBQUNBLDJFQUEyRTtBQUMzRSw0Q0FBNEMsOERBQW1CLEdBQUcsOEJBQThCO0FBQ2hHLDRDQUE0Qyw4REFBbUIsR0FBRyxVQUFVLDJFQUF3QjtBQUNwRyxRQUFRLG9GQUFpQyxXQUFXOzs7Ozs7Ozs7Ozs7Ozs7QUNkdUM7QUFDdEI7QUFDakM7QUFDN0I7QUFDUDtBQUNBLDZEQUE2RDtBQUM3RCxxQ0FBcUMsOERBQW1CLEdBQUcsdUJBQXVCO0FBQ2xGLHFDQUFxQyw4REFBbUIsR0FBRyxVQUFVLDJFQUF3QjtBQUM3RixRQUFRLDBFQUF1QjtBQUMvQixRQUFRLDhFQUFzQixHQUFHIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvZmVhdHVyZXMvb3RoZXItYXBwcy9vdGhlci1hcHBzLXJvdXRpbmcubW9kdWxlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL290aGVyLWFwcHMvb3RoZXItYXBwcy5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLCBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUsIH0gZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0ICogYXMgaTAgZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCAqIGFzIGkxIGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmV4cG9ydCBjb25zdCByb3V0ZXMgPSBbXG4gICAge1xuICAgICAgICBwYXRoOiBcImZ1cm5pdHVyZVwiLFxuICAgICAgICBsb2FkQ2hpbGRyZW46ICgpID0+IGltcG9ydChcIi4vZnVybml0dXJlL2Z1cm5pdHVyZS5tb2R1bGVcIikudGhlbigobSkgPT4gbS5GdXJuaXR1cmVNb2R1bGUpLFxuICAgIH0sXG5dO1xuZXhwb3J0IGNsYXNzIE90aGVyQXBwc1JvdXRpbmdNb2R1bGUge1xufVxuT3RoZXJBcHBzUm91dGluZ01vZHVsZS7JtWZhYyA9IGZ1bmN0aW9uIE90aGVyQXBwc1JvdXRpbmdNb2R1bGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgT3RoZXJBcHBzUm91dGluZ01vZHVsZSkoKTsgfTtcbk90aGVyQXBwc1JvdXRpbmdNb2R1bGUuybVtb2QgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVOZ01vZHVsZSh7IHR5cGU6IE90aGVyQXBwc1JvdXRpbmdNb2R1bGUgfSk7XG5PdGhlckFwcHNSb3V0aW5nTW9kdWxlLsm1aW5qID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lSW5qZWN0b3IoeyBpbXBvcnRzOiBbTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLFxuICAgICAgICBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUuZm9yQ2hpbGQocm91dGVzKV0gfSk7XG4iLCJpbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLCB9IGZyb20gXCJAbmF0aXZlc2NyaXB0L2FuZ3VsYXJcIjtcbmltcG9ydCB7IE90aGVyQXBwc1JvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9vdGhlci1hcHBzLXJvdXRpbmcubW9kdWxlXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuZXhwb3J0IGNsYXNzIE90aGVyQXBwc01vZHVsZSB7XG59XG5PdGhlckFwcHNNb2R1bGUuybVmYWMgPSBmdW5jdGlvbiBPdGhlckFwcHNNb2R1bGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgT3RoZXJBcHBzTW9kdWxlKSgpOyB9O1xuT3RoZXJBcHBzTW9kdWxlLsm1bW9kID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lTmdNb2R1bGUoeyB0eXBlOiBPdGhlckFwcHNNb2R1bGUgfSk7XG5PdGhlckFwcHNNb2R1bGUuybVpbmogPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVJbmplY3Rvcih7IGltcG9ydHM6IFtOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXG4gICAgICAgIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLFxuICAgICAgICBPdGhlckFwcHNSb3V0aW5nTW9kdWxlXSB9KTtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==