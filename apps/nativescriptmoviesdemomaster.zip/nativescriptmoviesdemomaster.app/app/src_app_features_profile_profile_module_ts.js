"use strict";
exports.id = "src_app_features_profile_profile_module_ts";
exports.ids = ["src_app_features_profile_profile_module_ts"];
exports.modules = {

/***/ "./src/app/features/profile/profile-card-back/profile-card-back.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileCardBackComponent": () => (/* binding */ ProfileCardBackComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@angular/forms/fesm2015/forms.mjs");
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");






function ProfileCardBackComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    const _r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "GridLayout", 7);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function ProfileCardBackComponent_ng_container_3_Template_GridLayout_tap_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2); const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r1.onSave()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "Label", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "TextField", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function ProfileCardBackComponent_ng_container_3_Template_TextField_ngModelChange_4_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2); const ctx_r3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r3.profile.displayName = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "Label", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](6, "TextField", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function ProfileCardBackComponent_ng_container_3_Template_TextField_ngModelChange_6_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2); const ctx_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r4.profile.username = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](7, "Label", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](8, "TextField", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("ngModelChange", function ProfileCardBackComponent_ng_container_3_Template_TextField_ngModelChange_8_listener($event) { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r2); const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r5.profile.bio = $event); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.icons.save);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx_r0.profile.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx_r0.profile.username);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngModel", ctx_r0.profile.bio);
} }
class ProfileCardBackComponent {
    constructor() {
        this.save = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
        this.icons = _core__WEBPACK_IMPORTED_MODULE_0__.Icons;
    }
    onSave() {
        this.save.emit(this.profile);
    }
}
ProfileCardBackComponent.ɵfac = function ProfileCardBackComponent_Factory(t) { return new (t || ProfileCardBackComponent)(); };
ProfileCardBackComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ProfileCardBackComponent, selectors: [["ns-profile-card-back"]], inputs: { profile: "profile" }, outputs: { save: "save" }, decls: 7, vars: 2, consts: [["height", "650", "rows", "auto, *"], ["row", "1", "boxShadow", "0 0 5 0 rgba(0,0,0,0.5)"], ["row", "1", "marginTop", "-75", "backgroundColor", "white", "borderRadius", "10", "padding", "25 30"], [4, "ngIf"], ["height", "150", "width", "150", "borderRadius", "75", "backgroundColor", "#000", "borderWidth", "5", "borderColor", "white"], ["height", "150", "width", "150", "borderRadius", "75", "opacity", "0.5", "src", "~/assets/images/profile/profile-pic.png", "stretch", "aspectFill"], ["verticalAlignment", "center", "horizontalAlignment", "center", "color", "white", "fontSize", "50", 1, "ionicons", 3, "text"], ["height", "40", "width", "40", "rows", "*", "columns", "*", "horizontalAlignment", "right", 3, "tap"], ["horizontalAlignment", "right", "verticalAlignment", "top", 1, "ionicons", "font-size-h1", "text-color-primary", 3, "text"], ["text", "Display Name", "color", "#aaa", "fontSize", "17", "marginTop", "40"], ["fontSize", "25", "color", "#777", "marginTop", "5", "borderBottomWidth", "2", "borderBottomColor", "#aaa", 3, "ngModel", "ngModelChange"], ["text", "Username", "color", "#aaa", "fontSize", "17", "marginTop", "40"], ["text", "Bio", "color", "#aaa", "fontSize", "17", "marginTop", "40"]], template: function ProfileCardBackComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "ContentView", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "StackLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, ProfileCardBackComponent_ng_container_3_Template, 9, 4, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](4, "GridLayout", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](5, "Image", 5)(6, "Label", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.profile);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx.icons.edit);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_3__.NgModel, _nativescript_angular__WEBPACK_IMPORTED_MODULE_4__.TextValueAccessor], encapsulation: 2 });


/***/ }),

/***/ "./src/app/features/profile/profile-card-front/profile-card-front.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileCardFrontComponent": () => (/* binding */ ProfileCardFrontComponent)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/core/index.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@angular/common/fesm2015/common.mjs");




function ProfileCardFrontComponent_ng_container_3_ng_container_12_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "Label", 16)(2, "Label", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r1.profile.bio);
} }
function ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Label_3_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "Label", 24);
} if (rf & 2) {
    const ctx_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r5.icons.filmOutline);
} }
function ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Label_4_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "Label", 24);
} if (rf & 2) {
    const ctx_r6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r6.icons.comment);
} }
function ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Label_5_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](0, "Label", 24);
} if (rf & 2) {
    const ctx_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r7.icons.heartOutline);
} }
function ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "StackLayout", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](2, 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Label_3_Template, 1, 1, "Label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](4, ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Label_4_Template, 1, 1, "Label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](5, ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Label_5_Template, 1, 1, "Label", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "Label", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const activity_r4 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitch", activity_r4.type);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "watched");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "reviewed");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngSwitchCase", "liked");
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", activity_r4.message);
} }
function ProfileCardFrontComponent_ng_container_3_ng_container_13_Template(rf, ctx) { if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "Label", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](2, ProfileCardFrontComponent_ng_container_3_ng_container_13_ng_container_2_Template, 7, 5, "ng-container", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngForOf", ctx_r2.profile.recentActivities);
} }
function ProfileCardFrontComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](1, "GridLayout", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵlistener"]("tap", function ProfileCardFrontComponent_ng_container_3_Template_GridLayout_tap_1_listener() { _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵrestoreView"](_r9); const ctx_r8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"](); return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵresetView"](ctx_r8.onEdit()); });
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](2, "Label", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](3, "Label", 7)(4, "Label", 8);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](5, "GridLayout", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](6, "Label", 10)(7, "Label", 11)(8, "Label", 12)(9, "Label", 13)(10, "Label", 14)(11, "Label", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](12, ProfileCardFrontComponent_ng_container_3_ng_container_12_Template, 3, 1, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](13, ProfileCardFrontComponent_ng_container_3_ng_container_13_Template, 3, 1, "ng-container", 3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementContainerEnd"]();
} if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.icons.edit);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.profile.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.profile.username);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.profile == null ? null : ctx_r0.profile.posts);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.profile == null ? null : ctx_r0.profile.followers);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("text", ctx_r0.profile == null ? null : ctx_r0.profile.following);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx_r0.profile.bio);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", (ctx_r0.profile.recentActivities == null ? null : ctx_r0.profile.recentActivities.length) > 0);
} }
class ProfileCardFrontComponent {
    constructor() {
        this.edit = new _angular_core__WEBPACK_IMPORTED_MODULE_1__.EventEmitter();
        this.icons = _core__WEBPACK_IMPORTED_MODULE_0__.Icons;
    }
    onEdit() {
        this.edit.emit();
    }
}
ProfileCardFrontComponent.ɵfac = function ProfileCardFrontComponent_Factory(t) { return new (t || ProfileCardFrontComponent)(); };
ProfileCardFrontComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineComponent"]({ type: ProfileCardFrontComponent, selectors: [["ns-profile-card-front"]], inputs: { profile: "profile" }, outputs: { edit: "edit" }, decls: 5, vars: 1, consts: [["height", "650", "rows", "auto, *"], ["row", "1", "boxShadow", "0 0 5 0 rgba(0,0,0,0.5)"], ["row", "1", "marginTop", "-75", "backgroundColor", "white", "borderRadius", "10", "padding", "25"], [4, "ngIf"], ["height", "150", "width", "150", "borderRadius", "75", "borderWidth", "5", "borderColor", "white", "src", "~/assets/images/profile/profile-pic.png", "stretch", "aspectFill"], ["height", "40", "width", "40", "rows", "*", "columns", "*", "horizontalAlignment", "right", 3, "tap"], ["horizontalAlignment", "right", "verticalAlignment", "top", 1, "ionicons", "font-size-h1", "text-color-primary", 3, "text"], ["color", "#777", "marginTop", "40", "horizontalAlignment", "center", "fontSize", "35", 3, "text"], ["fontSize", "20", "horizontalAlignment", "center", "color", "#aaa", 3, "text"], ["rows", "auto, auto", "columns", "*, *, *", "marginTop", "20"], ["row", "0", "col", "0", "color", "#aaa", "fontSize", "18", "horizontalAlignment", "center", "text", "Posts"], ["row", "1", "col", "0", "color", "#888", "fontSize", "30", "horizontalAlignment", "center", 3, "text"], ["row", "0", "col", "1", "color", "#aaa", "fontSize", "18", "horizontalAlignment", "center", "text", "Followers"], ["row", "1", "col", "1", "color", "#888", "fontSize", "30", "horizontalAlignment", "center", 3, "text"], ["row", "0", "col", "2", "color", "#aaa", "fontSize", "18", "horizontalAlignment", "center", "text", "Following"], ["row", "1", "col", "2", "color", "#888", "fontSize", "30", "horizontalAlignment", "center", 3, "text"], ["marginTop", "20", "marginBottom", "5", "text", "Bio", "fontSize", "15", "color", "#aaa"], ["fontSize", "23", "color", "#777", 3, "text"], ["marginTop", "20", "marginBottom", "10", "text", "Recent Activities", "fontSize", "15", "color", "#aaa"], [4, "ngFor", "ngForOf"], ["orientation", "horizontal", "marginTop", "5"], [3, "ngSwitch"], ["verticalAlignment", "center", "class", "ionicons font-size-h1 text-color-primary", 3, "text", 4, "ngSwitchCase"], ["color", "#777", "fontSize", "18", "marginLeft", "10", "verticalAlignment", "center", "textWrap", "true", 3, "text"], ["verticalAlignment", "center", 1, "ionicons", "font-size-h1", "text-color-primary", 3, "text"]], template: function ProfileCardFrontComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](1, "ContentView", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementStart"](2, "StackLayout", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵtemplate"](3, ProfileCardFrontComponent_ng_container_3_Template, 14, 8, "ng-container", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelement"](4, "Image", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵelementEnd"]();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵproperty"]("ngIf", ctx.profile);
    } }, dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_2__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgIf, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgSwitch, _angular_common__WEBPACK_IMPORTED_MODULE_2__.NgSwitchCase], encapsulation: 2 });


/***/ }),

/***/ "./src/app/features/profile/profile-routing.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileRoutingModule": () => (/* binding */ ProfileRoutingModule),
/* harmony export */   "routes": () => (/* binding */ routes)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _profile_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/profile/profile.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");




const routes = [
    {
        path: "",
        component: _profile_component__WEBPACK_IMPORTED_MODULE_0__.ProfileComponent,
    },
];
class ProfileRoutingModule {
}
ProfileRoutingModule.ɵfac = function ProfileRoutingModule_Factory(t) { return new (t || ProfileRoutingModule)(); };
ProfileRoutingModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: ProfileRoutingModule });
ProfileRoutingModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptRouterModule.forChild(routes)] });


/***/ }),

/***/ "./src/app/features/profile/profile.component.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileComponent": () => (/* binding */ ProfileComponent)
/* harmony export */ });
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/core/core-types/index.js");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("./node_modules/@nativescript/core/ui/animation/index.ios.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");
/* harmony import */ var _nativescript_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./node_modules/@nativescript/core/ui/page/index.ios.js");
/* harmony import */ var _profile_card_front_profile_card_front_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/profile/profile-card-front/profile-card-front.component.ts");
/* harmony import */ var _profile_card_back_profile_card_back_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./src/app/features/profile/profile-card-back/profile-card-back.component.ts");






const _c0 = ["front"];
const _c1 = ["back"];
class ProfileComponent {
    constructor(page) {
        this.page = page;
        this.profileData = {
            displayName: "Luca Giraffe",
            username: "mrtallguy",
            posts: 15,
            followers: 200,
            following: 150,
            bio: "I like Shark Movies",
            recentActivities: [
                {
                    type: "reviewed",
                    message: 'Added Movie review for "Sharknado"',
                },
                {
                    type: "watched",
                    message: 'Watched "Jaws"',
                },
                {
                    type: "liked",
                    message: 'Liked "Deep Blue Sea"',
                },
                {
                    type: "watched",
                    message: 'Watched "Deep Blue Sea"',
                },
            ],
        };
        this.editMode = false;
        this.page.actionBarHidden = true;
    }
    backLoaded() {
        this.initializeCards();
    }
    onEdit() {
        if (!this.editMode) {
            this.flipToBack().then(() => {
                this.editMode = true;
            });
        }
    }
    onSave() {
        if (this.editMode) {
            this.flipToFront().then(() => {
                this.editMode = false;
            });
        }
    }
    flipToBack() {
        this.back.nativeElement.visibility = "visible";
        return this.getFlipToBackAnimation(500)
            .play()
            .then(() => {
            this.front.nativeElement.visibility = "collapse";
        });
    }
    flipToFront() {
        this.front.nativeElement.visibility = "visible";
        return this.getFlipToFrontAnimation(500)
            .play()
            .then(() => {
            this.back.nativeElement.visibility = "collapse";
        });
    }
    initializeCards() {
        if (this.back && this.back.nativeElement) {
            // rotate and hide back side
            this.back.nativeElement.rotateX = 180;
            this.back.nativeElement.opacity = 0;
            this.back.nativeElement.visibility = "collapse";
        }
    }
    getFlipToBackAnimation(animationDuration) {
        const animationDefinition = [
            {
                target: this.front.nativeElement,
                rotate: { x: -180, y: 0, z: 0 },
                duration: animationDuration,
                curve: _nativescript_core__WEBPACK_IMPORTED_MODULE_2__.CoreTypes.AnimationCurve.easeInOut,
            },
            {
                target: this.back.nativeElement,
                rotate: { x: 0, y: 0, z: 0 },
                duration: animationDuration,
                curve: _nativescript_core__WEBPACK_IMPORTED_MODULE_2__.CoreTypes.AnimationCurve.easeInOut,
            },
            {
                target: this.front.nativeElement,
                opacity: 0,
                delay: animationDuration / 2,
                duration: 1,
            },
            {
                target: this.back.nativeElement,
                opacity: 1,
                delay: animationDuration / 2,
                duration: 1,
            },
        ];
        return new _nativescript_core__WEBPACK_IMPORTED_MODULE_3__.Animation(animationDefinition, false);
    }
    getFlipToFrontAnimation(animationDuration) {
        const animationDefinition = [
            {
                target: this.front.nativeElement,
                rotate: { x: 0, y: 0, z: 0 },
                duration: animationDuration,
                curve: _nativescript_core__WEBPACK_IMPORTED_MODULE_2__.CoreTypes.AnimationCurve.easeInOut,
            },
            {
                target: this.back.nativeElement,
                rotate: { x: 180, y: 0, z: 0 },
                duration: animationDuration,
                curve: _nativescript_core__WEBPACK_IMPORTED_MODULE_2__.CoreTypes.AnimationCurve.easeInOut,
            },
            {
                target: this.front.nativeElement,
                opacity: 1,
                delay: animationDuration / 2,
                duration: 1,
            },
            {
                target: this.back.nativeElement,
                opacity: 0,
                delay: animationDuration / 2,
                duration: 1,
            },
        ];
        return new _nativescript_core__WEBPACK_IMPORTED_MODULE_3__.Animation(animationDefinition, false);
    }
}
ProfileComponent.ɵfac = function ProfileComponent_Factory(t) { return new (t || ProfileComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_nativescript_core__WEBPACK_IMPORTED_MODULE_5__.Page)); };
ProfileComponent.ɵcmp = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({ type: ProfileComponent, selectors: [["ns-profile"]], viewQuery: function ProfileComponent_Query(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c0, 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵviewQuery"](_c1, 5);
    } if (rf & 2) {
        let _t;
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.front = _t.first);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵqueryRefresh"](_t = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵloadQuery"]()) && (ctx.back = _t.first);
    } }, decls: 9, vars: 2, consts: [["rows", "auto, *"], ["row", "0", "src", "~/assets/images/profile/profile-cover.png", "width", "100%", "height", "250", "stretch", "aspectFill"], ["row", "1", "rows", "auto", "margin", "-150 30 0 30"], ["front", ""], [3, "profile", "edit"], [3, "loaded"], ["back", ""], [3, "profile", "save"]], template: function ProfileComponent_Template(rf, ctx) { if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "GridLayout", 0);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "Image", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "GridLayout", 2)(3, "GridLayout", null, 3)(5, "ns-profile-card-front", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("edit", function ProfileComponent_Template_ns_profile_card_front_edit_5_listener() { return ctx.onEdit(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "GridLayout", 5, 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("loaded", function ProfileComponent_Template_GridLayout_loaded_6_listener() { return ctx.backLoaded(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](8, "ns-profile-card-back", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("save", function ProfileComponent_Template_ns_profile_card_back_save_8_listener() { return ctx.onSave(); });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()();
    } if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("profile", ctx.profileData);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("profile", ctx.profileData);
    } }, dependencies: [_profile_card_front_profile_card_front_component__WEBPACK_IMPORTED_MODULE_0__.ProfileCardFrontComponent, _profile_card_back_profile_card_back_component__WEBPACK_IMPORTED_MODULE_1__.ProfileCardBackComponent], encapsulation: 2 });


/***/ }),

/***/ "./src/app/features/profile/profile.module.ts":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfileModule": () => (/* binding */ ProfileModule)
/* harmony export */ });
/* harmony import */ var _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./node_modules/@nativescript/angular/fesm2015/nativescript-angular.mjs");
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/app/features/profile/profile-routing.module.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./node_modules/@angular/core/fesm2015/core.mjs");



class ProfileModule {
}
ProfileModule.ɵfac = function ProfileModule_Factory(t) { return new (t || ProfileModule)(); };
ProfileModule.ɵmod = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineNgModule"]({ type: ProfileModule });
ProfileModule.ɵinj = /*@__PURE__*/ _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjector"]({ imports: [_nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptCommonModule,
        _nativescript_angular__WEBPACK_IMPORTED_MODULE_2__.NativeScriptFormsModule,
        _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfileRoutingModule] });


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX2FwcF9mZWF0dXJlc19wcm9maWxlX3Byb2ZpbGVfbW9kdWxlX3RzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQTZDO0FBQ2Q7QUFDSztBQUNFO0FBQ0Q7QUFDTztBQUM1QyxxRUFBcUU7QUFDckUsZ0JBQWdCLDhEQUFtQjtBQUNuQyxJQUFJLHFFQUEwQjtBQUM5QixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHdEQUFhLGdHQUFnRywyREFBZ0IsT0FBTyxlQUFlLDJEQUFnQixJQUFJLE9BQU8seURBQWMsb0JBQW9CO0FBQ3BOLElBQUksdURBQVk7QUFDaEIsSUFBSSwwREFBZTtBQUNuQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksNERBQWlCO0FBQ3JCLElBQUksd0RBQWEseUhBQXlILDJEQUFnQixPQUFPLGVBQWUsMkRBQWdCLElBQUksT0FBTyx5REFBYyx3Q0FBd0M7QUFDalEsSUFBSSwwREFBZTtBQUNuQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksNERBQWlCO0FBQ3JCLElBQUksd0RBQWEseUhBQXlILDJEQUFnQixPQUFPLGVBQWUsMkRBQWdCLElBQUksT0FBTyx5REFBYyxxQ0FBcUM7QUFDOVAsSUFBSSwwREFBZTtBQUNuQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksNERBQWlCO0FBQ3JCLElBQUksd0RBQWEseUhBQXlILDJEQUFnQixPQUFPLGVBQWUsMkRBQWdCLElBQUksT0FBTyx5REFBYyxnQ0FBZ0M7QUFDelAsSUFBSSwwREFBZTtBQUNuQixJQUFJLG1FQUF3QjtBQUM1QixFQUFFO0FBQ0YsbUJBQW1CLDJEQUFnQjtBQUNuQyxJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakIsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDTztBQUNQO0FBQ0Esd0JBQXdCLHVEQUFZO0FBQ3BDLHFCQUFxQix3Q0FBSztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0VBQStFO0FBQy9FLDhDQUE4QywrREFBb0IsR0FBRyxpRkFBaUYsb0JBQW9CLGFBQWEsY0FBYyw0eENBQTR4QztBQUNqK0MsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsMERBQWU7QUFDdkIsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDBEQUFlO0FBQ3ZCLE1BQU07QUFDTixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsUUFBUSx1REFBWTtBQUNwQixRQUFRLHdEQUFhO0FBQ3JCLE9BQU8saUJBQWlCLGlEQUFPLEVBQUUsMkRBQWtCLEVBQUUsbURBQVUsRUFBRSxvRUFBb0IscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7QUM3RDdEO0FBQ2Q7QUFDSztBQUNFO0FBQ3RDLHNGQUFzRjtBQUN0RixJQUFJLHFFQUEwQjtBQUM5QixJQUFJLHVEQUFZO0FBQ2hCLElBQUksbUVBQXdCO0FBQzVCLEVBQUU7QUFDRixtQkFBbUIsMkRBQWdCO0FBQ25DLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQjtBQUNBLDZHQUE2RztBQUM3RyxJQUFJLHVEQUFZO0FBQ2hCLEVBQUU7QUFDRixtQkFBbUIsMkRBQWdCO0FBQ25DLElBQUksd0RBQWE7QUFDakI7QUFDQSw2R0FBNkc7QUFDN0csSUFBSSx1REFBWTtBQUNoQixFQUFFO0FBQ0YsbUJBQW1CLDJEQUFnQjtBQUNuQyxJQUFJLHdEQUFhO0FBQ2pCO0FBQ0EsNkdBQTZHO0FBQzdHLElBQUksdURBQVk7QUFDaEIsRUFBRTtBQUNGLG1CQUFtQiwyREFBZ0I7QUFDbkMsSUFBSSx3REFBYTtBQUNqQjtBQUNBLHFHQUFxRztBQUNyRyxJQUFJLHFFQUEwQjtBQUM5QixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHFFQUEwQjtBQUM5QixJQUFJLHdEQUFhO0FBQ2pCLElBQUksd0RBQWE7QUFDakIsSUFBSSx3REFBYTtBQUNqQixJQUFJLG1FQUF3QjtBQUM1QixJQUFJLHVEQUFZO0FBQ2hCLElBQUksMERBQWU7QUFDbkIsSUFBSSxtRUFBd0I7QUFDNUIsRUFBRTtBQUNGO0FBQ0EsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakIsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQjtBQUNBLHNGQUFzRjtBQUN0RixJQUFJLHFFQUEwQjtBQUM5QixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakIsSUFBSSxtRUFBd0I7QUFDNUIsRUFBRTtBQUNGLG1CQUFtQiwyREFBZ0I7QUFDbkMsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCO0FBQ0Esc0VBQXNFO0FBQ3RFLGdCQUFnQiw4REFBbUI7QUFDbkMsSUFBSSxxRUFBMEI7QUFDOUIsSUFBSSw0REFBaUI7QUFDckIsSUFBSSx3REFBYSxpR0FBaUcsMkRBQWdCLE9BQU8sZUFBZSwyREFBZ0IsSUFBSSxPQUFPLHlEQUFjLG9CQUFvQjtBQUNyTixJQUFJLHVEQUFZO0FBQ2hCLElBQUksMERBQWU7QUFDbkIsSUFBSSx1REFBWTtBQUNoQixJQUFJLDREQUFpQjtBQUNyQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksMERBQWU7QUFDbkIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksbUVBQXdCO0FBQzVCLEVBQUU7QUFDRixtQkFBbUIsMkRBQWdCO0FBQ25DLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakIsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakIsSUFBSSx1REFBWTtBQUNoQixJQUFJLHdEQUFhO0FBQ2pCLElBQUksdURBQVk7QUFDaEIsSUFBSSx3REFBYTtBQUNqQixJQUFJLHVEQUFZO0FBQ2hCLElBQUksd0RBQWE7QUFDakI7QUFDTztBQUNQO0FBQ0Esd0JBQXdCLHVEQUFZO0FBQ3BDLHFCQUFxQix3Q0FBSztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUZBQWlGO0FBQ2pGLCtDQUErQywrREFBb0IsR0FBRyxtRkFBbUYsb0JBQW9CLGFBQWEsY0FBYyx3dUVBQXd1RTtBQUNoN0UsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhO0FBQ3JCLFFBQVEsMERBQWU7QUFDdkIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDBEQUFlO0FBQ3ZCLE1BQU07QUFDTixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsT0FBTyxpQkFBaUIsb0RBQVUsRUFBRSxpREFBTyxFQUFFLHFEQUFXLEVBQUUseURBQWUscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7O0FDdkhGO0FBQ3JDO0FBQ25CO0FBQ1E7QUFDckM7QUFDUDtBQUNBO0FBQ0EsbUJBQW1CLGdFQUFnQjtBQUNuQyxLQUFLO0FBQ0w7QUFDTztBQUNQO0FBQ0EsdUVBQXVFO0FBQ3ZFLDBDQUEwQyw4REFBbUIsR0FBRyw0QkFBNEI7QUFDNUYsMENBQTBDLDhEQUFtQixHQUFHLFVBQVUsMkVBQXdCO0FBQ2xHLFFBQVEsb0ZBQWlDLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZUO0FBQ3NCO0FBQzdCO0FBQ0s7QUFDK0I7QUFDRjtBQUN0RTtBQUNBO0FBQ087QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIscUJBQXFCO0FBQy9DO0FBQ0EsdUJBQXVCLGtGQUFrQztBQUN6RCxhQUFhO0FBQ2I7QUFDQTtBQUNBLDBCQUEwQixrQkFBa0I7QUFDNUM7QUFDQSx1QkFBdUIsa0ZBQWtDO0FBQ3pELGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxtQkFBbUIseURBQVM7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixrQkFBa0I7QUFDNUM7QUFDQSx1QkFBdUIsa0ZBQWtDO0FBQ3pELGFBQWE7QUFDYjtBQUNBO0FBQ0EsMEJBQTBCLG9CQUFvQjtBQUM5QztBQUNBLHVCQUF1QixrRkFBa0M7QUFDekQsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLG1CQUFtQix5REFBUztBQUM1QjtBQUNBO0FBQ0EsK0RBQStELG1DQUFtQywrREFBb0IsQ0FBQyxvREFBTztBQUM5SCxzQ0FBc0MsK0RBQW9CLEdBQUcsMkdBQTJHO0FBQ3hLLFFBQVEseURBQWM7QUFDdEIsUUFBUSx5REFBYztBQUN0QixNQUFNO0FBQ047QUFDQSxRQUFRLDREQUFpQixNQUFNLHlEQUFjO0FBQzdDLFFBQVEsNERBQWlCLE1BQU0seURBQWM7QUFDN0MsT0FBTyw2WEFBNlg7QUFDcFksUUFBUSw0REFBaUI7QUFDekIsUUFBUSx1REFBWTtBQUNwQixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhLHNGQUFzRixzQkFBc0I7QUFDakksUUFBUSwwREFBZTtBQUN2QixRQUFRLDREQUFpQjtBQUN6QixRQUFRLHdEQUFhLCtFQUErRSwwQkFBMEI7QUFDOUgsUUFBUSw0REFBaUI7QUFDekIsUUFBUSx3REFBYSxxRkFBcUYsc0JBQXNCO0FBQ2hJLFFBQVEsMERBQWU7QUFDdkIsTUFBTTtBQUNOLFFBQVEsdURBQVk7QUFDcEIsUUFBUSx3REFBYTtBQUNyQixRQUFRLHVEQUFZO0FBQ3BCLFFBQVEsd0RBQWE7QUFDckIsT0FBTyxpQkFBaUIsdUdBQTRCLEVBQUUsb0dBQTJCLHFCQUFxQjs7Ozs7Ozs7Ozs7Ozs7O0FDcEtYO0FBQzNCO0FBQzVCO0FBQzdCO0FBQ1A7QUFDQSx5REFBeUQ7QUFDekQsbUNBQW1DLDhEQUFtQixHQUFHLHFCQUFxQjtBQUM5RSxtQ0FBbUMsOERBQW1CLEdBQUcsVUFBVSwyRUFBd0I7QUFDM0YsUUFBUSwwRUFBdUI7QUFDL0IsUUFBUSx5RUFBb0IsR0FBRyIsInNvdXJjZXMiOlsid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL3Byb2ZpbGUvcHJvZmlsZS1jYXJkLWJhY2svcHJvZmlsZS1jYXJkLWJhY2suY29tcG9uZW50LnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL3Byb2ZpbGUvcHJvZmlsZS1jYXJkLWZyb250L3Byb2ZpbGUtY2FyZC1mcm9udC5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvZmVhdHVyZXMvcHJvZmlsZS9wcm9maWxlLXJvdXRpbmcubW9kdWxlLnRzIiwid2VicGFjazovL0BuYXRpdmVzY3JpcHQvdGVtcGxhdGUtaGVsbG8td29ybGQtbmcvLi9zcmMvYXBwL2ZlYXR1cmVzL3Byb2ZpbGUvcHJvZmlsZS5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vQG5hdGl2ZXNjcmlwdC90ZW1wbGF0ZS1oZWxsby13b3JsZC1uZy8uL3NyYy9hcHAvZmVhdHVyZXMvcHJvZmlsZS9wcm9maWxlLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgSWNvbnMgfSBmcm9tIFwifi9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0ICogYXMgaTEgZnJvbSBcIkBhbmd1bGFyL2NvbW1vblwiO1xuaW1wb3J0ICogYXMgaTIgZnJvbSBcIkBhbmd1bGFyL2Zvcm1zXCI7XG5pbXBvcnQgKiBhcyBpMyBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5mdW5jdGlvbiBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnRfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgY29uc3QgX3IyID0gaTAuybXJtWdldEN1cnJlbnRWaWV3KCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgwKTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDEsIFwiR3JpZExheW91dFwiLCA3KTtcbiAgICBpMC7Jtcm1bGlzdGVuZXIoXCJ0YXBcIiwgZnVuY3Rpb24gUHJvZmlsZUNhcmRCYWNrQ29tcG9uZW50X25nX2NvbnRhaW5lcl8zX1RlbXBsYXRlX0dyaWRMYXlvdXRfdGFwXzFfbGlzdGVuZXIoKSB7IGkwLsm1ybVyZXN0b3JlVmlldyhfcjIpOyBjb25zdCBjdHhfcjEgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTsgcmV0dXJuIGkwLsm1ybVyZXNldFZpZXcoY3R4X3IxLm9uU2F2ZSgpKTsgfSk7XG4gICAgaTAuybXJtWVsZW1lbnQoMiwgXCJMYWJlbFwiLCA4KTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50KDMsIFwiTGFiZWxcIiwgOSk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCg0LCBcIlRleHRGaWVsZFwiLCAxMCk7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwibmdNb2RlbENoYW5nZVwiLCBmdW5jdGlvbiBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnRfbmdfY29udGFpbmVyXzNfVGVtcGxhdGVfVGV4dEZpZWxkX25nTW9kZWxDaGFuZ2VfNF9saXN0ZW5lcigkZXZlbnQpIHsgaTAuybXJtXJlc3RvcmVWaWV3KF9yMik7IGNvbnN0IGN0eF9yMyA9IGkwLsm1ybVuZXh0Q29udGV4dCgpOyByZXR1cm4gaTAuybXJtXJlc2V0VmlldyhjdHhfcjMucHJvZmlsZS5kaXNwbGF5TmFtZSA9ICRldmVudCk7IH0pO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnQoNSwgXCJMYWJlbFwiLCAxMSk7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCg2LCBcIlRleHRGaWVsZFwiLCAxMCk7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwibmdNb2RlbENoYW5nZVwiLCBmdW5jdGlvbiBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnRfbmdfY29udGFpbmVyXzNfVGVtcGxhdGVfVGV4dEZpZWxkX25nTW9kZWxDaGFuZ2VfNl9saXN0ZW5lcigkZXZlbnQpIHsgaTAuybXJtXJlc3RvcmVWaWV3KF9yMik7IGNvbnN0IGN0eF9yNCA9IGkwLsm1ybVuZXh0Q29udGV4dCgpOyByZXR1cm4gaTAuybXJtXJlc2V0VmlldyhjdHhfcjQucHJvZmlsZS51c2VybmFtZSA9ICRldmVudCk7IH0pO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtWVsZW1lbnQoNywgXCJMYWJlbFwiLCAxMik7XG4gICAgaTAuybXJtWVsZW1lbnRTdGFydCg4LCBcIlRleHRGaWVsZFwiLCAxMCk7XG4gICAgaTAuybXJtWxpc3RlbmVyKFwibmdNb2RlbENoYW5nZVwiLCBmdW5jdGlvbiBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnRfbmdfY29udGFpbmVyXzNfVGVtcGxhdGVfVGV4dEZpZWxkX25nTW9kZWxDaGFuZ2VfOF9saXN0ZW5lcigkZXZlbnQpIHsgaTAuybXJtXJlc3RvcmVWaWV3KF9yMik7IGNvbnN0IGN0eF9yNSA9IGkwLsm1ybVuZXh0Q29udGV4dCgpOyByZXR1cm4gaTAuybXJtXJlc2V0VmlldyhjdHhfcjUucHJvZmlsZS5iaW8gPSAkZXZlbnQpOyB9KTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBjdHhfcjAgPSBpMC7Jtcm1bmV4dENvbnRleHQoKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGN0eF9yMC5pY29ucy5zYXZlKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ01vZGVsXCIsIGN0eF9yMC5wcm9maWxlLmRpc3BsYXlOYW1lKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ01vZGVsXCIsIGN0eF9yMC5wcm9maWxlLnVzZXJuYW1lKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgyKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ01vZGVsXCIsIGN0eF9yMC5wcm9maWxlLmJpbyk7XG59IH1cbmV4cG9ydCBjbGFzcyBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLnNhdmUgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgICAgIHRoaXMuaWNvbnMgPSBJY29ucztcbiAgICB9XG4gICAgb25TYXZlKCkge1xuICAgICAgICB0aGlzLnNhdmUuZW1pdCh0aGlzLnByb2ZpbGUpO1xuICAgIH1cbn1cblByb2ZpbGVDYXJkQmFja0NvbXBvbmVudC7JtWZhYyA9IGZ1bmN0aW9uIFByb2ZpbGVDYXJkQmFja0NvbXBvbmVudF9GYWN0b3J5KHQpIHsgcmV0dXJuIG5ldyAodCB8fCBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnQpKCk7IH07XG5Qcm9maWxlQ2FyZEJhY2tDb21wb25lbnQuybVjbXAgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVDb21wb25lbnQoeyB0eXBlOiBQcm9maWxlQ2FyZEJhY2tDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLXByb2ZpbGUtY2FyZC1iYWNrXCJdXSwgaW5wdXRzOiB7IHByb2ZpbGU6IFwicHJvZmlsZVwiIH0sIG91dHB1dHM6IHsgc2F2ZTogXCJzYXZlXCIgfSwgZGVjbHM6IDcsIHZhcnM6IDIsIGNvbnN0czogW1tcImhlaWdodFwiLCBcIjY1MFwiLCBcInJvd3NcIiwgXCJhdXRvLCAqXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwiYm94U2hhZG93XCIsIFwiMCAwIDUgMCByZ2JhKDAsMCwwLDAuNSlcIl0sIFtcInJvd1wiLCBcIjFcIiwgXCJtYXJnaW5Ub3BcIiwgXCItNzVcIiwgXCJiYWNrZ3JvdW5kQ29sb3JcIiwgXCJ3aGl0ZVwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjEwXCIsIFwicGFkZGluZ1wiLCBcIjI1IDMwXCJdLCBbNCwgXCJuZ0lmXCJdLCBbXCJoZWlnaHRcIiwgXCIxNTBcIiwgXCJ3aWR0aFwiLCBcIjE1MFwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjc1XCIsIFwiYmFja2dyb3VuZENvbG9yXCIsIFwiIzAwMFwiLCBcImJvcmRlcldpZHRoXCIsIFwiNVwiLCBcImJvcmRlckNvbG9yXCIsIFwid2hpdGVcIl0sIFtcImhlaWdodFwiLCBcIjE1MFwiLCBcIndpZHRoXCIsIFwiMTUwXCIsIFwiYm9yZGVyUmFkaXVzXCIsIFwiNzVcIiwgXCJvcGFjaXR5XCIsIFwiMC41XCIsIFwic3JjXCIsIFwifi9hc3NldHMvaW1hZ2VzL3Byb2ZpbGUvcHJvZmlsZS1waWMucG5nXCIsIFwic3RyZXRjaFwiLCBcImFzcGVjdEZpbGxcIl0sIFtcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwiaG9yaXpvbnRhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCBcImNvbG9yXCIsIFwid2hpdGVcIiwgXCJmb250U2l6ZVwiLCBcIjUwXCIsIDEsIFwiaW9uaWNvbnNcIiwgMywgXCJ0ZXh0XCJdLCBbXCJoZWlnaHRcIiwgXCI0MFwiLCBcIndpZHRoXCIsIFwiNDBcIiwgXCJyb3dzXCIsIFwiKlwiLCBcImNvbHVtbnNcIiwgXCIqXCIsIFwiaG9yaXpvbnRhbEFsaWdubWVudFwiLCBcInJpZ2h0XCIsIDMsIFwidGFwXCJdLCBbXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwicmlnaHRcIiwgXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcInRvcFwiLCAxLCBcImlvbmljb25zXCIsIFwiZm9udC1zaXplLWgxXCIsIFwidGV4dC1jb2xvci1wcmltYXJ5XCIsIDMsIFwidGV4dFwiXSwgW1widGV4dFwiLCBcIkRpc3BsYXkgTmFtZVwiLCBcImNvbG9yXCIsIFwiI2FhYVwiLCBcImZvbnRTaXplXCIsIFwiMTdcIiwgXCJtYXJnaW5Ub3BcIiwgXCI0MFwiXSwgW1wiZm9udFNpemVcIiwgXCIyNVwiLCBcImNvbG9yXCIsIFwiIzc3N1wiLCBcIm1hcmdpblRvcFwiLCBcIjVcIiwgXCJib3JkZXJCb3R0b21XaWR0aFwiLCBcIjJcIiwgXCJib3JkZXJCb3R0b21Db2xvclwiLCBcIiNhYWFcIiwgMywgXCJuZ01vZGVsXCIsIFwibmdNb2RlbENoYW5nZVwiXSwgW1widGV4dFwiLCBcIlVzZXJuYW1lXCIsIFwiY29sb3JcIiwgXCIjYWFhXCIsIFwiZm9udFNpemVcIiwgXCIxN1wiLCBcIm1hcmdpblRvcFwiLCBcIjQwXCJdLCBbXCJ0ZXh0XCIsIFwiQmlvXCIsIFwiY29sb3JcIiwgXCIjYWFhXCIsIFwiZm9udFNpemVcIiwgXCIxN1wiLCBcIm1hcmdpblRvcFwiLCBcIjQwXCJdXSwgdGVtcGxhdGU6IGZ1bmN0aW9uIFByb2ZpbGVDYXJkQmFja0NvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiQ29udGVudFZpZXdcIiwgMSk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMiwgXCJTdGFja0xheW91dFwiLCAyKTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDMsIFByb2ZpbGVDYXJkQmFja0NvbXBvbmVudF9uZ19jb250YWluZXJfM19UZW1wbGF0ZSwgOSwgNCwgXCJuZy1jb250YWluZXJcIiwgMyk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoNCwgXCJHcmlkTGF5b3V0XCIsIDQpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCg1LCBcIkltYWdlXCIsIDUpKDYsIFwiTGFiZWxcIiwgNik7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50RW5kKCkoKTtcbiAgICB9IGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMyk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgY3R4LnByb2ZpbGUpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHguaWNvbnMuZWRpdCk7XG4gICAgfSB9LCBkZXBlbmRlbmNpZXM6IFtpMS5OZ0lmLCBpMi5OZ0NvbnRyb2xTdGF0dXMsIGkyLk5nTW9kZWwsIGkzLlRleHRWYWx1ZUFjY2Vzc29yXSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCB7IEV2ZW50RW1pdHRlciB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBJY29ucyB9IGZyb20gXCJ+L2NvcmVcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uXCI7XG5mdW5jdGlvbiBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xMl9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiTGFiZWxcIiwgMTYpKDIsIFwiTGFiZWxcIiwgMTcpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBjdHhfcjEgPSBpMC7Jtcm1bmV4dENvbnRleHQoMik7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHhfcjEucHJvZmlsZS5iaW8pO1xufSB9XG5mdW5jdGlvbiBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xM19uZ19jb250YWluZXJfMl9MYWJlbF8zX1RlbXBsYXRlKHJmLCBjdHgpIHsgaWYgKHJmICYgMSkge1xuICAgIGkwLsm1ybVlbGVtZW50KDAsIFwiTGFiZWxcIiwgMjQpO1xufSBpZiAocmYgJiAyKSB7XG4gICAgY29uc3QgY3R4X3I1ID0gaTAuybXJtW5leHRDb250ZXh0KDQpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3I1Lmljb25zLmZpbG1PdXRsaW5lKTtcbn0gfVxuZnVuY3Rpb24gUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudF9uZ19jb250YWluZXJfM19uZ19jb250YWluZXJfMTNfbmdfY29udGFpbmVyXzJfTGFiZWxfNF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudCgwLCBcIkxhYmVsXCIsIDI0KTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yNiA9IGkwLsm1ybVuZXh0Q29udGV4dCg0KTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGN0eF9yNi5pY29ucy5jb21tZW50KTtcbn0gfVxuZnVuY3Rpb24gUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudF9uZ19jb250YWluZXJfM19uZ19jb250YWluZXJfMTNfbmdfY29udGFpbmVyXzJfTGFiZWxfNV9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudCgwLCBcIkxhYmVsXCIsIDI0KTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yNyA9IGkwLsm1ybVuZXh0Q29udGV4dCg0KTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGN0eF9yNy5pY29ucy5oZWFydE91dGxpbmUpO1xufSB9XG5mdW5jdGlvbiBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xM19uZ19jb250YWluZXJfMl9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMSwgXCJTdGFja0xheW91dFwiLCAyMCk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJTdGFydCgyLCAyMSk7XG4gICAgaTAuybXJtXRlbXBsYXRlKDMsIFByb2ZpbGVDYXJkRnJvbnRDb21wb25lbnRfbmdfY29udGFpbmVyXzNfbmdfY29udGFpbmVyXzEzX25nX2NvbnRhaW5lcl8yX0xhYmVsXzNfVGVtcGxhdGUsIDEsIDEsIFwiTGFiZWxcIiwgMjIpO1xuICAgIGkwLsm1ybV0ZW1wbGF0ZSg0LCBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xM19uZ19jb250YWluZXJfMl9MYWJlbF80X1RlbXBsYXRlLCAxLCAxLCBcIkxhYmVsXCIsIDIyKTtcbiAgICBpMC7Jtcm1dGVtcGxhdGUoNSwgUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudF9uZ19jb250YWluZXJfM19uZ19jb250YWluZXJfMTNfbmdfY29udGFpbmVyXzJfTGFiZWxfNV9UZW1wbGF0ZSwgMSwgMSwgXCJMYWJlbFwiLCAyMik7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudCg2LCBcIkxhYmVsXCIsIDIzKTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBhY3Rpdml0eV9yNCA9IGN0eC4kaW1wbGljaXQ7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwibmdTd2l0Y2hcIiwgYWN0aXZpdHlfcjQudHlwZSk7XG4gICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgaTAuybXJtXByb3BlcnR5KFwibmdTd2l0Y2hDYXNlXCIsIFwid2F0Y2hlZFwiKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ1N3aXRjaENhc2VcIiwgXCJyZXZpZXdlZFwiKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJuZ1N3aXRjaENhc2VcIiwgXCJsaWtlZFwiKTtcbiAgICBpMC7Jtcm1YWR2YW5jZSgxKTtcbiAgICBpMC7Jtcm1cHJvcGVydHkoXCJ0ZXh0XCIsIGFjdGl2aXR5X3I0Lm1lc3NhZ2UpO1xufSB9XG5mdW5jdGlvbiBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xM19UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiTGFiZWxcIiwgMTgpO1xuICAgIGkwLsm1ybV0ZW1wbGF0ZSgyLCBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xM19uZ19jb250YWluZXJfMl9UZW1wbGF0ZSwgNywgNSwgXCJuZy1jb250YWluZXJcIiwgMTkpO1xuICAgIGkwLsm1ybVlbGVtZW50Q29udGFpbmVyRW5kKCk7XG59IGlmIChyZiAmIDIpIHtcbiAgICBjb25zdCBjdHhfcjIgPSBpMC7Jtcm1bmV4dENvbnRleHQoMik7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwibmdGb3JPZlwiLCBjdHhfcjIucHJvZmlsZS5yZWNlbnRBY3Rpdml0aWVzKTtcbn0gfVxuZnVuY3Rpb24gUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudF9uZ19jb250YWluZXJfM19UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICBjb25zdCBfcjkgPSBpMC7Jtcm1Z2V0Q3VycmVudFZpZXcoKTtcbiAgICBpMC7Jtcm1ZWxlbWVudENvbnRhaW5lclN0YXJ0KDApO1xuICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMSwgXCJHcmlkTGF5b3V0XCIsIDUpO1xuICAgIGkwLsm1ybVsaXN0ZW5lcihcInRhcFwiLCBmdW5jdGlvbiBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX1RlbXBsYXRlX0dyaWRMYXlvdXRfdGFwXzFfbGlzdGVuZXIoKSB7IGkwLsm1ybVyZXN0b3JlVmlldyhfcjkpOyBjb25zdCBjdHhfcjggPSBpMC7Jtcm1bmV4dENvbnRleHQoKTsgcmV0dXJuIGkwLsm1ybVyZXNldFZpZXcoY3R4X3I4Lm9uRWRpdCgpKTsgfSk7XG4gICAgaTAuybXJtWVsZW1lbnQoMiwgXCJMYWJlbFwiLCA2KTtcbiAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpO1xuICAgIGkwLsm1ybVlbGVtZW50KDMsIFwiTGFiZWxcIiwgNykoNCwgXCJMYWJlbFwiLCA4KTtcbiAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDUsIFwiR3JpZExheW91dFwiLCA5KTtcbiAgICBpMC7Jtcm1ZWxlbWVudCg2LCBcIkxhYmVsXCIsIDEwKSg3LCBcIkxhYmVsXCIsIDExKSg4LCBcIkxhYmVsXCIsIDEyKSg5LCBcIkxhYmVsXCIsIDEzKSgxMCwgXCJMYWJlbFwiLCAxNCkoMTEsIFwiTGFiZWxcIiwgMTUpO1xuICAgIGkwLsm1ybVlbGVtZW50RW5kKCk7XG4gICAgaTAuybXJtXRlbXBsYXRlKDEyLCBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xMl9UZW1wbGF0ZSwgMywgMSwgXCJuZy1jb250YWluZXJcIiwgMyk7XG4gICAgaTAuybXJtXRlbXBsYXRlKDEzLCBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X25nX2NvbnRhaW5lcl8zX25nX2NvbnRhaW5lcl8xM19UZW1wbGF0ZSwgMywgMSwgXCJuZy1jb250YWluZXJcIiwgMyk7XG4gICAgaTAuybXJtWVsZW1lbnRDb250YWluZXJFbmQoKTtcbn0gaWYgKHJmICYgMikge1xuICAgIGNvbnN0IGN0eF9yMCA9IGkwLsm1ybVuZXh0Q29udGV4dCgpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDIpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IwLmljb25zLmVkaXQpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IwLnByb2ZpbGUuZGlzcGxheU5hbWUpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IwLnByb2ZpbGUudXNlcm5hbWUpO1xuICAgIGkwLsm1ybVhZHZhbmNlKDMpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcInRleHRcIiwgY3R4X3IwLnByb2ZpbGUgPT0gbnVsbCA/IG51bGwgOiBjdHhfcjAucHJvZmlsZS5wb3N0cyk7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHhfcjAucHJvZmlsZSA9PSBudWxsID8gbnVsbCA6IGN0eF9yMC5wcm9maWxlLmZvbGxvd2Vycyk7XG4gICAgaTAuybXJtWFkdmFuY2UoMik7XG4gICAgaTAuybXJtXByb3BlcnR5KFwidGV4dFwiLCBjdHhfcjAucHJvZmlsZSA9PSBudWxsID8gbnVsbCA6IGN0eF9yMC5wcm9maWxlLmZvbGxvd2luZyk7XG4gICAgaTAuybXJtWFkdmFuY2UoMSk7XG4gICAgaTAuybXJtXByb3BlcnR5KFwibmdJZlwiLCBjdHhfcjAucHJvZmlsZS5iaW8pO1xuICAgIGkwLsm1ybVhZHZhbmNlKDEpO1xuICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgKGN0eF9yMC5wcm9maWxlLnJlY2VudEFjdGl2aXRpZXMgPT0gbnVsbCA/IG51bGwgOiBjdHhfcjAucHJvZmlsZS5yZWNlbnRBY3Rpdml0aWVzLmxlbmd0aCkgPiAwKTtcbn0gfVxuZXhwb3J0IGNsYXNzIFByb2ZpbGVDYXJkRnJvbnRDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICB0aGlzLmVkaXQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgICAgIHRoaXMuaWNvbnMgPSBJY29ucztcbiAgICB9XG4gICAgb25FZGl0KCkge1xuICAgICAgICB0aGlzLmVkaXQuZW1pdCgpO1xuICAgIH1cbn1cblByb2ZpbGVDYXJkRnJvbnRDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBQcm9maWxlQ2FyZEZyb250Q29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IFByb2ZpbGVDYXJkRnJvbnRDb21wb25lbnQpKCk7IH07XG5Qcm9maWxlQ2FyZEZyb250Q29tcG9uZW50Lsm1Y21wID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lQ29tcG9uZW50KHsgdHlwZTogUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudCwgc2VsZWN0b3JzOiBbW1wibnMtcHJvZmlsZS1jYXJkLWZyb250XCJdXSwgaW5wdXRzOiB7IHByb2ZpbGU6IFwicHJvZmlsZVwiIH0sIG91dHB1dHM6IHsgZWRpdDogXCJlZGl0XCIgfSwgZGVjbHM6IDUsIHZhcnM6IDEsIGNvbnN0czogW1tcImhlaWdodFwiLCBcIjY1MFwiLCBcInJvd3NcIiwgXCJhdXRvLCAqXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwiYm94U2hhZG93XCIsIFwiMCAwIDUgMCByZ2JhKDAsMCwwLDAuNSlcIl0sIFtcInJvd1wiLCBcIjFcIiwgXCJtYXJnaW5Ub3BcIiwgXCItNzVcIiwgXCJiYWNrZ3JvdW5kQ29sb3JcIiwgXCJ3aGl0ZVwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjEwXCIsIFwicGFkZGluZ1wiLCBcIjI1XCJdLCBbNCwgXCJuZ0lmXCJdLCBbXCJoZWlnaHRcIiwgXCIxNTBcIiwgXCJ3aWR0aFwiLCBcIjE1MFwiLCBcImJvcmRlclJhZGl1c1wiLCBcIjc1XCIsIFwiYm9yZGVyV2lkdGhcIiwgXCI1XCIsIFwiYm9yZGVyQ29sb3JcIiwgXCJ3aGl0ZVwiLCBcInNyY1wiLCBcIn4vYXNzZXRzL2ltYWdlcy9wcm9maWxlL3Byb2ZpbGUtcGljLnBuZ1wiLCBcInN0cmV0Y2hcIiwgXCJhc3BlY3RGaWxsXCJdLCBbXCJoZWlnaHRcIiwgXCI0MFwiLCBcIndpZHRoXCIsIFwiNDBcIiwgXCJyb3dzXCIsIFwiKlwiLCBcImNvbHVtbnNcIiwgXCIqXCIsIFwiaG9yaXpvbnRhbEFsaWdubWVudFwiLCBcInJpZ2h0XCIsIDMsIFwidGFwXCJdLCBbXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwicmlnaHRcIiwgXCJ2ZXJ0aWNhbEFsaWdubWVudFwiLCBcInRvcFwiLCAxLCBcImlvbmljb25zXCIsIFwiZm9udC1zaXplLWgxXCIsIFwidGV4dC1jb2xvci1wcmltYXJ5XCIsIDMsIFwidGV4dFwiXSwgW1wiY29sb3JcIiwgXCIjNzc3XCIsIFwibWFyZ2luVG9wXCIsIFwiNDBcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwiZm9udFNpemVcIiwgXCIzNVwiLCAzLCBcInRleHRcIl0sIFtcImZvbnRTaXplXCIsIFwiMjBcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwiY29sb3JcIiwgXCIjYWFhXCIsIDMsIFwidGV4dFwiXSwgW1wicm93c1wiLCBcImF1dG8sIGF1dG9cIiwgXCJjb2x1bW5zXCIsIFwiKiwgKiwgKlwiLCBcIm1hcmdpblRvcFwiLCBcIjIwXCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiMFwiLCBcImNvbG9yXCIsIFwiI2FhYVwiLCBcImZvbnRTaXplXCIsIFwiMThcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwidGV4dFwiLCBcIlBvc3RzXCJdLCBbXCJyb3dcIiwgXCIxXCIsIFwiY29sXCIsIFwiMFwiLCBcImNvbG9yXCIsIFwiIzg4OFwiLCBcImZvbnRTaXplXCIsIFwiMzBcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIDMsIFwidGV4dFwiXSwgW1wicm93XCIsIFwiMFwiLCBcImNvbFwiLCBcIjFcIiwgXCJjb2xvclwiLCBcIiNhYWFcIiwgXCJmb250U2l6ZVwiLCBcIjE4XCIsIFwiaG9yaXpvbnRhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCBcInRleHRcIiwgXCJGb2xsb3dlcnNcIl0sIFtcInJvd1wiLCBcIjFcIiwgXCJjb2xcIiwgXCIxXCIsIFwiY29sb3JcIiwgXCIjODg4XCIsIFwiZm9udFNpemVcIiwgXCIzMFwiLCBcImhvcml6b250YWxBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgMywgXCJ0ZXh0XCJdLCBbXCJyb3dcIiwgXCIwXCIsIFwiY29sXCIsIFwiMlwiLCBcImNvbG9yXCIsIFwiI2FhYVwiLCBcImZvbnRTaXplXCIsIFwiMThcIiwgXCJob3Jpem9udGFsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwidGV4dFwiLCBcIkZvbGxvd2luZ1wiXSwgW1wicm93XCIsIFwiMVwiLCBcImNvbFwiLCBcIjJcIiwgXCJjb2xvclwiLCBcIiM4ODhcIiwgXCJmb250U2l6ZVwiLCBcIjMwXCIsIFwiaG9yaXpvbnRhbEFsaWdubWVudFwiLCBcImNlbnRlclwiLCAzLCBcInRleHRcIl0sIFtcIm1hcmdpblRvcFwiLCBcIjIwXCIsIFwibWFyZ2luQm90dG9tXCIsIFwiNVwiLCBcInRleHRcIiwgXCJCaW9cIiwgXCJmb250U2l6ZVwiLCBcIjE1XCIsIFwiY29sb3JcIiwgXCIjYWFhXCJdLCBbXCJmb250U2l6ZVwiLCBcIjIzXCIsIFwiY29sb3JcIiwgXCIjNzc3XCIsIDMsIFwidGV4dFwiXSwgW1wibWFyZ2luVG9wXCIsIFwiMjBcIiwgXCJtYXJnaW5Cb3R0b21cIiwgXCIxMFwiLCBcInRleHRcIiwgXCJSZWNlbnQgQWN0aXZpdGllc1wiLCBcImZvbnRTaXplXCIsIFwiMTVcIiwgXCJjb2xvclwiLCBcIiNhYWFcIl0sIFs0LCBcIm5nRm9yXCIsIFwibmdGb3JPZlwiXSwgW1wib3JpZW50YXRpb25cIiwgXCJob3Jpem9udGFsXCIsIFwibWFyZ2luVG9wXCIsIFwiNVwiXSwgWzMsIFwibmdTd2l0Y2hcIl0sIFtcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwiY2xhc3NcIiwgXCJpb25pY29ucyBmb250LXNpemUtaDEgdGV4dC1jb2xvci1wcmltYXJ5XCIsIDMsIFwidGV4dFwiLCA0LCBcIm5nU3dpdGNoQ2FzZVwiXSwgW1wiY29sb3JcIiwgXCIjNzc3XCIsIFwiZm9udFNpemVcIiwgXCIxOFwiLCBcIm1hcmdpbkxlZnRcIiwgXCIxMFwiLCBcInZlcnRpY2FsQWxpZ25tZW50XCIsIFwiY2VudGVyXCIsIFwidGV4dFdyYXBcIiwgXCJ0cnVlXCIsIDMsIFwidGV4dFwiXSwgW1widmVydGljYWxBbGlnbm1lbnRcIiwgXCJjZW50ZXJcIiwgMSwgXCJpb25pY29uc1wiLCBcImZvbnQtc2l6ZS1oMVwiLCBcInRleHQtY29sb3ItcHJpbWFyeVwiLCAzLCBcInRleHRcIl1dLCB0ZW1wbGF0ZTogZnVuY3Rpb24gUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudF9UZW1wbGF0ZShyZiwgY3R4KSB7IGlmIChyZiAmIDEpIHtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRTdGFydCgwLCBcIkdyaWRMYXlvdXRcIiwgMCk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50KDEsIFwiQ29udGVudFZpZXdcIiwgMSk7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMiwgXCJTdGFja0xheW91dFwiLCAyKTtcbiAgICAgICAgaTAuybXJtXRlbXBsYXRlKDMsIFByb2ZpbGVDYXJkRnJvbnRDb21wb25lbnRfbmdfY29udGFpbmVyXzNfVGVtcGxhdGUsIDE0LCA4LCBcIm5nLWNvbnRhaW5lclwiLCAzKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnQoNCwgXCJJbWFnZVwiLCA0KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKTtcbiAgICB9IGlmIChyZiAmIDIpIHtcbiAgICAgICAgaTAuybXJtWFkdmFuY2UoMyk7XG4gICAgICAgIGkwLsm1ybVwcm9wZXJ0eShcIm5nSWZcIiwgY3R4LnByb2ZpbGUpO1xuICAgIH0gfSwgZGVwZW5kZW5jaWVzOiBbaTEuTmdGb3JPZiwgaTEuTmdJZiwgaTEuTmdTd2l0Y2gsIGkxLk5nU3dpdGNoQ2FzZV0sIGVuY2Fwc3VsYXRpb246IDIgfSk7XG4iLCJpbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsIE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZSwgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5pbXBvcnQgeyBQcm9maWxlQ29tcG9uZW50IH0gZnJvbSBcIi4vcHJvZmlsZS5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGkwIGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9hbmd1bGFyXCI7XG5leHBvcnQgY29uc3Qgcm91dGVzID0gW1xuICAgIHtcbiAgICAgICAgcGF0aDogXCJcIixcbiAgICAgICAgY29tcG9uZW50OiBQcm9maWxlQ29tcG9uZW50LFxuICAgIH0sXG5dO1xuZXhwb3J0IGNsYXNzIFByb2ZpbGVSb3V0aW5nTW9kdWxlIHtcbn1cblByb2ZpbGVSb3V0aW5nTW9kdWxlLsm1ZmFjID0gZnVuY3Rpb24gUHJvZmlsZVJvdXRpbmdNb2R1bGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgUHJvZmlsZVJvdXRpbmdNb2R1bGUpKCk7IH07XG5Qcm9maWxlUm91dGluZ01vZHVsZS7JtW1vZCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZU5nTW9kdWxlKHsgdHlwZTogUHJvZmlsZVJvdXRpbmdNb2R1bGUgfSk7XG5Qcm9maWxlUm91dGluZ01vZHVsZS7JtWluaiA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUluamVjdG9yKHsgaW1wb3J0czogW05hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcbiAgICAgICAgTmF0aXZlU2NyaXB0Um91dGVyTW9kdWxlLmZvckNoaWxkKHJvdXRlcyldIH0pO1xuIiwiaW1wb3J0IHsgRWxlbWVudFJlZiB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBBbmltYXRpb24sIENvcmVUeXBlcywgUGFnZSwgfSBmcm9tIFwiQG5hdGl2ZXNjcmlwdC9jb3JlXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0ICogYXMgaTEgZnJvbSBcIkBuYXRpdmVzY3JpcHQvY29yZVwiO1xuaW1wb3J0ICogYXMgaTIgZnJvbSBcIi4vcHJvZmlsZS1jYXJkLWZyb250L3Byb2ZpbGUtY2FyZC1mcm9udC5jb21wb25lbnRcIjtcbmltcG9ydCAqIGFzIGkzIGZyb20gXCIuL3Byb2ZpbGUtY2FyZC1iYWNrL3Byb2ZpbGUtY2FyZC1iYWNrLmNvbXBvbmVudFwiO1xuY29uc3QgX2MwID0gW1wiZnJvbnRcIl07XG5jb25zdCBfYzEgPSBbXCJiYWNrXCJdO1xuZXhwb3J0IGNsYXNzIFByb2ZpbGVDb21wb25lbnQge1xuICAgIGNvbnN0cnVjdG9yKHBhZ2UpIHtcbiAgICAgICAgdGhpcy5wYWdlID0gcGFnZTtcbiAgICAgICAgdGhpcy5wcm9maWxlRGF0YSA9IHtcbiAgICAgICAgICAgIGRpc3BsYXlOYW1lOiBcIkx1Y2EgR2lyYWZmZVwiLFxuICAgICAgICAgICAgdXNlcm5hbWU6IFwibXJ0YWxsZ3V5XCIsXG4gICAgICAgICAgICBwb3N0czogMTUsXG4gICAgICAgICAgICBmb2xsb3dlcnM6IDIwMCxcbiAgICAgICAgICAgIGZvbGxvd2luZzogMTUwLFxuICAgICAgICAgICAgYmlvOiBcIkkgbGlrZSBTaGFyayBNb3ZpZXNcIixcbiAgICAgICAgICAgIHJlY2VudEFjdGl2aXRpZXM6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwicmV2aWV3ZWRcIixcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ0FkZGVkIE1vdmllIHJldmlldyBmb3IgXCJTaGFya25hZG9cIicsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwid2F0Y2hlZFwiLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiAnV2F0Y2hlZCBcIkphd3NcIicsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwibGlrZWRcIixcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogJ0xpa2VkIFwiRGVlcCBCbHVlIFNlYVwiJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJ3YXRjaGVkXCIsXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6ICdXYXRjaGVkIFwiRGVlcCBCbHVlIFNlYVwiJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5lZGl0TW9kZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnBhZ2UuYWN0aW9uQmFySGlkZGVuID0gdHJ1ZTtcbiAgICB9XG4gICAgYmFja0xvYWRlZCgpIHtcbiAgICAgICAgdGhpcy5pbml0aWFsaXplQ2FyZHMoKTtcbiAgICB9XG4gICAgb25FZGl0KCkge1xuICAgICAgICBpZiAoIXRoaXMuZWRpdE1vZGUpIHtcbiAgICAgICAgICAgIHRoaXMuZmxpcFRvQmFjaygpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZWRpdE1vZGUgPSB0cnVlO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgb25TYXZlKCkge1xuICAgICAgICBpZiAodGhpcy5lZGl0TW9kZSkge1xuICAgICAgICAgICAgdGhpcy5mbGlwVG9Gcm9udCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuZWRpdE1vZGUgPSBmYWxzZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZsaXBUb0JhY2soKSB7XG4gICAgICAgIHRoaXMuYmFjay5uYXRpdmVFbGVtZW50LnZpc2liaWxpdHkgPSBcInZpc2libGVcIjtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0RmxpcFRvQmFja0FuaW1hdGlvbig1MDApXG4gICAgICAgICAgICAucGxheSgpXG4gICAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmZyb250Lm5hdGl2ZUVsZW1lbnQudmlzaWJpbGl0eSA9IFwiY29sbGFwc2VcIjtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGZsaXBUb0Zyb250KCkge1xuICAgICAgICB0aGlzLmZyb250Lm5hdGl2ZUVsZW1lbnQudmlzaWJpbGl0eSA9IFwidmlzaWJsZVwiO1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRGbGlwVG9Gcm9udEFuaW1hdGlvbig1MDApXG4gICAgICAgICAgICAucGxheSgpXG4gICAgICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmJhY2submF0aXZlRWxlbWVudC52aXNpYmlsaXR5ID0gXCJjb2xsYXBzZVwiO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgaW5pdGlhbGl6ZUNhcmRzKCkge1xuICAgICAgICBpZiAodGhpcy5iYWNrICYmIHRoaXMuYmFjay5uYXRpdmVFbGVtZW50KSB7XG4gICAgICAgICAgICAvLyByb3RhdGUgYW5kIGhpZGUgYmFjayBzaWRlXG4gICAgICAgICAgICB0aGlzLmJhY2submF0aXZlRWxlbWVudC5yb3RhdGVYID0gMTgwO1xuICAgICAgICAgICAgdGhpcy5iYWNrLm5hdGl2ZUVsZW1lbnQub3BhY2l0eSA9IDA7XG4gICAgICAgICAgICB0aGlzLmJhY2submF0aXZlRWxlbWVudC52aXNpYmlsaXR5ID0gXCJjb2xsYXBzZVwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIGdldEZsaXBUb0JhY2tBbmltYXRpb24oYW5pbWF0aW9uRHVyYXRpb24pIHtcbiAgICAgICAgY29uc3QgYW5pbWF0aW9uRGVmaW5pdGlvbiA9IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IHRoaXMuZnJvbnQubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgICAgICByb3RhdGU6IHsgeDogLTE4MCwgeTogMCwgejogMCB9LFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiBhbmltYXRpb25EdXJhdGlvbixcbiAgICAgICAgICAgICAgICBjdXJ2ZTogQ29yZVR5cGVzLkFuaW1hdGlvbkN1cnZlLmVhc2VJbk91dCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0OiB0aGlzLmJhY2submF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgICAgICByb3RhdGU6IHsgeDogMCwgeTogMCwgejogMCB9LFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiBhbmltYXRpb25EdXJhdGlvbixcbiAgICAgICAgICAgICAgICBjdXJ2ZTogQ29yZVR5cGVzLkFuaW1hdGlvbkN1cnZlLmVhc2VJbk91dCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0OiB0aGlzLmZyb250Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMCxcbiAgICAgICAgICAgICAgICBkZWxheTogYW5pbWF0aW9uRHVyYXRpb24gLyAyLFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAxLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IHRoaXMuYmFjay5uYXRpdmVFbGVtZW50LFxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDEsXG4gICAgICAgICAgICAgICAgZGVsYXk6IGFuaW1hdGlvbkR1cmF0aW9uIC8gMixcbiAgICAgICAgICAgICAgICBkdXJhdGlvbjogMSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF07XG4gICAgICAgIHJldHVybiBuZXcgQW5pbWF0aW9uKGFuaW1hdGlvbkRlZmluaXRpb24sIGZhbHNlKTtcbiAgICB9XG4gICAgZ2V0RmxpcFRvRnJvbnRBbmltYXRpb24oYW5pbWF0aW9uRHVyYXRpb24pIHtcbiAgICAgICAgY29uc3QgYW5pbWF0aW9uRGVmaW5pdGlvbiA9IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IHRoaXMuZnJvbnQubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgICAgICByb3RhdGU6IHsgeDogMCwgeTogMCwgejogMCB9LFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiBhbmltYXRpb25EdXJhdGlvbixcbiAgICAgICAgICAgICAgICBjdXJ2ZTogQ29yZVR5cGVzLkFuaW1hdGlvbkN1cnZlLmVhc2VJbk91dCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0OiB0aGlzLmJhY2submF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgICAgICByb3RhdGU6IHsgeDogMTgwLCB5OiAwLCB6OiAwIH0sXG4gICAgICAgICAgICAgICAgZHVyYXRpb246IGFuaW1hdGlvbkR1cmF0aW9uLFxuICAgICAgICAgICAgICAgIGN1cnZlOiBDb3JlVHlwZXMuQW5pbWF0aW9uQ3VydmUuZWFzZUluT3V0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IHRoaXMuZnJvbnQubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAxLFxuICAgICAgICAgICAgICAgIGRlbGF5OiBhbmltYXRpb25EdXJhdGlvbiAvIDIsXG4gICAgICAgICAgICAgICAgZHVyYXRpb246IDEsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRhcmdldDogdGhpcy5iYWNrLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMCxcbiAgICAgICAgICAgICAgICBkZWxheTogYW5pbWF0aW9uRHVyYXRpb24gLyAyLFxuICAgICAgICAgICAgICAgIGR1cmF0aW9uOiAxLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXTtcbiAgICAgICAgcmV0dXJuIG5ldyBBbmltYXRpb24oYW5pbWF0aW9uRGVmaW5pdGlvbiwgZmFsc2UpO1xuICAgIH1cbn1cblByb2ZpbGVDb21wb25lbnQuybVmYWMgPSBmdW5jdGlvbiBQcm9maWxlQ29tcG9uZW50X0ZhY3RvcnkodCkgeyByZXR1cm4gbmV3ICh0IHx8IFByb2ZpbGVDb21wb25lbnQpKGkwLsm1ybVkaXJlY3RpdmVJbmplY3QoaTEuUGFnZSkpOyB9O1xuUHJvZmlsZUNvbXBvbmVudC7JtWNtcCA9IC8qQF9fUFVSRV9fKi8gaTAuybXJtWRlZmluZUNvbXBvbmVudCh7IHR5cGU6IFByb2ZpbGVDb21wb25lbnQsIHNlbGVjdG9yczogW1tcIm5zLXByb2ZpbGVcIl1dLCB2aWV3UXVlcnk6IGZ1bmN0aW9uIFByb2ZpbGVDb21wb25lbnRfUXVlcnkocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybV2aWV3UXVlcnkoX2MwLCA1KTtcbiAgICAgICAgaTAuybXJtXZpZXdRdWVyeShfYzEsIDUpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBsZXQgX3Q7XG4gICAgICAgIGkwLsm1ybVxdWVyeVJlZnJlc2goX3QgPSBpMC7Jtcm1bG9hZFF1ZXJ5KCkpICYmIChjdHguZnJvbnQgPSBfdC5maXJzdCk7XG4gICAgICAgIGkwLsm1ybVxdWVyeVJlZnJlc2goX3QgPSBpMC7Jtcm1bG9hZFF1ZXJ5KCkpICYmIChjdHguYmFjayA9IF90LmZpcnN0KTtcbiAgICB9IH0sIGRlY2xzOiA5LCB2YXJzOiAyLCBjb25zdHM6IFtbXCJyb3dzXCIsIFwiYXV0bywgKlwiXSwgW1wicm93XCIsIFwiMFwiLCBcInNyY1wiLCBcIn4vYXNzZXRzL2ltYWdlcy9wcm9maWxlL3Byb2ZpbGUtY292ZXIucG5nXCIsIFwid2lkdGhcIiwgXCIxMDAlXCIsIFwiaGVpZ2h0XCIsIFwiMjUwXCIsIFwic3RyZXRjaFwiLCBcImFzcGVjdEZpbGxcIl0sIFtcInJvd1wiLCBcIjFcIiwgXCJyb3dzXCIsIFwiYXV0b1wiLCBcIm1hcmdpblwiLCBcIi0xNTAgMzAgMCAzMFwiXSwgW1wiZnJvbnRcIiwgXCJcIl0sIFszLCBcInByb2ZpbGVcIiwgXCJlZGl0XCJdLCBbMywgXCJsb2FkZWRcIl0sIFtcImJhY2tcIiwgXCJcIl0sIFszLCBcInByb2ZpbGVcIiwgXCJzYXZlXCJdXSwgdGVtcGxhdGU6IGZ1bmN0aW9uIFByb2ZpbGVDb21wb25lbnRfVGVtcGxhdGUocmYsIGN0eCkgeyBpZiAocmYgJiAxKSB7XG4gICAgICAgIGkwLsm1ybVlbGVtZW50U3RhcnQoMCwgXCJHcmlkTGF5b3V0XCIsIDApO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudCgxLCBcIkltYWdlXCIsIDEpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDIsIFwiR3JpZExheW91dFwiLCAyKSgzLCBcIkdyaWRMYXlvdXRcIiwgbnVsbCwgMykoNSwgXCJucy1wcm9maWxlLWNhcmQtZnJvbnRcIiwgNCk7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcImVkaXRcIiwgZnVuY3Rpb24gUHJvZmlsZUNvbXBvbmVudF9UZW1wbGF0ZV9uc19wcm9maWxlX2NhcmRfZnJvbnRfZWRpdF81X2xpc3RlbmVyKCkgeyByZXR1cm4gY3R4Lm9uRWRpdCgpOyB9KTtcbiAgICAgICAgaTAuybXJtWVsZW1lbnRFbmQoKSgpO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDYsIFwiR3JpZExheW91dFwiLCA1LCA2KTtcbiAgICAgICAgaTAuybXJtWxpc3RlbmVyKFwibG9hZGVkXCIsIGZ1bmN0aW9uIFByb2ZpbGVDb21wb25lbnRfVGVtcGxhdGVfR3JpZExheW91dF9sb2FkZWRfNl9saXN0ZW5lcigpIHsgcmV0dXJuIGN0eC5iYWNrTG9hZGVkKCk7IH0pO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudFN0YXJ0KDgsIFwibnMtcHJvZmlsZS1jYXJkLWJhY2tcIiwgNyk7XG4gICAgICAgIGkwLsm1ybVsaXN0ZW5lcihcInNhdmVcIiwgZnVuY3Rpb24gUHJvZmlsZUNvbXBvbmVudF9UZW1wbGF0ZV9uc19wcm9maWxlX2NhcmRfYmFja19zYXZlXzhfbGlzdGVuZXIoKSB7IHJldHVybiBjdHgub25TYXZlKCk7IH0pO1xuICAgICAgICBpMC7Jtcm1ZWxlbWVudEVuZCgpKCkoKSgpO1xuICAgIH0gaWYgKHJmICYgMikge1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSg1KTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwicHJvZmlsZVwiLCBjdHgucHJvZmlsZURhdGEpO1xuICAgICAgICBpMC7Jtcm1YWR2YW5jZSgzKTtcbiAgICAgICAgaTAuybXJtXByb3BlcnR5KFwicHJvZmlsZVwiLCBjdHgucHJvZmlsZURhdGEpO1xuICAgIH0gfSwgZGVwZW5kZW5jaWVzOiBbaTIuUHJvZmlsZUNhcmRGcm9udENvbXBvbmVudCwgaTMuUHJvZmlsZUNhcmRCYWNrQ29tcG9uZW50XSwgZW5jYXBzdWxhdGlvbjogMiB9KTtcbiIsImltcG9ydCB7IE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSwgTmF0aXZlU2NyaXB0Rm9ybXNNb2R1bGUsIH0gZnJvbSBcIkBuYXRpdmVzY3JpcHQvYW5ndWxhclwiO1xuaW1wb3J0IHsgUHJvZmlsZVJvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9wcm9maWxlLXJvdXRpbmcubW9kdWxlXCI7XG5pbXBvcnQgKiBhcyBpMCBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuZXhwb3J0IGNsYXNzIFByb2ZpbGVNb2R1bGUge1xufVxuUHJvZmlsZU1vZHVsZS7JtWZhYyA9IGZ1bmN0aW9uIFByb2ZpbGVNb2R1bGVfRmFjdG9yeSh0KSB7IHJldHVybiBuZXcgKHQgfHwgUHJvZmlsZU1vZHVsZSkoKTsgfTtcblByb2ZpbGVNb2R1bGUuybVtb2QgPSAvKkBfX1BVUkVfXyovIGkwLsm1ybVkZWZpbmVOZ01vZHVsZSh7IHR5cGU6IFByb2ZpbGVNb2R1bGUgfSk7XG5Qcm9maWxlTW9kdWxlLsm1aW5qID0gLypAX19QVVJFX18qLyBpMC7Jtcm1ZGVmaW5lSW5qZWN0b3IoeyBpbXBvcnRzOiBbTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLFxuICAgICAgICBOYXRpdmVTY3JpcHRGb3Jtc01vZHVsZSxcbiAgICAgICAgUHJvZmlsZVJvdXRpbmdNb2R1bGVdIH0pO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9